import { useState, useEffect } from 'react';
import { Instagram, Music2, Youtube, AlertCircle, CheckCircle, RefreshCw, Unplug, ExternalLink } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ConnectedAccount, Platform, getMockConnectedAccounts, disconnectAccount, getPlatformInfo } from '../../lib/socialMedia';

export default function SocialMediaSettings() {
  const { user } = useAuth();
  const [connectedAccounts, setConnectedAccounts] = useState<ConnectedAccount[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [disconnecting, setDisconnecting] = useState<string | null>(null);

  useEffect(() => {
    loadConnectedAccounts();
  }, []);

  const loadConnectedAccounts = async () => {
    setIsLoading(true);
    try {
      // In production: fetch from Supabase
      // For demo: use mock data
      const accounts = getMockConnectedAccounts();
      setConnectedAccounts(accounts);
    } catch (error) {
      console.error('Failed to load connected accounts:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleConnect = (platform: Platform) => {
    // In production: call initiateOAuth(platform, clientId)
    // For demo: show alert
    alert(`🔄 Connecting to ${platform}...\n\nIn production, this would redirect you to ${getPlatformInfo(platform).name}'s OAuth authorization page.`);
  };

  const handleDisconnect = async (platform: Platform, accountId: string) => {
    if (!confirm(`Are you sure you want to disconnect your ${getPlatformInfo(platform).name} account?`)) {
      return;
    }

    setDisconnecting(accountId);
    try {
      await disconnectAccount(platform, accountId);
      setConnectedAccounts(prev => prev.filter(acc => acc.accountId !== accountId));
    } catch (error) {
      console.error('Failed to disconnect account:', error);
      alert('Failed to disconnect account. Please try again.');
    } finally {
      setDisconnecting(null);
    }
  };

  const handleRefreshToken = async (account: ConnectedAccount) => {
    alert(`🔄 Refreshing ${account.platform} token...\n\nIn production, this would refresh your access token.`);
  };

  const getPlatformIcon = (platform: Platform) => {
    switch (platform) {
      case 'instagram':
        return <Instagram className="w-5 h-5" />;
      case 'tiktok':
        return <Music2 className="w-5 h-5" />;
      case 'youtube':
        return <Youtube className="w-5 h-5" />;
    }
  };

  const isTokenExpired = (expiresAt: number) => {
    return Date.now() >= expiresAt;
  };

  const isTokenExpiringSoon = (expiresAt: number) => {
    return Date.now() >= expiresAt - 24 * 60 * 60 * 1000; // Within 24 hours
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const availablePlatforms: Platform[] = ['instagram', 'tiktok', 'youtube'];
  const connectedPlatforms = connectedAccounts.map(acc => acc.platform);
  const unconnectedPlatforms = availablePlatforms.filter(p => !connectedPlatforms.includes(p));

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <RefreshCw className="w-6 h-6 animate-spin text-purple-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Connected Accounts</h2>
        <p className="text-[var(--color-text-secondary)]">
          Manage your social media connections and publish content across platforms
        </p>
      </div>

      {/* Connected Accounts */}
      {connectedAccounts.length > 0 && (
        <div className="space-y-4">
          {connectedAccounts.map((account) => {
            const platformInfo = getPlatformInfo(account.platform);
            const expired = isTokenExpired(account.expiresAt);
            const expiringSoon = isTokenExpiringSoon(account.expiresAt);

            return (
              <div
                key={account.accountId}
                className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: platformInfo.color + '20' }}
                    >
                      <div style={{ color: platformInfo.color }}>
                        {getPlatformIcon(account.platform)}
                      </div>
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-lg">{account.displayName}</h3>
                        {account.isActive && !expired && (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        )}
                        {expired && (
                          <AlertCircle className="w-4 h-4 text-red-500" />
                        )}
                        {!expired && expiringSoon && (
                          <AlertCircle className="w-4 h-4 text-yellow-500" />
                        )}
                      </div>
                      <p className="text-sm text-[var(--color-text-secondary)] mb-3">
                        {account.username} • {platformInfo.name}
                      </p>

                      {/* Stats */}
                      {account.stats && (
                        <div className="flex items-center gap-4 mb-3">
                          {account.stats.followers !== undefined && (
                            <div className="text-sm">
                              <span className="font-bold text-purple-400">
                                {formatNumber(account.stats.followers)}
                              </span>
                              <span className="text-[var(--color-text-secondary)] ml-1">followers</span>
                            </div>
                          )}
                          {account.stats.posts !== undefined && (
                            <div className="text-sm">
                              <span className="font-bold text-purple-400">
                                {formatNumber(account.stats.posts)}
                              </span>
                              <span className="text-[var(--color-text-secondary)] ml-1">posts</span>
                            </div>
                          )}
                          {account.stats.engagement !== undefined && (
                            <div className="text-sm">
                              <span className="font-bold text-purple-400">
                                {account.stats.engagement}%
                              </span>
                              <span className="text-[var(--color-text-secondary)] ml-1">engagement</span>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Status Messages */}
                      {expired && (
                        <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 mb-3">
                          <p className="text-sm text-red-400 flex items-center gap-2">
                            <AlertCircle className="w-4 h-4" />
                            Access token expired. Please reconnect your account.
                          </p>
                        </div>
                      )}
                      {!expired && expiringSoon && (
                        <div className="bg-yellow-500/10 border border-yellow-500/50 rounded-lg p-3 mb-3">
                          <p className="text-sm text-yellow-400 flex items-center gap-2">
                            <AlertCircle className="w-4 h-4" />
                            Access token expires soon. Consider refreshing.
                          </p>
                        </div>
                      )}

                      <div className="text-xs text-[var(--color-text-secondary)]">
                        Connected {formatDate(account.connectedAt)}
                        {account.lastSyncAt && ` • Last synced ${formatDate(account.lastSyncAt)}`}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {(expired || expiringSoon) && (
                      <button
                        onClick={() => handleRefreshToken(account)}
                        className="px-4 py-2 bg-[var(--color-background)] border border-[var(--color-border)] hover:bg-[var(--color-surface-hover)] rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
                      >
                        <RefreshCw className="w-4 h-4" />
                        Refresh
                      </button>
                    )}
                    <button
                      onClick={() => handleDisconnect(account.platform, account.accountId)}
                      disabled={disconnecting === account.accountId}
                      className="px-4 py-2 bg-red-500/10 border border-red-500/50 hover:bg-red-500/20 text-red-400 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 disabled:opacity-50"
                    >
                      <Unplug className="w-4 h-4" />
                      {disconnecting === account.accountId ? 'Disconnecting...' : 'Disconnect'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Available Platforms to Connect */}
      {unconnectedPlatforms.length > 0 && (
        <div>
          <h3 className="text-lg font-bold mb-4">Connect New Platform</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {unconnectedPlatforms.map((platform) => {
              const platformInfo = getPlatformInfo(platform);
              return (
                <button
                  key={platform}
                  onClick={() => handleConnect(platform)}
                  className="bg-[var(--color-surface)] border border-[var(--color-border)] hover:border-purple-500/50 rounded-xl p-6 transition-all text-left group"
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                    style={{ backgroundColor: platformInfo.color + '20' }}
                  >
                    <div style={{ color: platformInfo.color }}>
                      {getPlatformIcon(platform)}
                    </div>
                  </div>
                  <h4 className="font-bold mb-2 flex items-center gap-2">
                    {platformInfo.name}
                    <ExternalLink className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </h4>
                  <p className="text-sm text-[var(--color-text-secondary)] mb-4">
                    {platformInfo.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {platformInfo.capabilities.map((cap) => (
                      <span
                        key={cap}
                        className="px-2 py-1 bg-[var(--color-background)] rounded text-xs"
                      >
                        {cap}
                      </span>
                    ))}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty State */}
      {connectedAccounts.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-purple-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Instagram className="w-8 h-8 text-purple-400" />
          </div>
          <h3 className="text-xl font-bold mb-2">No Connected Accounts</h3>
          <p className="text-[var(--color-text-secondary)] mb-6">
            Connect your social media accounts to start publishing and scheduling content
          </p>
        </div>
      )}
    </div>
  );
}
