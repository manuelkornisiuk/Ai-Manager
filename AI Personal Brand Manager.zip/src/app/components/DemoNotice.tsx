import { AlertCircle, Shield, X } from 'lucide-react';
import { useState } from 'react';

export default function DemoNotice() {
  const [dismissed, setDismissed] = useState(() => {
    return localStorage.getItem('demo-notice-dismissed') === 'true';
  });

  const handleDismiss = () => {
    localStorage.setItem('demo-notice-dismissed', 'true');
    setDismissed(true);
  };

  if (dismissed) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 max-w-2xl w-full mx-4">
      <div className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 border-2 border-blue-500/50 rounded-xl p-4 backdrop-blur-lg shadow-2xl">
        <div className="flex items-start gap-3">
          <Shield className="w-6 h-6 text-blue-400 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <div className="flex items-start justify-between gap-2 mb-2">
              <h3 className="font-bold text-blue-300">🔒 Safe Demo Mode</h3>
              <button
                onClick={handleDismiss}
                className="text-[var(--color-text-secondary)] hover:text-white transition-colors"
                aria-label="Dismiss notice"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-[var(--color-text-secondary)] mb-2">
              This is a <strong className="text-white">demonstration version</strong> with mock data only.
              No real social media accounts are connected. Your Instagram, Spotify, TikTok, and YouTube accounts
              are <strong className="text-green-400">100% safe</strong> and cannot be accessed.
            </p>
            <div className="flex items-center gap-2 text-xs text-blue-300">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>All data shown is simulated for demonstration purposes</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
