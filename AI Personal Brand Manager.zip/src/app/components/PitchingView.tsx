import { Music, Radio, Tv, Send, CheckCircle, Clock, Target, TrendingUp, Mail, ExternalLink, Star, Sparkles, Crown } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import PremiumFeatureGate from './PremiumFeatureGate.tsx';

export default function PitchingView() {
  const [activeCategory, setActiveCategory] = useState<'blogs' | 'playlists' | 'sync'>('playlists');
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  // Get auth context - creator always has access
  const { hasPremiumAccess, isCreator, user } = useAuth();

  // Check if user has access to pitching feature
  const hasPitchingAccess = hasPremiumAccess;

  const spotifyPlaylists = [
    {
      name: 'Fresh Finds: Hip-Hop',
      curator: 'Spotify Editorial',
      followers: '180K',
      genre: 'Hip-Hop',
      matchScore: 95,
      avgStreams: '50K per placement',
      submissionStatus: 'not-submitted',
      tips: 'Submit 3-4 weeks before release. Include high-quality cover art and compelling story.',
    },
    {
      name: 'Underground Gems',
      curator: 'IndieVibes',
      followers: '45K',
      genre: 'Alternative Hip-Hop',
      matchScore: 92,
      avgStreams: '12K per placement',
      submissionStatus: 'not-submitted',
      tips: 'This curator loves moody, atmospheric production. Mention your creative process.',
    },
    {
      name: 'Chill Beats & Bars',
      curator: 'LoFi Culture',
      followers: '230K',
      genre: 'Chill Hip-Hop',
      matchScore: 88,
      avgStreams: '65K per placement',
      submissionStatus: 'submitted',
      submittedDate: '3 days ago',
      tips: 'Response time: 7-14 days. They prioritize unique vocal delivery.',
    },
    {
      name: 'New Music Friday',
      curator: 'Spotify Editorial',
      followers: '3.2M',
      genre: 'All Genres',
      matchScore: 75,
      avgStreams: '250K per placement',
      submissionStatus: 'not-submitted',
      tips: 'Highly competitive. Submit only your absolute best work with strong momentum.',
    },
    {
      name: 'Midnight Vibes',
      curator: 'NightOwl Music',
      followers: '89K',
      genre: 'Moody Hip-Hop',
      matchScore: 94,
      avgStreams: '25K per placement',
      submissionStatus: 'approved',
      approvedDate: '2 weeks ago',
      tips: 'Added to playlist! Expected 25K streams over next month.',
    },
  ];

  const blogOpportunities = [
    {
      name: 'HipHopDX',
      type: 'Major Blog',
      reach: '2.5M monthly readers',
      genre: 'Hip-Hop',
      matchScore: 89,
      responseRate: '15%',
      avgTimeline: '2-4 weeks',
      submissionStatus: 'not-submitted',
      contact: 'submissions@hiphopdx.com',
      requirements: 'Press kit, high-res photos, streaming links, bio (max 300 words)',
    },
    {
      name: 'Complex Music',
      type: 'Major Blog',
      reach: '5M monthly readers',
      genre: 'Hip-Hop, R&B',
      matchScore: 82,
      responseRate: '8%',
      avgTimeline: '3-6 weeks',
      submissionStatus: 'not-submitted',
      contact: 'music@complex.com',
      requirements: 'Must have existing press coverage or significant streaming numbers',
    },
    {
      name: 'Elevator Magazine',
      type: 'Indie Blog',
      reach: '850K monthly readers',
      genre: 'Alternative Hip-Hop',
      matchScore: 96,
      responseRate: '35%',
      avgTimeline: '1-2 weeks',
      submissionStatus: 'submitted',
      submittedDate: '5 days ago',
      contact: 'submit@elevatormagazine.com',
      requirements: 'EPK, Spotify link, social media handles, artist statement',
    },
    {
      name: 'The 405',
      type: 'Indie Blog',
      reach: '400K monthly readers',
      genre: 'Alternative, Experimental',
      matchScore: 91,
      responseRate: '25%',
      avgTimeline: '2-3 weeks',
      submissionStatus: 'not-submitted',
      contact: 'submissions@the405.com',
      requirements: 'SoundCloud/Spotify link, bio, social links, press photo',
    },
  ];

  const syncOpportunities = [
    {
      title: 'Drama Series: "City Lights"',
      type: 'TV Show',
      network: 'Netflix',
      genre: 'Urban Drama',
      mood: 'Moody, Atmospheric',
      matchScore: 93,
      budget: '$2,000 - $5,000',
      deadline: '2 weeks',
      description: 'Looking for moody hip-hop tracks for underground club scenes. Dark, atmospheric production preferred.',
      requirements: 'Instrumental and vocal versions, cleared samples, master and publishing rights',
      submissionStatus: 'not-submitted',
    },
    {
      title: 'Indie Film: "Urban Stories"',
      type: 'Movie',
      network: 'Sundance Selection',
      genre: 'Coming of Age',
      mood: 'Introspective, Raw',
      matchScore: 96,
      budget: '$1,500 - $3,000',
      deadline: '10 days',
      description: 'Need authentic hip-hop tracks for protagonist journey. Raw, emotional delivery.',
      requirements: 'Clean and explicit versions, full rights clearance, stems available',
      submissionStatus: 'not-submitted',
    },
    {
      title: 'Commercial: Nike Basketball',
      type: 'Advertisement',
      network: 'Nike',
      genre: 'High Energy Hip-Hop',
      mood: 'Motivational, Powerful',
      matchScore: 78,
      budget: '$8,000 - $15,000',
      deadline: '5 days',
      description: 'Seeking high-energy hip-hop for new basketball campaign. Must be inspiring and powerful.',
      requirements: 'Worldwide rights, instrumental version required, no explicit content',
      submissionStatus: 'not-submitted',
    },
    {
      title: 'Video Game: "Street Chronicles"',
      type: 'Video Game',
      network: 'EA Games',
      genre: 'Hip-Hop',
      mood: 'Gritty, Urban',
      matchScore: 85,
      budget: '$5,000 - $10,000',
      deadline: '3 weeks',
      description: 'Building soundtrack for open-world urban game. Need gritty, authentic hip-hop tracks.',
      requirements: 'Loop-ready stems, no sample clearance issues, perpetual game license',
      submissionStatus: 'submitted',
      submittedDate: '1 week ago',
    },
  ];

  const yourTracks = [
    {
      title: 'Midnight Vibes',
      mood: 'Moody, Atmospheric',
      genre: 'Alternative Hip-Hop',
      duration: '3:24',
      bpm: 87,
      released: true,
      hasInstrumental: true,
      hasClean: true,
    },
    {
      title: 'City Nights',
      mood: 'Upbeat, Energetic',
      genre: 'Hip-Hop',
      duration: '2:58',
      bpm: 140,
      released: true,
      hasInstrumental: true,
      hasClean: false,
    },
    {
      title: 'Reflections',
      mood: 'Introspective, Emotional',
      genre: 'Alternative Hip-Hop',
      duration: '4:12',
      bpm: 75,
      released: false,
      hasInstrumental: false,
      hasClean: true,
    },
  ];

  const recentActivity = [
    {
      type: 'approved',
      target: 'Midnight Vibes (Playlist)',
      date: '2 weeks ago',
      result: 'Added to playlist - 18.5K streams so far',
    },
    {
      type: 'submitted',
      target: 'Elevator Magazine',
      date: '5 days ago',
      result: 'Awaiting response',
    },
    {
      type: 'submitted',
      target: 'Street Chronicles (Video Game)',
      date: '1 week ago',
      result: 'Under review',
    },
    {
      type: 'rejected',
      target: 'Fresh Finds: Hip-Hop',
      date: '3 weeks ago',
      result: 'Not selected - resubmit in 3 months',
    },
  ];

  const getMatchColor = (score: number) => {
    if (score >= 90) return 'text-green-400 bg-green-500/20';
    if (score >= 80) return 'text-yellow-400 bg-yellow-500/20';
    return 'text-orange-400 bg-orange-500/20';
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs font-medium rounded-full flex items-center gap-1">
          <CheckCircle className="w-3 h-3" /> Approved
        </span>;
      case 'submitted':
        return <span className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs font-medium rounded-full flex items-center gap-1">
          <Clock className="w-3 h-3" /> Submitted
        </span>;
      default:
        return <span className="px-2 py-1 bg-[var(--color-border)] text-[var(--color-text-secondary)] text-xs font-medium rounded-full">
          Not Submitted
        </span>;
    }
  };

  return (
    <div className="space-y-6">
      {showUpgradeModal && !hasPitchingAccess && (
        <PremiumFeatureGate featureName="Music Pitching" currentPlan="free" />
      )}

      <div>
        <div className="flex items-center gap-3">
          <h2 className="text-3xl font-bold">Music Pitching</h2>
          {isCreator && (
            <span className="px-3 py-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white text-sm font-bold rounded-full flex items-center gap-1">
              <Crown className="w-4 h-4" />
              Creator Access
            </span>
          )}
          {!hasPitchingAccess && !isCreator && (
            <span className="px-3 py-1 bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-sm font-bold rounded-full flex items-center gap-1">
              <Crown className="w-4 h-4" />
              Premium Only
            </span>
          )}
        </div>
        <p className="text-[var(--color-text-secondary)] mt-1">
          Get your music on playlists, blogs, and in TV/films
        </p>
      </div>

      {!hasPitchingAccess && (
        <div className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border-2 border-yellow-500/50 rounded-xl p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center flex-shrink-0">
              <Crown className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold mb-2">Unlock Music Pitching with Premium Plan</h3>
              <p className="text-[var(--color-text-secondary)] mb-4">
                Get your music in front of <strong className="text-white">180K+ playlist followers</strong>,
                <strong className="text-white"> 2.5M+ blog readers</strong>, and
                <strong className="text-white"> $2K-$15K sync opportunities</strong>. Starting at $149/month or save with annual billing ($119/month).
              </p>
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => setShowUpgradeModal(true)}
                  className="px-6 py-3 bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-white font-bold rounded-lg transition-all flex items-center gap-2"
                >
                  <Crown className="w-5 h-5" />
                  Upgrade to Premium Plan
                </button>
                <button
                  onClick={() => window.location.hash = 'pricing'}
                  className="px-6 py-3 bg-[var(--color-surface)] border border-[var(--color-border)] hover:bg-[var(--color-surface-hover)] rounded-lg font-medium transition-colors"
                >
                  View Pricing Details
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-purple-400" />
          <h3 className="text-xl font-bold">AI-Matched Opportunities</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
            <p className="text-sm text-[var(--color-text-secondary)] mb-1">High Match Rate</p>
            <p className="text-2xl font-bold text-green-400">12 Opportunities</p>
            <p className="text-xs text-[var(--color-text-secondary)] mt-1">90%+ match for your sound</p>
          </div>
          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
            <p className="text-sm text-[var(--color-text-secondary)] mb-1">Active Pitches</p>
            <p className="text-2xl font-bold text-blue-400">3 Pending</p>
            <p className="text-xs text-[var(--color-text-secondary)] mt-1">Awaiting response</p>
          </div>
          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
            <p className="text-sm text-[var(--color-text-secondary)] mb-1">Success Rate</p>
            <p className="text-2xl font-bold text-purple-400">28%</p>
            <p className="text-xs text-[var(--color-text-secondary)] mt-1">Above 15% average</p>
          </div>
        </div>
      </div>

      <div className="flex gap-3 overflow-x-auto pb-2">
        <button
          onClick={() => setActiveCategory('playlists')}
          className={`px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap flex items-center gap-2 ${
            activeCategory === 'playlists'
              ? 'bg-purple-500 text-white'
              : 'bg-[var(--color-surface)] text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-hover)]'
          }`}
        >
          <Music className="w-4 h-4" />
          Spotify Playlists
        </button>
        <button
          onClick={() => setActiveCategory('blogs')}
          className={`px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap flex items-center gap-2 ${
            activeCategory === 'blogs'
              ? 'bg-purple-500 text-white'
              : 'bg-[var(--color-surface)] text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-hover)]'
          }`}
        >
          <Radio className="w-4 h-4" />
          Blogs & Press
        </button>
        <button
          onClick={() => setActiveCategory('sync')}
          className={`px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap flex items-center gap-2 ${
            activeCategory === 'sync'
              ? 'bg-purple-500 text-white'
              : 'bg-[var(--color-surface)] text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-hover)]'
          }`}
        >
          <Tv className="w-4 h-4" />
          TV/Film/Ads
        </button>
      </div>

      {activeCategory === 'playlists' && (
        <div className="space-y-4">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
            <div className="mb-4">
              <h3 className="text-xl font-bold">Spotify Playlist Opportunities</h3>
              <p className="text-sm text-[var(--color-text-secondary)]">AI-matched playlists for your Alternative Hip-Hop sound</p>
            </div>
            <div className="space-y-4">
              {spotifyPlaylists.map((playlist, index) => (
                <div key={index} className="p-5 bg-[var(--color-background)] rounded-xl border border-[var(--color-border)] hover:border-purple-500/50 transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-bold text-lg">{playlist.name}</h4>
                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${getMatchColor(playlist.matchScore)}`}>
                          {playlist.matchScore}% Match
                        </span>
                        {getStatusBadge(playlist.submissionStatus)}
                      </div>
                      <div className="flex flex-wrap gap-4 text-sm text-[var(--color-text-secondary)] mb-2">
                        <span>Curator: {playlist.curator}</span>
                        <span>•</span>
                        <span>{playlist.followers} followers</span>
                        <span>•</span>
                        <span>{playlist.genre}</span>
                      </div>
                      {playlist.submissionStatus === 'submitted' && (
                        <p className="text-sm text-blue-400">Submitted {playlist.submittedDate}</p>
                      )}
                      {playlist.submissionStatus === 'approved' && (
                        <p className="text-sm text-green-400">✓ Approved {playlist.approvedDate}</p>
                      )}
                    </div>
                  </div>

                  <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-3 mb-3">
                    <p className="text-xs font-medium text-purple-300 mb-1">💡 Pitch Tips:</p>
                    <p className="text-sm text-[var(--color-text-secondary)]">{playlist.tips}</p>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-sm">
                      <span className="text-green-400 font-medium">Avg: {playlist.avgStreams}</span>
                    </div>
                    {playlist.submissionStatus === 'not-submitted' && (
                      <button
                        onClick={() => !hasPitchingAccess && setShowUpgradeModal(true)}
                        disabled={!hasPitchingAccess}
                        className={`px-4 py-2 rounded-lg font-medium transition-all flex items-center gap-2 ${
                          hasPitchingAccess
                            ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white'
                            : 'bg-[var(--color-surface)] border border-yellow-500/50 text-yellow-400 cursor-pointer'
                        }`}
                      >
                        {hasPitchingAccess ? <Send className="w-4 h-4" /> : <Crown className="w-4 h-4" />}
                        {hasPitchingAccess ? 'Submit Pitch' : 'Upgrade to Submit'}
                      </button>
                    )}
                    {playlist.submissionStatus === 'submitted' && (
                      <button className="px-4 py-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg font-medium text-[var(--color-text-secondary)] cursor-not-allowed">
                        Pending Review
                      </button>
                    )}
                    {playlist.submissionStatus === 'approved' && (
                      <button className="px-4 py-2 bg-green-500/20 text-green-400 rounded-lg font-medium flex items-center gap-2">
                        <CheckCircle className="w-4 h-4" />
                        View Analytics
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeCategory === 'blogs' && (
        <div className="space-y-4">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
            <div className="mb-4">
              <h3 className="text-xl font-bold">Blog & Press Opportunities</h3>
              <p className="text-sm text-[var(--color-text-secondary)]">Get featured on top music blogs and publications</p>
            </div>
            <div className="space-y-4">
              {blogOpportunities.map((blog, index) => (
                <div key={index} className="p-5 bg-[var(--color-background)] rounded-xl border border-[var(--color-border)] hover:border-purple-500/50 transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-bold text-lg">{blog.name}</h4>
                        <span className="px-2 py-1 bg-purple-500/20 text-purple-300 text-xs font-medium rounded-full">
                          {blog.type}
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${getMatchColor(blog.matchScore)}`}>
                          {blog.matchScore}% Match
                        </span>
                        {getStatusBadge(blog.submissionStatus)}
                      </div>
                      <div className="flex flex-wrap gap-4 text-sm text-[var(--color-text-secondary)] mb-2">
                        <span>{blog.reach}</span>
                        <span>•</span>
                        <span>{blog.genre}</span>
                        <span>•</span>
                        <span>{blog.responseRate} response rate</span>
                        <span>•</span>
                        <span>{blog.avgTimeline} turnaround</span>
                      </div>
                      {blog.submissionStatus === 'submitted' && (
                        <p className="text-sm text-blue-400">Submitted {blog.submittedDate}</p>
                      )}
                    </div>
                  </div>

                  <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 mb-3">
                    <p className="text-xs font-medium text-blue-300 mb-1">📋 Requirements:</p>
                    <p className="text-sm text-[var(--color-text-secondary)]">{blog.requirements}</p>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-[var(--color-text-secondary)]">
                      <Mail className="w-4 h-4" />
                      <span>{blog.contact}</span>
                    </div>
                    {blog.submissionStatus === 'not-submitted' && (
                      <button
                        onClick={() => {
                          if (!hasPitchingAccess) {
                            setShowUpgradeModal(true);
                          } else {
                            setSelectedTarget({
                              name: blog.name,
                              type: 'blog',
                              details: blog,
                            });
                            setShowPitchModal(true);
                          }
                        }}
                        className={`px-4 py-2 rounded-lg font-medium transition-all flex items-center gap-2 ${
                          hasPitchingAccess
                            ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white'
                            : 'bg-[var(--color-surface)] border border-yellow-500/50 text-yellow-400 cursor-pointer'
                        }`}
                      >
                        {hasPitchingAccess ? <Send className="w-4 h-4" /> : <Crown className="w-4 h-4" />}
                        {hasPitchingAccess ? 'Submit Press Kit' : 'Upgrade to Submit'}
                      </button>
                    )}
                    {blog.submissionStatus === 'submitted' && (
                      <button className="px-4 py-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg font-medium text-[var(--color-text-secondary)] cursor-not-allowed">
                        Awaiting Response
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeCategory === 'sync' && (
        <div className="space-y-4">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
            <div className="mb-4">
              <h3 className="text-xl font-bold">Sync Licensing Opportunities</h3>
              <p className="text-sm text-[var(--color-text-secondary)]">Get your music in TV shows, films, ads, and video games</p>
            </div>
            <div className="space-y-4">
              {syncOpportunities.map((opportunity, index) => (
                <div key={index} className="p-5 bg-[var(--color-background)] rounded-xl border border-[var(--color-border)] hover:border-purple-500/50 transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-bold text-lg">{opportunity.title}</h4>
                        <span className="px-2 py-1 bg-pink-500/20 text-pink-300 text-xs font-medium rounded-full">
                          {opportunity.type}
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${getMatchColor(opportunity.matchScore)}`}>
                          {opportunity.matchScore}% Match
                        </span>
                        {getStatusBadge(opportunity.submissionStatus)}
                      </div>
                      <div className="flex flex-wrap gap-4 text-sm text-[var(--color-text-secondary)] mb-2">
                        <span>{opportunity.network}</span>
                        <span>•</span>
                        <span>{opportunity.genre}</span>
                        <span>•</span>
                        <span className="text-green-400 font-medium">{opportunity.budget}</span>
                        <span>•</span>
                        <span className="text-orange-400">Deadline: {opportunity.deadline}</span>
                      </div>
                      {opportunity.submissionStatus === 'submitted' && (
                        <p className="text-sm text-blue-400">Submitted {opportunity.submittedDate}</p>
                      )}
                    </div>
                  </div>

                  <p className="text-sm text-[var(--color-text-secondary)] mb-3">{opportunity.description}</p>

                  <div className="bg-pink-500/10 border border-pink-500/20 rounded-lg p-3 mb-3">
                    <p className="text-xs font-medium text-pink-300 mb-1">📋 Requirements:</p>
                    <p className="text-sm text-[var(--color-text-secondary)]">{opportunity.requirements}</p>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-sm">
                      <span className="text-[var(--color-text-secondary)]">Mood: </span>
                      <span className="text-purple-400 font-medium">{opportunity.mood}</span>
                    </div>
                    {opportunity.submissionStatus === 'not-submitted' && (
                      <button
                        onClick={() => {
                          if (!hasPitchingAccess) {
                            setShowUpgradeModal(true);
                          } else {
                            setSelectedTarget({
                              name: opportunity.title,
                              type: 'sync',
                              details: opportunity,
                            });
                            setShowPitchModal(true);
                          }
                        }}
                        className={`px-4 py-2 rounded-lg font-medium transition-all flex items-center gap-2 ${
                          hasPitchingAccess
                            ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white'
                            : 'bg-[var(--color-surface)] border border-yellow-500/50 text-yellow-400 cursor-pointer'
                        }`}
                      >
                        {hasPitchingAccess ? <Send className="w-4 h-4" /> : <Crown className="w-4 h-4" />}
                        {hasPitchingAccess ? 'Submit for Sync' : 'Upgrade to Submit'}
                      </button>
                    )}
                    {opportunity.submissionStatus === 'submitted' && (
                      <button className="px-4 py-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg font-medium text-[var(--color-text-secondary)] cursor-not-allowed">
                        Under Review
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <div className="mb-4">
            <h3 className="text-xl font-bold">Your Tracks</h3>
            <p className="text-sm text-[var(--color-text-secondary)]">Select tracks to pitch</p>
          </div>
          <div className="space-y-3">
            {yourTracks.map((track, index) => (
              <div key={index} className="p-4 bg-[var(--color-background)] rounded-lg border border-[var(--color-border)]">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="font-bold">{track.title}</h4>
                    <p className="text-sm text-[var(--color-text-secondary)]">{track.mood} • {track.genre}</p>
                  </div>
                  <input type="checkbox" className="w-5 h-5 rounded border-[var(--color-border)] text-purple-500" />
                </div>
                <div className="flex flex-wrap gap-2 text-xs">
                  <span className="px-2 py-1 bg-[var(--color-surface)] rounded">{track.duration}</span>
                  <span className="px-2 py-1 bg-[var(--color-surface)] rounded">{track.bpm} BPM</span>
                  {track.hasInstrumental && (
                    <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded">Instrumental ✓</span>
                  )}
                  {track.hasClean && (
                    <span className="px-2 py-1 bg-blue-500/20 text-blue-400 rounded">Clean ✓</span>
                  )}
                  {!track.released && (
                    <span className="px-2 py-1 bg-orange-500/20 text-orange-400 rounded">Unreleased</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <div className="mb-4">
            <h3 className="text-xl font-bold">Recent Activity</h3>
            <p className="text-sm text-[var(--color-text-secondary)]">Your pitch history</p>
          </div>
          <div className="space-y-3">
            {recentActivity.map((activity, index) => (
              <div key={index} className="p-4 bg-[var(--color-background)] rounded-lg border border-[var(--color-border)]">
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    activity.type === 'approved' ? 'bg-green-500/20' :
                    activity.type === 'submitted' ? 'bg-blue-500/20' :
                    'bg-red-500/20'
                  }`}>
                    {activity.type === 'approved' && <CheckCircle className="w-4 h-4 text-green-400" />}
                    {activity.type === 'submitted' && <Clock className="w-4 h-4 text-blue-400" />}
                    {activity.type === 'rejected' && <Target className="w-4 h-4 text-red-400" />}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium">{activity.target}</h4>
                    <p className="text-sm text-[var(--color-text-secondary)]">{activity.result}</p>
                    <p className="text-xs text-[var(--color-text-secondary)] mt-1">{activity.date}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
