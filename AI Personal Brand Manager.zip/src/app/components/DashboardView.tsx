import { TrendingUp, Users, Music, Eye, Instagram, Youtube, Music2, Target, Zap, Award } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

export default function DashboardView() {
  const stats = [
    { label: 'Total Followers', value: '47.2K', change: '+12.3%', trend: '+5.8K this month', icon: Users, color: 'purple' },
    { label: 'Engagement Rate', value: '8.4%', change: '+2.1%', trend: 'Above 6.5% avg', icon: TrendingUp, color: 'pink' },
    { label: 'Monthly Streams', value: '125K', change: '+18.5%', trend: '+19.5K from last month', icon: Music, color: 'blue' },
    { label: 'Content Views', value: '342K', change: '+15.2%', trend: '+45K this week', icon: Eye, color: 'green' },
  ];

  const engagementData = [
    { day: 'Mon', engagement: 6.2, projected: 8.5 },
    { day: 'Tue', engagement: 7.8, projected: 9.2 },
    { day: 'Wed', engagement: 6.5, projected: 8.8 },
    { day: 'Thu', engagement: 8.9, projected: 10.5 },
    { day: 'Fri', engagement: 9.2, projected: 11.0 },
    { day: 'Sat', engagement: 11.5, projected: 13.2 },
    { day: 'Sun', engagement: 10.3, projected: 12.1 },
  ];

  const platformData = [
    { platform: 'Instagram', followers: 18500, growth: '+8%', color: '#E1306C' },
    { platform: 'TikTok', followers: 22300, growth: '+15%', color: '#000000' },
    { platform: 'Spotify', followers: 4200, growth: '+22%', color: '#1DB954' },
    { platform: 'YouTube', followers: 2200, growth: '+12%', color: '#FF0000' },
  ];

  const recentPosts = [
    {
      platform: 'instagram',
      content: 'New single "Midnight Vibes" drops Friday! 🎵',
      engagement: '2.4K likes • 187 comments',
      performance: 'Outperforming by 23%',
      time: '2 hours ago',
    },
    {
      platform: 'tiktok',
      content: 'Behind the scenes of the music video shoot 🎬',
      engagement: '8.9K views • 542 likes',
      performance: 'Top 10% of your content',
      time: '5 hours ago',
    },
    {
      platform: 'youtube',
      content: 'Studio session: Creating "Midnight Vibes" from scratch',
      engagement: '3.2K views • 241 likes',
      performance: 'Average performance',
      time: '1 day ago',
    },
  ];

  const quickWins = [
    {
      title: 'Post at 7:30 PM tonight',
      description: 'Peak engagement window - 11.5% avg',
      impact: 'High',
    },
    {
      title: 'Use purple/pink in next post',
      description: '23% better engagement with brand colors',
      impact: 'High',
    },
    {
      title: 'Reply to all comments ASAP',
      description: '32/50 done - boost to 100% for algorithm',
      impact: 'Medium',
    },
  ];

  const growthProjection = [
    { month: 'Jan', actual: 38000 },
    { month: 'Feb', actual: 40200 },
    { month: 'Mar', actual: 42100 },
    { month: 'Apr', actual: 44800 },
    { month: 'May', actual: 47234 },
    { month: 'Jun', projected: 51500 },
    { month: 'Jul', projected: 56200 },
    { month: 'Aug', projected: 61800 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Welcome back, Jordan!</h2>
          <p className="text-[var(--color-text-secondary)] mt-1">Here's what's happening with your music</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-[var(--color-text-secondary)]">Monthly Growth Target</p>
          <p className="text-2xl font-bold text-green-400">+25-30%</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6 hover:border-purple-500/50 transition-colors">
              <div className="flex items-center justify-between mb-2">
                <Icon className={`w-5 h-5 text-${stat.color}-500`} />
                <span className="text-sm text-green-500 font-medium">{stat.change}</span>
              </div>
              <p className="text-3xl font-bold">{stat.value}</p>
              <p className="text-sm text-[var(--color-text-secondary)] mt-1">{stat.label}</p>
              <p className="text-xs text-[var(--color-text-secondary)] mt-2">{stat.trend}</p>
            </div>
          );
        })}
      </div>

      <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <Zap className="w-5 h-5 text-yellow-500" />
          <h3 className="text-xl font-bold">Quick Wins for Today</h3>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {quickWins.map((win, index) => (
            <div key={index} className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
              <div className="flex items-start justify-between mb-2">
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  win.impact === 'High' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'
                }`}>
                  {win.impact} Impact
                </span>
              </div>
              <h4 className="font-bold mb-1">{win.title}</h4>
              <p className="text-sm text-[var(--color-text-secondary)]">{win.description}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <div className="mb-4">
            <h3 className="text-xl font-bold">This Week's Engagement</h3>
            <p className="text-sm text-[var(--color-text-secondary)]">You're trending up! Keep it going</p>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={engagementData}>
              <defs>
                <linearGradient id="colorEngagement" x1="0" y1="0" x2="0" y2="1">
                  <stop key="engagement-stop-1" offset="5%" stopColor="#a855f7" stopOpacity={0.3}/>
                  <stop key="engagement-stop-2" offset="95%" stopColor="#a855f7" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorProjected" x1="0" y1="0" x2="0" y2="1">
                  <stop key="projected-stop-1" offset="5%" stopColor="#ec4899" stopOpacity={0.3}/>
                  <stop key="projected-stop-2" offset="95%" stopColor="#ec4899" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid key="area-grid" strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis key="area-xaxis" dataKey="day" stroke="var(--color-text-secondary)" />
              <YAxis key="area-yaxis" stroke="var(--color-text-secondary)" />
              <Tooltip
                key="area-tooltip"
                contentStyle={{
                  backgroundColor: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px'
                }}
              />
              <Area key="engagement-area" type="monotone" dataKey="engagement" stroke="#a855f7" fillOpacity={1} fill="url(#colorEngagement)" strokeWidth={2} />
              <Area key="projected-area" type="monotone" dataKey="projected" stroke="#ec4899" fillOpacity={1} fill="url(#colorProjected)" strokeWidth={2} strokeDasharray="5 5" />
            </AreaChart>
          </ResponsiveContainer>
          <div className="flex items-center justify-center gap-6 mt-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-purple-500 rounded-full" />
              <span className="text-xs text-[var(--color-text-secondary)]">Current</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-pink-500 rounded-full" />
              <span className="text-xs text-[var(--color-text-secondary)]">Projected</span>
            </div>
          </div>
        </div>

        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <h3 className="text-xl font-bold mb-4">Followers by Platform</h3>
          <div className="space-y-4">
            {platformData.map((platform) => (
              <div key={platform.platform}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: platform.color }} />
                    <span className="font-medium">{platform.platform}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold">{platform.followers.toLocaleString()}</span>
                    <span className="text-sm text-green-500 ml-2">{platform.growth}</span>
                  </div>
                </div>
                <div className="h-2 bg-[var(--color-background)] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${(platform.followers / 22300) * 100}%`,
                      backgroundColor: platform.color
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <div className="mb-4">
          <h3 className="text-xl font-bold">Where You're Heading</h3>
          <p className="text-sm text-[var(--color-text-secondary)]">Growth trajectory for the next 3 months</p>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={growthProjection}>
            <CartesianGrid key="line-grid" strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis key="line-xaxis" dataKey="month" stroke="var(--color-text-secondary)" />
            <YAxis key="line-yaxis" stroke="var(--color-text-secondary)" />
            <Tooltip
              key="line-tooltip"
              contentStyle={{
                backgroundColor: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: '8px'
              }}
            />
            <Line key="actual-line" type="monotone" dataKey="actual" stroke="#a855f7" strokeWidth={3} dot={{ fill: '#a855f7', r: 4 }} />
            <Line key="projected-line" type="monotone" dataKey="projected" stroke="#ec4899" strokeWidth={3} strokeDasharray="5 5" dot={{ fill: '#ec4899', r: 4 }} />
          </LineChart>
        </ResponsiveContainer>
        <div className="flex items-center justify-center gap-6 mt-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-purple-500 rounded-full" />
            <span className="text-xs text-[var(--color-text-secondary)]">Current Growth</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-pink-500 rounded-full" />
            <span className="text-xs text-[var(--color-text-secondary)]">With Our Strategies</span>
          </div>
        </div>
        <p className="text-sm text-center text-green-400 font-medium mt-4">
          Potential to reach 61.8K followers by August
        </p>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <div className="mb-4">
          <h3 className="text-xl font-bold">Your Recent Posts</h3>
          <p className="text-sm text-[var(--color-text-secondary)]">See how your content is performing</p>
        </div>
        <div className="space-y-4">
          {recentPosts.map((post, index) => (
            <div key={index} className="flex items-start gap-4 p-4 bg-[var(--color-background)] rounded-lg hover:bg-[var(--color-surface-hover)] transition-colors">
              <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center">
                {post.platform === 'instagram' && <Instagram className="w-5 h-5 text-purple-500" />}
                {post.platform === 'tiktok' && <Music2 className="w-5 h-5 text-purple-500" />}
                {post.platform === 'youtube' && <Youtube className="w-5 h-5 text-purple-500" />}
              </div>
              <div className="flex-1">
                <p className="font-medium">{post.content}</p>
                <p className="text-sm text-[var(--color-text-secondary)] mt-1">{post.engagement}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    post.performance.includes('Outperforming') || post.performance.includes('Top')
                      ? 'bg-green-500/20 text-green-400'
                      : 'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {post.performance}
                  </span>
                  <span className="text-xs text-[var(--color-text-secondary)]">{post.time}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
