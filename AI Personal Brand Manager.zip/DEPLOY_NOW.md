# Deploy ArtistOS to Web - Quick Guide

## Your app is ready! Follow these steps:

### 1️⃣ Upload to GitHub

**If you're in Claude Code:**
- Download all files from `/workspaces/default/code/`
- Save them to a folder on your computer called `artistos`

**Then upload to GitHub:**

```bash
# Open Terminal/Command Prompt in your artistos folder
cd path/to/your/artistos/folder

# Initialize git
git init

# Add all files
git add .

# Create first commit
git commit -m "Initial commit - ArtistOS by Juan Manuel Kornisiuk"

# Connect to GitHub (replace YOUR-USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR-USERNAME/artistos.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### 2️⃣ Deploy to Vercel (Free Hosting)

1. Go to [vercel.com](https://vercel.com)
2. Click **"Sign Up"** → Choose **"Continue with GitHub"**
3. Once logged in, click **"Add New..."** → **"Project"**
4. Find your `artistos` repository and click **"Import"**
5. Vercel auto-detects settings:
   - Framework: Vite ✅
   - Build Command: `pnpm run build` ✅
   - Output Directory: `dist` ✅
6. Click **"Deploy"**

**⏱️ Wait 2-3 minutes...**

✅ **Done!** Your app will be live at: `https://artistos-yourname.vercel.app`

---

**Created by:** Juan Manuel Kornisiuk
**Email:** juanmanuelkornisiuk@gmail.com

© 2026 Juan Manuel Kornisiuk. All Rights Reserved.
