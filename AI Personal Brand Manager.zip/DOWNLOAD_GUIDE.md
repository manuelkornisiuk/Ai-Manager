# 📥 How to Download ArtistOS

## Quick Download Guide

### Step 1: Export from Figma Make / This Workspace

**Option A: Use File Manager (Easiest)**
1. Look for a "Download" or "Export" button in the Figma Make interface
2. Select "Download Project" or "Export Files"
3. All files will be downloaded as a ZIP file
4. Extract the ZIP to a folder called `artistos` on your computer

**Option B: Copy Files Manually**
If there's a file explorer in the interface:
1. Navigate to `/workspaces/default/code/`
2. Select all files and folders
3. Right-click → Download or Export
4. Save to your computer in a folder called `artistos`

**Option C: Use Terminal/Command (Advanced)**
If you have terminal access:
```bash
# Navigate to the code directory
cd /workspaces/default/code

# Create a zip of everything
zip -r artistos.zip .

# Download the artistos.zip file
```

---

## What You Should Have Downloaded

Your `artistos` folder should contain:

```
artistos/
├── src/                          # All source code
│   ├── app/
│   │   ├── components/          # All UI components
│   │   │   ├── DashboardView.tsx
│   │   │   ├── PitchingView.tsx
│   │   │   ├── Navigation.tsx
│   │   │   └── ... (15+ components)
│   │   ├── context/
│   │   │   └── ThemeContext.tsx
│   │   └── App.tsx              # Main app file
│   ├── styles/
│   │   ├── theme.css
│   │   └── fonts.css
│   └── imports/
├── node_modules/                 # (Can ignore - will reinstall)
├── package.json                  # Dependencies
├── package-lock.json or pnpm-lock.yaml
├── vite.config.ts               # Build config
├── tsconfig.json                # TypeScript config
├── vercel.json                  # Vercel deployment config
├── .gitignore                   # Git exclusions
├── .vercelignore               # Vercel exclusions
├── README.md                    # Project documentation
├── COPYRIGHT                    # Your copyright notice
├── SECURITY_NOTICE.md          # Security documentation
├── DEPLOYMENT.md               # Deployment guide
├── DEPLOY_NOW.md               # Quick deploy guide
└── DOWNLOAD_GUIDE.md           # This file
```

**Total files: ~80+**

---

## Verify Your Download

1. Open the `artistos` folder
2. Check that you have:
   - ✅ `src` folder with `app` subfolder
   - ✅ `package.json` file
   - ✅ `vercel.json` file
   - ✅ `.gitignore` file
   - ✅ All `.md` documentation files

---

## Next Steps: Deploy to Vercel

Now that you have the files, follow these steps:

### 1️⃣ Upload to GitHub
```bash
cd path/to/artistos
git init
git add .
git commit -m "Initial commit - ArtistOS by Juan Manuel Kornisiuk"
git remote add origin https://github.com/YOUR-USERNAME/artistos.git
git push -u origin main
```

### 2️⃣ Deploy on Vercel
1. Go to [vercel.com](https://vercel.com)
2. Sign up with GitHub
3. Import your `artistos` repository
4. Click Deploy
5. Done! ✅

**See `DEPLOY_NOW.md` for complete step-by-step instructions.**

---

## Alternative: Run Locally First (Optional)

Want to test before deploying?

1. **Install dependencies:**
   ```bash
   cd artistos
   npm install
   # or
   pnpm install
   ```

2. **Run development server:**
   ```bash
   npm run dev
   # or
   pnpm run dev
   ```

3. **Open browser:**
   - Go to `http://localhost:5173`
   - You should see ArtistOS running!

4. **Build for production:**
   ```bash
   npm run build
   # or
   pnpm run build
   ```

---

## Troubleshooting Downloads

### ❌ Can't Find Download Button
- Check the top menu bar for Export/Download
- Look in Settings or File menu
- Try right-clicking on the project/workspace

### ❌ Downloaded File is Incomplete
- Make sure you selected the entire `/workspaces/default/code/` directory
- Check the ZIP file size (should be ~10-50 MB)
- Try downloading again

### ❌ No ZIP File Created
- Some systems may download individual files
- Manually create a folder and copy all files into it
- Make sure to maintain the folder structure

### ❌ Missing node_modules Folder
- This is NORMAL and expected
- Don't worry - you'll reinstall dependencies with `npm install`
- This folder is very large and excluded from downloads

---

## File Sizes Reference

- **With node_modules**: ~150-200 MB
- **Without node_modules**: ~2-5 MB (smaller, faster download)
- **Built app (dist/)**: ~1-2 MB

**You want the version WITHOUT node_modules** - it's smaller and you'll reinstall fresh dependencies later.

---

## Quick Checklist

- [ ] Downloaded all files from workspace
- [ ] Extracted to folder called `artistos`
- [ ] Verified `package.json` exists
- [ ] Verified `src/app/App.tsx` exists
- [ ] Verified `.gitignore` and `vercel.json` exist
- [ ] Ready to upload to GitHub
- [ ] Ready to deploy to Vercel

---

## Need Help?

- **Can't download files**: Check Figma Make documentation or support
- **Downloaded but missing files**: Make sure you selected the correct directory
- **Ready to deploy**: Follow `DEPLOY_NOW.md` step-by-step

---

**Next:** Once downloaded, follow `DEPLOY_NOW.md` to get your app live on Vercel!

© 2026 Juan Manuel Kornisiuk. All Rights Reserved.
