import { Palette, Music, Users, Target, TrendingUp, Sparkles, Zap, Award, MessageCircle } from 'lucide-react';

export default function BrandDNAView() {
  const brandProfile = {
    primaryGenre: 'Alternative Hip-Hop',
    visualStyle: 'Moody Aesthetic',
    brandArchetype: 'The Creator',
    archetypeDescription: 'You inspire through authentic self-expression and experimental music. Your audience connects with your creative journey and artistic vulnerability.',
    targetAudience: 'Gen Z Urban Creatives',
    audienceDetails: '18-24 years old (42% of your audience). They love music, fashion, and authentic content that feels real.',
    contentPillars: ['Behind-the-scenes', 'Lifestyle', 'Music Snippets', 'Creative Process'],
    contentStrategy: {
      'Behind-the-scenes': 40,
      'Music Snippets': 30,
      'Lifestyle': 20,
      'Educational': 10,
    },
    colorPalette: [
      { color: '#8B5CF6', name: 'Primary Purple', performance: '+23%' },
      { color: '#EC4899', name: 'Accent Pink', performance: '+23%' },
      { color: '#3B82F6', name: 'Highlight Blue', performance: '+12%' },
      { color: '#10B981', name: 'Success Green', performance: '+8%' },
    ],
    brandKeywords: ['authentic', 'raw', 'creative', 'experimental', 'moody'],
    voiceGuidelines: [
      'Vulnerable but confident',
      'Relatable but aspirational',
      'Focus on the journey, not just the destination',
    ],
  };

  const strengthAreas = [
    { area: 'Visual Consistency', score: 87, trend: 'up' },
    { area: 'Posting Frequency', score: 72, trend: 'up' },
    { area: 'Audience Engagement', score: 84, trend: 'stable' },
    { area: 'Content Variety', score: 65, trend: 'down' },
    { area: 'Brand Recognition', score: 78, trend: 'up' },
  ];

  const recommendations = [
    {
      title: 'Use Your Signature Colors',
      description: 'Purple/pink gradient posts get 23% more engagement. Use these colors in all your Stories and Reels thumbnails.',
      impact: 'High',
      priority: 'Urgent',
      category: 'branding',
    },
    {
      title: 'Balance Your Content Mix',
      description: 'Post 40% behind-the-scenes, 30% music clips, 20% lifestyle, 10% tips. This keeps your feed interesting without losing your identity.',
      impact: 'High',
      priority: 'Important',
      category: 'branding',
    },
    {
      title: 'Stay Authentic in Your Voice',
      description: 'Your vulnerable but confident style connects with Gen Z. Keep sharing your creative journey - the struggles and wins.',
      impact: 'Medium',
      priority: 'Important',
      category: 'branding',
    },
    {
      title: 'Post at the Right Times',
      description: 'Your audience is most active 6-9 PM EST. Post your best content during this window, especially Stories at 8 PM.',
      impact: 'High',
      priority: 'Urgent',
      category: 'growth',
    },
    {
      title: 'Reuse What Works',
      description: 'Test content on TikTok first, then post your winners to Instagram Reels within 48 hours. Same for YouTube Shorts.',
      impact: 'High',
      priority: 'Important',
      category: 'growth',
    },
    {
      title: 'Engage More With Fans',
      description: 'Reply to all comments in the first hour. Use polls in Stories. This builds loyalty and helps the algorithm boost your content.',
      impact: 'Medium',
      priority: 'Important',
      category: 'growth',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Your Brand DNA</h2>
        <p className="text-[var(--color-text-secondary)] mt-1">What makes you unique and how to amplify it</p>
      </div>

      <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-8">
        <div className="flex items-center gap-3 mb-6">
          <Sparkles className="w-8 h-8 text-purple-500" />
          <h3 className="text-2xl font-bold">Your Brand Identity</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Music className="w-5 h-5 text-purple-500" />
              <p className="font-medium text-sm text-[var(--color-text-secondary)]">Primary Genre</p>
            </div>
            <p className="text-lg font-bold">{brandProfile.primaryGenre}</p>
          </div>

          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Palette className="w-5 h-5 text-pink-500" />
              <p className="font-medium text-sm text-[var(--color-text-secondary)]">Visual Style</p>
            </div>
            <p className="text-lg font-bold">{brandProfile.visualStyle}</p>
          </div>

          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4 md:col-span-2">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-5 h-5 text-blue-500" />
              <p className="font-medium text-sm text-[var(--color-text-secondary)]">Brand Archetype</p>
            </div>
            <p className="text-lg font-bold mb-2">{brandProfile.brandArchetype}</p>
            <p className="text-sm text-[var(--color-text-secondary)]">{brandProfile.archetypeDescription}</p>
          </div>

          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4 md:col-span-2">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-5 h-5 text-green-500" />
              <p className="font-medium text-sm text-[var(--color-text-secondary)]">Target Audience</p>
            </div>
            <p className="text-lg font-bold mb-2">{brandProfile.targetAudience}</p>
            <p className="text-sm text-[var(--color-text-secondary)]">{brandProfile.audienceDetails}</p>
          </div>

          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4 md:col-span-2">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-purple-500" />
              <p className="font-medium text-sm text-[var(--color-text-secondary)]">Content Pillars</p>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {brandProfile.contentPillars.map((pillar) => (
                <span key={pillar} className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm font-medium">
                  {pillar}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-6">
          <p className="font-medium text-sm text-[var(--color-text-secondary)] mb-3">Brand Color Palette & Performance</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {brandProfile.colorPalette.map((item) => (
              <div key={item.color} className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
                <div
                  className="w-full h-16 rounded-lg shadow-lg mb-2"
                  style={{ backgroundColor: item.color }}
                />
                <p className="text-sm font-bold">{item.name}</p>
                <p className="text-xs font-mono text-[var(--color-text-secondary)]">{item.color}</p>
                <p className="text-xs text-green-400 font-medium mt-1">{item.performance} engagement</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <p className="font-medium text-sm text-[var(--color-text-secondary)] mb-3">Brand Keywords</p>
            <div className="flex flex-wrap gap-2">
              {brandProfile.brandKeywords.map((keyword) => (
                <span key={keyword} className="px-3 py-1 bg-[var(--color-surface)]/50 backdrop-blur rounded-full text-sm">
                  {keyword}
                </span>
              ))}
            </div>
          </div>
          <div>
            <p className="font-medium text-sm text-[var(--color-text-secondary)] mb-3">Brand Voice Guidelines</p>
            <div className="space-y-2">
              {brandProfile.voiceGuidelines.map((guideline, index) => (
                <div key={index} className="flex items-start gap-2">
                  <MessageCircle className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                  <span className="text-sm">{guideline}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-6">
          <p className="font-medium text-sm text-[var(--color-text-secondary)] mb-3">Content Strategy Distribution</p>
          <div className="space-y-3">
            {Object.entries(brandProfile.contentStrategy).map(([pillar, percentage]) => (
              <div key={pillar}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">{pillar}</span>
                  <span className="text-sm text-[var(--color-text-secondary)]">{percentage}%</span>
                </div>
                <div className="h-2 bg-[var(--color-surface)]/50 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <h3 className="text-xl font-bold mb-4">Strength Analysis</h3>
        <div className="space-y-4">
          {strengthAreas.map((item) => (
            <div key={item.area}>
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium">{item.area}</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold">{item.score}%</span>
                  {item.trend === 'up' && <TrendingUp className="w-4 h-4 text-green-500" />}
                  {item.trend === 'down' && <TrendingUp className="w-4 h-4 text-red-500 rotate-180" />}
                  {item.trend === 'stable' && <div className="w-4 h-0.5 bg-yellow-500" />}
                </div>
              </div>
              <div className="h-2 bg-[var(--color-background)] rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all"
                  style={{ width: `${item.score}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-5 h-5 text-yellow-500" />
            <h3 className="text-lg font-bold">Branding</h3>
          </div>
          <div className="space-y-3">
            {recommendations.filter(r => r.category === 'branding').map((rec, index) => (
              <div key={index} className="p-3 bg-[var(--color-background)] rounded-lg">
                <h4 className="font-bold text-sm mb-1">{rec.title}</h4>
                <p className="text-xs text-[var(--color-text-secondary)]">{rec.description}</p>
                <span className={`inline-block mt-2 px-2 py-1 rounded text-xs font-medium ${
                  rec.impact === 'High' ? 'bg-red-500/20 text-red-300' :
                  'bg-yellow-500/20 text-yellow-300'
                }`}>
                  {rec.impact} Impact
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <Zap className="w-5 h-5 text-purple-500" />
            <h3 className="text-lg font-bold">Growth</h3>
          </div>
          <div className="space-y-3">
            {recommendations.filter(r => r.category === 'growth').map((rec, index) => (
              <div key={index} className="p-3 bg-[var(--color-background)] rounded-lg">
                <h4 className="font-bold text-sm mb-1">{rec.title}</h4>
                <p className="text-xs text-[var(--color-text-secondary)]">{rec.description}</p>
                <span className={`inline-block mt-2 px-2 py-1 rounded text-xs font-medium ${
                  rec.priority === 'Urgent' ? 'bg-red-500/20 text-red-300' :
                  'bg-orange-500/20 text-orange-300'
                }`}>
                  {rec.priority}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-green-500" />
            <h3 className="text-lg font-bold">Growth Projection</h3>
          </div>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-[var(--color-text-secondary)] mb-1">Current Growth Rate</p>
              <p className="text-3xl font-bold text-green-400">+12.3%</p>
              <p className="text-xs text-[var(--color-text-secondary)] mt-1">monthly</p>
            </div>
            <div className="border-t border-green-500/20 pt-4">
              <p className="text-sm text-[var(--color-text-secondary)] mb-1">Projected Growth</p>
              <p className="text-3xl font-bold text-green-400">+25-30%</p>
              <p className="text-xs text-[var(--color-text-secondary)] mt-1">with recommendations applied</p>
            </div>
            <div className="border-t border-green-500/20 pt-4">
              <p className="text-sm text-[var(--color-text-secondary)] mb-1">Engagement Boost</p>
              <p className="text-2xl font-bold text-green-400">8.4% → 12-15%</p>
              <p className="text-xs text-[var(--color-text-secondary)] mt-1">estimated engagement rate</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
