# Security Policy

## Data Protection

ArtistOS is committed to protecting your data and privacy with industry-standard security measures.

### Security Features

- **End-to-End Encryption** - All data transmission uses TLS 1.3 encryption
- **Zero-Knowledge Architecture** - We cannot access your social media credentials
- **OAuth 2.0 Authentication** - Secure third-party platform connections
- **Data Encryption at Rest** - AES-256 encryption for stored data
- **Regular Security Audits** - Quarterly third-party security assessments
- **GDPR & CCPA Compliant** - Full compliance with data protection regulations
- **No Data Selling** - We never sell or share your personal data
- **Automatic Session Timeout** - Enhanced protection against unauthorized access
- **Two-Factor Authentication** - Optional 2FA for additional security

### What We Store

- Platform analytics (aggregated, anonymized when possible)
- Content performance metrics
- User preferences and settings
- Subscription information

### What We Don't Store

- Social media passwords (OAuth tokens only)
- Private messages or DMs
- Payment card details (handled by Stripe)
- Unpublished content drafts

### Data Retention

- Analytics data: Retained for 12 months
- Account data: Retained while subscription is active
- Deleted accounts: All data permanently deleted within 30 days

### Reporting Security Issues

If you discover a security vulnerability, please email: security@artistos.com

We take all reports seriously and will respond within 48 hours.

---

© 2026 Juan Manuel Kornisiuk. All Rights Reserved.
