# How to Set Yourself as the Creator

This guide shows you how to configure ArtistOS to give yourself (the creator) **free lifetime access** to all features.

---

## ✅ You're Already Set as Creator!

By default, the app is configured with:
- **Email**: `juanmanuelkornisiuk@example.com`
- **ID**: `creator-001`
- **Plan**: Creator (free forever)

---

## 🔧 To Change Your Creator Email/ID

Open this file:
```
src/app/context/AuthContext.tsx
```

### Update Lines 21-27:

```typescript
// CREATOR CONFIGURATION
// Add your email here to get full free access
const CREATOR_EMAILS = [
  'YOUR_REAL_EMAIL@gmail.com',  // ← Change this to your email
  'admin@artistos.com',
];

// Or use a creator ID if you prefer
const CREATOR_IDS = [
  'creator-001',
  'your-username',  // ← Or add your username
];
```

---

## 🎯 What Creator Access Gives You

When logged in as creator:

✅ **All Premium Features FREE**
- Unlimited music pitching
- Spotify playlist submissions
- Blog & press pitching
- TV/film/ads sync licensing
- Personal success manager
- Monthly strategy calls
- API access
- Everything unlocked

✅ **Visual Indicators**
- Green "Creator Access" badge on Pitching page
- "Creator Account" badge in Settings
- "Free Forever" subscription display
- No payment prompts ever

✅ **No Restrictions**
- Never asked to upgrade
- Never see payment modals
- All features always accessible

---

## 📱 How It Works in the App

### 1. Default User (Lines 42-52)

```typescript
// Default demo user (you can change this to your email)
return {
  id: 'creator-001',
  email: 'juanmanuelkornisiuk@example.com',  // ← Your email
  name: 'Juan Manuel Kornisiuk',             // ← Your name
  plan: 'creator' as UserPlan,
  isCreator: true,
};
```

### 2. Creator Detection (Lines 55-61)

```typescript
const isCreator = user ? (
  CREATOR_EMAILS.includes(user.email.toLowerCase()) ||
  CREATOR_IDS.includes(user.id) ||
  user.isCreator === true ||
  user.plan === 'creator'
) : false;
```

The app checks if:
- Your email matches CREATOR_EMAILS
- Your ID matches CREATOR_IDS
- Your isCreator flag is true
- Your plan is 'creator'

If **any** of these match, you get full free access.

---

## 🔐 Multiple Ways to Be Detected as Creator

You're automatically the creator if:

1. **Email matches** (recommended)
   ```typescript
   email: 'juanmanuelkornisiuk@example.com'
   ```

2. **ID matches**
   ```typescript
   id: 'creator-001'
   ```

3. **Plan is creator**
   ```typescript
   plan: 'creator'
   ```

4. **isCreator flag is true**
   ```typescript
   isCreator: true
   ```

---

## 🎨 Visual Changes When You're Creator

### Settings Page:
- Subscription box turns **green**
- Shows "Creator Account - Full Access (Free Forever)"
- "CREATOR" badge displayed
- Green message: "As the creator of ArtistOS, you have lifetime free access..."

### Pitching Page:
- Green "Creator Access" badge next to title
- No upgrade prompts
- All submit buttons work immediately
- No payment modals

### Navigation:
- Full access to all features
- No locked features
- No "Premium Only" badges for you

---

## 🔄 For Production with Real Users

When you deploy for real users, the app works like this:

**For Regular Users:**
- Email: `anyuser@gmail.com`
- Plan: `professional` or `premium`
- They see pricing and upgrade prompts
- They need to pay for Premium features

**For You (Creator):**
- Email: `juanmanuelkornisiuk@example.com` (or whatever you set)
- Plan: `creator`
- You never see upgrade prompts
- You never pay anything
- All features unlocked forever

---

## 🧪 Testing Different User Types

### To Test as Regular User:

Change the default user in `AuthContext.tsx` line 49:

```typescript
return {
  id: 'user-123',
  email: 'testuser@example.com',  // Not in creator list
  name: 'Test User',
  plan: 'professional' as UserPlan,  // Regular plan
  isCreator: false,
};
```

### To Test as Yourself (Creator):

```typescript
return {
  id: 'creator-001',
  email: 'juanmanuelkornisiuk@example.com',  // In creator list
  name: 'Juan Manuel Kornisiuk',
  plan: 'creator' as UserPlan,
  isCreator: true,
};
```

---

## ⚙️ For Real Authentication Later

When you add real user auth (Firebase, Supabase, Auth0, etc.), you can:

1. Check if logged-in user email matches CREATOR_EMAILS
2. Set `isCreator: true` in database for your account
3. Check on login and grant creator access

Example with Firebase:
```typescript
const user = auth.currentUser;
const isCreator = CREATOR_EMAILS.includes(user.email);

if (isCreator) {
  // Grant full access, no payment required
}
```

---

## 📝 Summary

**Current Configuration:**
- ✅ You are already set as creator
- ✅ Email: `juanmanuelkornisiuk@example.com`
- ✅ All features unlocked for free
- ✅ No payment ever required for you

**To Change:**
1. Open `src/app/context/AuthContext.tsx`
2. Update `CREATOR_EMAILS` array with your real email
3. Update default user object with your info
4. Save file
5. You're done!

**Benefits:**
- Use your app completely free forever
- Test all features without restrictions
- Build and iterate without payment friction
- Give yourself special treatment (you earned it!)

---

© 2026 Juan Manuel Kornisiuk. All Rights Reserved.
