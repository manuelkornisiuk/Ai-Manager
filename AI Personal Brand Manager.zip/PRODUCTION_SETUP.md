# ArtistOS Production Infrastructure Setup

Complete guide for setting up the production-ready ArtistOS platform with Supabase, Stripe, and Resend.

## Quick Start Checklist

- [ ] Supabase project created
- [ ] Database schema deployed
- [ ] Stripe products configured
- [ ] Resend account set up
- [ ] Environment variables configured
- [ ] Local development tested
- [ ] Production deployed to Vercel
- [ ] Webhooks configured

---

## 1. Supabase Database Setup

### Create Project

1. Go to [supabase.com](https://supabase.com) → **New Project**
2. Fill in details:
   - Name: `artistos`
   - Database Password: (generate strong password)
   - Region: (closest to your users)
3. Wait for project to spin up (~2 minutes)

### Get Credentials

1. Go to **Settings** → **API**
2. Copy these values:
   ```
   Project URL: https://xxxxx.supabase.co
   anon public key: eyJ...
   ```

### Deploy Database Schema

1. Go to **SQL Editor** in Supabase
2. Click **New Query**
3. Copy entire `supabase/schema.sql` file
4. Paste and click **Run**
5. Verify tables created in **Table Editor**:
   - profiles
   - subscriptions
   - brand_dna
   - content_ideas
   - video_scenarios
   - playlist_pitches
   - curator_contacts
   - analytics_history
   - scheduled_posts
   - email_notifications

### Configure Authentication

1. **Authentication** → **Providers** → Ensure **Email** is enabled
2. **Authentication** → **URL Configuration**:
   - Site URL: `http://localhost:5173` (dev) or your domain (prod)
   - Redirect URLs: Add both:
     - `http://localhost:5173/**`
     - `https://your-production-domain.com/**`
3. **Authentication** → **Email Templates**:
   - Customize "Confirm Signup" template (optional)
   - Customize "Reset Password" template (optional)

---

## 2. Stripe Payment Processing

### Create Account & Products

1. Sign up at [stripe.com](https://stripe.com)
2. Stay in **Test Mode** for development
3. Go to **Products** → **Add Product**

#### Create Monthly Plan
- **Name**: ArtistOS Monthly
- **Description**: All Professional features
- **Price**: $15.00 USD
- **Billing**: Recurring monthly
- **Copy Price ID**: `price_xxxxx`

#### Create Quarterly Plan
- **Name**: ArtistOS Quarterly
- **Description**: Save 13% with quarterly billing
- **Price**: $39.00 USD
- **Billing**: Recurring every 3 months
- **Copy Price ID**: `price_xxxxx`

#### Create Annual Plan
- **Name**: ArtistOS Annual
- **Description**: Save 20% with annual billing
- **Price**: $144.00 USD
- **Billing**: Recurring yearly
- **Copy Price ID**: `price_xxxxx`

### Get API Keys

1. Go to **Developers** → **API keys**
2. Copy:
   - **Publishable key**: `pk_test_xxxxx` (test mode)
   - **Secret key**: `sk_test_xxxxx` (test mode)

### Webhooks (After Deployment)

Will be configured after production deployment:
- Endpoint: `https://your-domain.com/api/stripe-webhook`
- Events: 
  - `checkout.session.completed`
  - `customer.subscription.created`
  - `customer.subscription.updated`
  - `customer.subscription.deleted`
  - `invoice.payment_succeeded`
  - `invoice.payment_failed`

---

## 3. Resend Email Service

### Create Account

1. Go to [resend.com](https://resend.com)
2. Sign up (free: 3,000 emails/month)

### Get API Key

1. Go to **API Keys**
2. Click **Create API Key**
3. Name: `artistos-production`
4. Permission: **Sending access**
5. Copy key: `re_xxxxx`

### Domain Setup (Optional, Recommended for Production)

1. Go to **Domains** → **Add Domain**
2. Enter domain: `artistos.com`
3. Add DNS records shown
4. Wait for verification

**For Development**: Use `onboarding@resend.dev` without domain setup

---

## 4. Environment Configuration

### Create `.env.local` File

```env
# Supabase Configuration
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Stripe Configuration (Test Mode)
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_51xxxxx
STRIPE_SECRET_KEY=sk_test_51xxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxx

# Stripe Price IDs
VITE_STRIPE_MONTHLY_PRICE_ID=price_xxxxx
VITE_STRIPE_QUARTERLY_PRICE_ID=price_xxxxx
VITE_STRIPE_ANNUAL_PRICE_ID=price_xxxxx

# Resend Email Service
RESEND_API_KEY=re_xxxxx
FROM_EMAIL=onboarding@resend.dev

# App Configuration
VITE_APP_URL=http://localhost:5173
VITE_APP_NAME=ArtistOS

# Creator Configuration
CREATOR_EMAIL=juanmanuelkornisiuk@gmail.com
```

---

## 5. Local Development Testing

### Install & Start

```bash
# Install dependencies
pnpm install

# Start dev server
pnpm dev
```

### Test Authentication Flow

1. **Sign Up**:
   - Email: `test@example.com`
   - Password: `testpass123`
   - Verify user created in Supabase

2. **Sign In/Out**:
   - Test signing out
   - Test signing back in

3. **Creator Access**:
   - Sign up with `juanmanuelkornisiuk@gmail.com`
   - Verify "Creator" badge appears
   - Check subscription = "creator" in database

### Test Payment Flow

1. Navigate to **Pricing** page
2. Select any plan
3. Use Stripe test card:
   - Card: `4242 4242 4242 4242`
   - Expiry: Any future date
   - CVC: Any 3 digits
4. Complete checkout
5. Verify subscription created in database

### Test Email Notifications

1. Trigger welcome email (new signup)
2. Test password reset flow
3. Check emails arrive in inbox
4. Verify email rendering

---

## 6. Production Deployment to Vercel

### Prepare Repository

```bash
# Initialize git
git init

# Add all files
git add .

# Create commit
git commit -m "Initial commit: ArtistOS production ready"

# Create GitHub repo and push
git remote add origin https://github.com/YOUR-USERNAME/artistos.git
git branch -M main
git push -u origin main
```

### Deploy to Vercel

1. Go to [vercel.com](https://vercel.com)
2. Click **Add New Project**
3. Import your GitHub repository
4. Configure:
   - **Framework**: Vite
   - **Build Command**: `pnpm build`
   - **Output Directory**: `dist`
   - **Install Command**: `pnpm install`

### Add Environment Variables

In Vercel **Settings** → **Environment Variables**, add:

```env
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_... (or pk_live_ for production)
STRIPE_SECRET_KEY=sk_test_... (or sk_live_ for production)
VITE_STRIPE_MONTHLY_PRICE_ID=...
VITE_STRIPE_QUARTERLY_PRICE_ID=...
VITE_STRIPE_ANNUAL_PRICE_ID=...
RESEND_API_KEY=...
FROM_EMAIL=noreply@artistos.com (or your verified domain)
VITE_APP_URL=https://your-app.vercel.app
VITE_APP_NAME=ArtistOS
CREATOR_EMAIL=juanmanuelkornisiuk@gmail.com
```

### Deploy

Click **Deploy** and wait 2-3 minutes.

### Update Supabase URLs

1. Go to Supabase **Authentication** → **URL Configuration**
2. Add production URL:
   - `https://your-app-name.vercel.app/**`

### Configure Stripe Webhooks

1. Go to Stripe **Developers** → **Webhooks**
2. **Add Endpoint**: `https://your-app-name.vercel.app/api/stripe-webhook`
3. Select events listed above
4. Copy **Signing Secret**: `whsec_xxxxx`
5. Add to Vercel environment variables: `STRIPE_WEBHOOK_SECRET`
6. Redeploy

---

## 7. Post-Deployment Testing

### Test Production App

1. **User Registration**:
   - Sign up with real email
   - Check email verification
   - Verify profile in Supabase

2. **Creator Access**:
   - Sign up with `juanmanuelkornisiuk@gmail.com`
   - Verify creator features unlocked

3. **Payment Flow**:
   - Purchase subscription (use test card in test mode)
   - Verify webhook received
   - Check subscription status in database

4. **Email Delivery**:
   - Trigger various emails
   - Verify delivery in Resend dashboard

### Monitor Services

- **Supabase**: Database usage, auth logs
- **Stripe**: Payments, subscription status
- **Resend**: Email delivery, open rates
- **Vercel**: Traffic, errors, logs

---

## 8. Going Live (Test Mode → Live Mode)

When ready for real customers:

### Switch Stripe to Live Mode

1. In Stripe Dashboard, toggle to **Live mode**
2. Create new products (same as test mode)
3. Get live API keys:
   - `pk_live_xxxxx`
   - `sk_live_xxxxx`
4. Update Vercel environment variables with live keys
5. Update webhook endpoint in live mode
6. Redeploy

### Verify Production Setup

- Use real credit card for test purchase
- Verify payment processes correctly
- Confirm emails send to real addresses
- Test all critical user flows

---

## Troubleshooting

### Authentication Issues

- Verify Supabase URL and anon key
- Check site URL configuration
- Review auth logs in Supabase

### Payment Failures

- Verify Stripe keys are correct
- Check Price IDs match products
- Review Stripe logs for errors
- Ensure webhook signing secret is set

### Email Not Sending

- Check Resend API key
- Verify FROM_EMAIL domain
- Review Resend logs
- Check spam folder

### Database Errors

- Verify RLS policies enabled
- Check user authentication
- Review Supabase logs

---

## Security Checklist

- [ ] Never commit `.env.local` to git
- [ ] Use different API keys for dev/prod
- [ ] Enable Supabase RLS (already configured)
- [ ] Verify Stripe webhook signatures
- [ ] Use HTTPS only in production
- [ ] Rotate API keys periodically
- [ ] Enable database backups
- [ ] Monitor for suspicious activity
- [ ] Keep dependencies updated

---

## Next Steps

After successful deployment:

1. Add custom domain in Vercel
2. Set up monitoring (Sentry, LogRocket)
3. Configure analytics (Google Analytics, Mixpanel)
4. Create user documentation
5. Plan marketing launch
6. Set up customer support
7. Build analytics dashboard
8. Create automated backups
9. Plan feature roadmap
10. Celebrate! 🎉

---

**Creator**: Juan Manuel Kornisiuk
**Email**: juanmanuelkornisiuk@gmail.com
**Project**: ArtistOS - Your AI Manager

© 2026 Juan Manuel Kornisiuk. All Rights Reserved.
