import { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Instagram, Music2, Youtube, Clock, AlertCircle, X, Calendar, Send } from 'lucide-react';
import SocialMediaComposer from './SocialMediaComposer';

interface ScheduledPost {
  id: number;
  date: string;
  time: string;
  platform: 'instagram' | 'tiktok' | 'youtube';
  type: string;
  title: string;
  status: 'scheduled' | 'draft' | 'posted';
  optimalTime: boolean;
  engagement: string;
  suggestion?: string;
}

export default function ScheduleView() {
  const [currentDate, setCurrentDate] = useState(new Date(2026, 5, 4));
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showComposer, setShowComposer] = useState(false);
  const [newPost, setNewPost] = useState({
    title: '',
    platform: 'instagram' as 'instagram' | 'tiktok' | 'youtube',
    type: 'Reel',
    date: '',
    time: '',
  });

  const [scheduledPosts, setScheduledPosts] = useState([
    {
      id: 1,
      date: '2026-06-04',
      time: '19:30',
      platform: 'tiktok' as 'instagram' | 'tiktok' | 'youtube',
      type: 'Video',
      title: 'Beat Breakdown: Studio Session',
      status: 'scheduled' as 'scheduled' | 'draft' | 'posted',
      optimalTime: true,
      engagement: '12-15K views',
    },
    {
      id: 2,
      date: '2026-06-05',
      time: '18:00',
      platform: 'instagram' as 'instagram' | 'tiktok' | 'youtube',
      type: 'Reel',
      title: 'Behind the scenes music video',
      status: 'scheduled' as 'scheduled' | 'draft' | 'posted',
      optimalTime: true,
      engagement: '5-7K views',
    },
    {
      id: 3,
      date: '2026-06-06',
      time: '20:00',
      platform: 'instagram' as 'instagram' | 'tiktok' | 'youtube',
      type: 'Story',
      title: 'Album cover poll - Interactive',
      status: 'scheduled' as 'scheduled' | 'draft' | 'posted',
      optimalTime: true,
      engagement: '2-3K votes',
    },
    {
      id: 4,
      date: '2026-06-07',
      time: '14:00',
      platform: 'youtube' as 'instagram' | 'tiktok' | 'youtube',
      type: 'Video',
      title: 'Day in the life vlog',
      status: 'scheduled' as 'scheduled' | 'draft' | 'posted',
      optimalTime: false,
      engagement: '8-10K views',
      suggestion: 'Move to 6-9 PM for +30% engagement',
    },
    {
      id: 5,
      date: '2026-06-08',
      time: '19:00',
      platform: 'tiktok' as 'instagram' | 'tiktok' | 'youtube',
      type: 'Video',
      title: 'New single teaser - Midnight Vibes',
      status: 'scheduled' as 'scheduled' | 'draft' | 'posted',
      optimalTime: true,
      engagement: '15-20K views',
    },
    {
      id: 6,
      date: '2026-06-09',
      time: '18:00',
      platform: 'instagram' as 'instagram' | 'tiktok' | 'youtube',
      type: 'Carousel',
      title: 'Visual Vibes: Lyrics + Aesthetic',
      status: 'draft' as 'scheduled' | 'draft' | 'posted',
      optimalTime: true,
      engagement: '5-7K likes',
    },
  ]);

  const handleSchedulePost = () => {
    if (!newPost.title?.trim() || !newPost.date || !newPost.time) {
      alert('Please fill in all required fields');
      return;
    }

    if (!newPost.platform) {
      alert('Please select a platform');
      return;
    }

    const hour = parseInt(newPost.time.split(':')[0]);
    const isOptimalTime = (newPost.platform === 'instagram' || newPost.platform === 'tiktok')
      ? (hour >= 18 && hour <= 21)
      : (hour >= 14 && hour <= 20);

    const estimatedEngagement = newPost.platform === 'instagram'
      ? '5-8K views'
      : newPost.platform === 'tiktok'
      ? '15-25K views'
      : '8-12K views';

    const post: ScheduledPost = {
      id: Date.now(),
      title: newPost.title,
      platform: newPost.platform,
      type: newPost.type,
      date: newPost.date,
      time: newPost.time,
      status: 'scheduled',
      optimalTime: isOptimalTime,
      engagement: estimatedEngagement,
      suggestion: !isOptimalTime ? `Move to ${newPost.platform === 'youtube' ? '2-8 PM' : '6-9 PM'} for better engagement` : undefined,
    };

    setScheduledPosts([...scheduledPosts, post].sort((a, b) => {
      const dateA = new Date(`${a.date}T${a.time}`);
      const dateB = new Date(`${b.date}T${b.time}`);
      return dateA.getTime() - dateB.getTime();
    }));

    setNewPost({
      title: '',
      platform: 'instagram',
      type: 'Reel',
      date: '',
      time: '',
    });
    setShowScheduleModal(false);
  };

  const getContentTypes = (platform: string) => {
    switch (platform) {
      case 'instagram':
        return ['Reel', 'Post', 'Story', 'Carousel'];
      case 'tiktok':
        return ['Video', 'Live'];
      case 'youtube':
        return ['Video', 'Short', 'Live'];
      default:
        return ['Video'];
    }
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i);
    }
    return days;
  };

  const getPostsForDay = (day: number) => {
    const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return scheduledPosts.filter(post => post.date === dateStr);
  };

  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const days = getDaysInMonth(currentDate);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Content Schedule</h2>
          <p className="text-[var(--color-text-secondary)] mt-1">Plan and schedule your posts across all platforms.</p>
        </div>
        <button
          onClick={() => setShowComposer(true)}
          className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-bold transition-all flex items-center gap-2"
        >
          <Send className="w-5 h-5" />
          Create Post
        </button>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold">
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h3>
          <div className="flex gap-2">
            <button
              onClick={previousMonth}
              className="p-2 hover:bg-[var(--color-surface-hover)] rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={nextMonth}
              className="p-2 hover:bg-[var(--color-surface-hover)] rounded-lg transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {dayNames.map((day) => (
            <div key={day} className="text-center font-medium text-sm text-[var(--color-text-secondary)] py-2">
              {day}
            </div>
          ))}

          {days.map((day, index) => {
            if (day === null) {
              return <div key={`empty-${index}`} className="aspect-square" />;
            }

            const posts = getPostsForDay(day);
            const isToday = day === 4 && currentDate.getMonth() === 5;

            return (
              <div
                key={day}
                className={`aspect-square border border-[var(--color-border)] rounded-lg p-2 ${
                  isToday ? 'bg-purple-500/10 border-purple-500' : 'bg-[var(--color-background)]'
                }`}
              >
                <div className="flex flex-col h-full">
                  <span className={`text-sm font-medium ${isToday ? 'text-purple-400' : ''}`}>
                    {day}
                  </span>
                  <div className="flex-1 mt-1 space-y-1">
                    {posts.slice(0, 2).map((post) => (
                      <div
                        key={post.id}
                        className="text-xs p-1 bg-purple-500/20 rounded flex items-center gap-1"
                      >
                        {post.platform === 'instagram' && <Instagram className="w-3 h-3" />}
                        {post.platform === 'tiktok' && <Music2 className="w-3 h-3" />}
                        {post.platform === 'youtube' && <Youtube className="w-3 h-3" />}
                        <span className="truncate">{post.time}</span>
                      </div>
                    ))}
                    {posts.length > 2 && (
                      <div className="text-xs text-[var(--color-text-secondary)]">
                        +{posts.length - 2} more
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-4">
          <Clock className="w-5 h-5 text-purple-500 mb-2" />
          <p className="text-2xl font-bold">6-9 PM EST</p>
          <p className="text-sm text-[var(--color-text-secondary)]">Peak Engagement Window</p>
        </div>
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-4">
          <p className="text-sm text-[var(--color-text-secondary)] mb-1">Scheduled This Week</p>
          <p className="text-2xl font-bold">6 posts</p>
        </div>
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-4">
          <p className="text-sm text-[var(--color-text-secondary)] mb-1">Optimal Timing</p>
          <p className="text-2xl font-bold text-green-400">83%</p>
        </div>
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-4">
          <p className="text-sm text-[var(--color-text-secondary)] mb-1">Est. Weekly Reach</p>
          <p className="text-2xl font-bold">47-67K</p>
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold">Upcoming Posts</h3>
          <button
            onClick={() => setShowScheduleModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-medium transition-all shadow-lg shadow-purple-500/20"
          >
            <Plus className="w-4 h-4" />
            Schedule Post
          </button>
        </div>

        <div className="space-y-3">
          {scheduledPosts.map((post) => (
            <div key={post.id} className={`p-4 rounded-lg ${
              post.optimalTime
                ? 'bg-[var(--color-background)] border border-[var(--color-border)]'
                : 'bg-yellow-500/10 border border-yellow-500/30'
            }`}>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center flex-shrink-0">
                  {post.platform === 'instagram' && <Instagram className="w-5 h-5 text-purple-500" />}
                  {post.platform === 'tiktok' && <Music2 className="w-5 h-5 text-purple-500" />}
                  {post.platform === 'youtube' && <Youtube className="w-5 h-5 text-purple-500" />}
                </div>

                <div className="flex-1">
                  <div className="flex items-start justify-between mb-1">
                    <div className="flex-1">
                      <h4 className="font-bold">{post.title}</h4>
                      <p className="text-sm text-[var(--color-text-secondary)]">
                        {post.platform.charAt(0).toUpperCase() + post.platform.slice(1)} • {post.type}
                      </p>
                    </div>
                    <div className="text-right ml-4">
                      <p className="font-medium">{post.time}</p>
                      <p className="text-sm text-[var(--color-text-secondary)]">
                        {new Date(post.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      post.status === 'scheduled' ? 'bg-blue-500/20 text-blue-300' : 'bg-gray-500/20 text-gray-300'
                    }`}>
                      {post.status}
                    </span>
                    {post.optimalTime && (
                      <span className="px-3 py-1 bg-green-500/20 text-green-300 rounded-full text-xs font-medium flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        Optimal Time
                      </span>
                    )}
                    <span className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-xs font-medium">
                      {post.engagement}
                    </span>
                  </div>

                  {post.suggestion && (
                    <div className="mt-2 flex items-start gap-2 text-xs text-yellow-300 bg-yellow-500/10 rounded p-2">
                      <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                      <span>{post.suggestion}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showScheduleModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-[var(--color-surface)] border-b border-[var(--color-border)] p-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Schedule New Post</h2>
                <p className="text-sm text-[var(--color-text-secondary)] mt-1">Choose platform, date, and time for your content</p>
              </div>
              <button
                onClick={() => setShowScheduleModal(false)}
                className="w-10 h-10 rounded-full bg-[var(--color-background)] hover:bg-[var(--color-surface-hover)] flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-[var(--color-text-secondary)]">
                    <p className="font-medium text-foreground mb-1">Demo Mode - Scheduling Simulation</p>
                    <p>In the live version, posts will be automatically published to your connected accounts at the scheduled time using official platform APIs. This demo shows how scheduling works without posting to real accounts.</p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Post Title / Description</label>
                <input
                  type="text"
                  value={newPost.title}
                  onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                  placeholder="e.g., Behind the scenes studio session"
                  className="w-full px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Platform</label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => setNewPost({ ...newPost, platform: 'instagram', type: 'Reel' })}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      newPost.platform === 'instagram'
                        ? 'border-purple-500 bg-purple-500/10'
                        : 'border-[var(--color-border)] bg-[var(--color-background)] hover:border-purple-500/50'
                    }`}
                  >
                    <Instagram className={`w-8 h-8 mx-auto mb-2 ${
                      newPost.platform === 'instagram' ? 'text-purple-500' : 'text-[var(--color-text-secondary)]'
                    }`} />
                    <p className="text-sm font-medium">Instagram</p>
                  </button>
                  <button
                    onClick={() => setNewPost({ ...newPost, platform: 'tiktok', type: 'Video' })}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      newPost.platform === 'tiktok'
                        ? 'border-pink-500 bg-pink-500/10'
                        : 'border-[var(--color-border)] bg-[var(--color-background)] hover:border-pink-500/50'
                    }`}
                  >
                    <Music2 className={`w-8 h-8 mx-auto mb-2 ${
                      newPost.platform === 'tiktok' ? 'text-pink-500' : 'text-[var(--color-text-secondary)]'
                    }`} />
                    <p className="text-sm font-medium">TikTok</p>
                  </button>
                  <button
                    onClick={() => setNewPost({ ...newPost, platform: 'youtube', type: 'Video' })}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      newPost.platform === 'youtube'
                        ? 'border-red-500 bg-red-500/10'
                        : 'border-[var(--color-border)] bg-[var(--color-background)] hover:border-red-500/50'
                    }`}
                  >
                    <Youtube className={`w-8 h-8 mx-auto mb-2 ${
                      newPost.platform === 'youtube' ? 'text-red-500' : 'text-[var(--color-text-secondary)]'
                    }`} />
                    <p className="text-sm font-medium">YouTube</p>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Content Type</label>
                <select
                  value={newPost.type}
                  onChange={(e) => setNewPost({ ...newPost, type: e.target.value })}
                  className="w-full px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  {getContentTypes(newPost.platform).map((type) => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--color-text-secondary)]" />
                    <input
                      type="date"
                      value={newPost.date}
                      onChange={(e) => setNewPost({ ...newPost, date: e.target.value })}
                      min={new Date().toISOString().split('T')[0]}
                      className="w-full pl-10 pr-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Time</label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--color-text-secondary)]" />
                    <input
                      type="time"
                      value={newPost.time}
                      onChange={(e) => setNewPost({ ...newPost, time: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-lg p-4">
                <p className="text-sm font-medium text-green-400 mb-2 flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Optimal Posting Times for {newPost.platform.charAt(0).toUpperCase() + newPost.platform.slice(1)}
                </p>
                <div className="text-xs text-[var(--color-text-secondary)] space-y-1">
                  {newPost.platform === 'instagram' && (
                    <>
                      <p>• Best: 6-9 PM EST (peak engagement)</p>
                      <p>• Good: 11 AM - 1 PM EST (lunch break)</p>
                      <p>• Avoid: 3-5 AM EST (low activity)</p>
                    </>
                  )}
                  {newPost.platform === 'tiktok' && (
                    <>
                      <p>• Best: 6-10 PM EST (FYP algorithm peak)</p>
                      <p>• Good: 7-9 AM EST (morning scroll)</p>
                      <p>• Pro tip: Post 2-3x daily for algorithm boost</p>
                    </>
                  )}
                  {newPost.platform === 'youtube' && (
                    <>
                      <p>• Best: 2-4 PM EST (after school/work)</p>
                      <p>• Good: 6-9 PM EST (evening viewing)</p>
                      <p>• Weekend: 9-11 AM EST (morning uploads)</p>
                    </>
                  )}
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-[var(--color-border)]">
                <button
                  onClick={() => setShowScheduleModal(false)}
                  className="flex-1 px-6 py-3 bg-[var(--color-background)] hover:bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-lg font-medium transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSchedulePost}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-medium transition-all"
                >
                  Schedule Post
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <SocialMediaComposer
        isOpen={showComposer}
        onClose={() => setShowComposer(false)}
      />
    </div>
  );
}
