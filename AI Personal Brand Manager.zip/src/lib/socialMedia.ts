// Social Media Integration Service
// Handles OAuth flows, token management, and API interactions

export type Platform = 'instagram' | 'tiktok' | 'youtube';

export interface ConnectedAccount {
  platform: Platform;
  accountId: string;
  username: string;
  displayName: string;
  profilePicture?: string;
  accessToken: string;
  refreshToken?: string;
  expiresAt: number;
  scopes: string[];
  isActive: boolean;
  connectedAt: string;
  lastSyncAt?: string;
  stats?: {
    followers?: number;
    posts?: number;
    engagement?: number;
  };
}

export interface PostSchedule {
  id: string;
  platforms: Platform[];
  content: string;
  mediaUrls?: string[];
  scheduledFor: string;
  status: 'scheduled' | 'publishing' | 'published' | 'failed';
  publishedAt?: string;
  errors?: Record<Platform, string>;
}

// OAuth Configuration for each platform
const OAUTH_CONFIGS = {
  instagram: {
    authUrl: 'https://api.instagram.com/oauth/authorize',
    tokenUrl: 'https://api.instagram.com/oauth/access_token',
    scope: 'user_profile,user_media,instagram_basic,instagram_content_publish',
    redirectUri: `${window.location.origin}/oauth/callback/instagram`,
  },
  tiktok: {
    authUrl: 'https://www.tiktok.com/auth/authorize',
    tokenUrl: 'https://open-api.tiktok.com/oauth/access_token',
    scope: 'user.info.basic,video.list,video.upload',
    redirectUri: `${window.location.origin}/oauth/callback/tiktok`,
  },
  youtube: {
    authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    scope: 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly',
    redirectUri: `${window.location.origin}/oauth/callback/youtube`,
  },
};

// Initiate OAuth flow
export const initiateOAuth = (platform: Platform, clientId: string) => {
  const config = OAUTH_CONFIGS[platform];
  const state = generateState();

  // Store state for validation
  sessionStorage.setItem(`oauth_state_${platform}`, state);

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: config.redirectUri,
    response_type: 'code',
    scope: config.scope,
    state,
  });

  // Redirect to OAuth provider
  window.location.href = `${config.authUrl}?${params.toString()}`;
};

// Handle OAuth callback
export const handleOAuthCallback = async (
  platform: Platform,
  code: string,
  state: string,
  clientId: string,
  clientSecret: string
): Promise<ConnectedAccount> => {
  // Validate state
  const storedState = sessionStorage.getItem(`oauth_state_${platform}`);
  if (state !== storedState) {
    throw new Error('Invalid OAuth state');
  }

  const config = OAUTH_CONFIGS[platform];

  // Exchange code for access token
  const tokenResponse = await fetch(config.tokenUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      client_id: clientId,
      client_secret: clientSecret,
      code,
      redirect_uri: config.redirectUri,
      grant_type: 'authorization_code',
    }),
  });

  if (!tokenResponse.ok) {
    throw new Error('Failed to exchange authorization code');
  }

  const tokens = await tokenResponse.json();

  // Fetch user profile
  const profile = await fetchUserProfile(platform, tokens.access_token);

  const account: ConnectedAccount = {
    platform,
    accountId: profile.id,
    username: profile.username,
    displayName: profile.displayName,
    profilePicture: profile.profilePicture,
    accessToken: tokens.access_token,
    refreshToken: tokens.refresh_token,
    expiresAt: Date.now() + (tokens.expires_in * 1000),
    scopes: config.scope.split(','),
    isActive: true,
    connectedAt: new Date().toISOString(),
    stats: profile.stats,
  };

  return account;
};

// Fetch user profile from platform
const fetchUserProfile = async (platform: Platform, accessToken: string) => {
  // Platform-specific API endpoints
  const endpoints = {
    instagram: 'https://graph.instagram.com/me?fields=id,username,account_type,media_count',
    tiktok: 'https://open-api.tiktok.com/user/info/',
    youtube: 'https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true',
  };

  const response = await fetch(endpoints[platform], {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!response.ok) {
    throw new Error('Failed to fetch user profile');
  }

  const data = await response.json();

  // Transform platform-specific response to common format
  return transformProfileData(platform, data);
};

// Transform platform-specific data
const transformProfileData = (platform: Platform, data: any) => {
  switch (platform) {
    case 'instagram':
      return {
        id: data.id,
        username: data.username,
        displayName: data.username,
        profilePicture: data.profile_picture_url,
        stats: {
          posts: data.media_count,
        },
      };
    case 'tiktok':
      return {
        id: data.data.user.id,
        username: data.data.user.unique_id,
        displayName: data.data.user.display_name,
        profilePicture: data.data.user.avatar_url,
        stats: {
          followers: data.data.user.follower_count,
        },
      };
    case 'youtube':
      const channel = data.items[0];
      return {
        id: channel.id,
        username: channel.snippet.customUrl,
        displayName: channel.snippet.title,
        profilePicture: channel.snippet.thumbnails.default.url,
        stats: {
          followers: parseInt(channel.statistics.subscriberCount),
          posts: parseInt(channel.statistics.videoCount),
        },
      };
    default:
      throw new Error(`Unknown platform: ${platform}`);
  }
};

// Refresh access token
export const refreshAccessToken = async (
  platform: Platform,
  refreshToken: string,
  clientId: string,
  clientSecret: string
): Promise<{ accessToken: string; expiresAt: number }> => {
  const config = OAUTH_CONFIGS[platform];

  const response = await fetch(config.tokenUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    }),
  });

  if (!response.ok) {
    throw new Error('Failed to refresh access token');
  }

  const tokens = await response.json();

  return {
    accessToken: tokens.access_token,
    expiresAt: Date.now() + (tokens.expires_in * 1000),
  };
};

// Disconnect account
export const disconnectAccount = async (platform: Platform, accountId: string) => {
  // In production, revoke tokens and remove from database
  console.log(`Disconnecting ${platform} account: ${accountId}`);
  return true;
};

// Publish post to platform
export const publishPost = async (
  platform: Platform,
  accessToken: string,
  content: string,
  mediaUrls?: string[]
): Promise<{ postId: string; url: string }> => {
  // Platform-specific publishing logic
  switch (platform) {
    case 'instagram':
      return publishToInstagram(accessToken, content, mediaUrls);
    case 'tiktok':
      return publishToTikTok(accessToken, content, mediaUrls);
    case 'youtube':
      return publishToYouTube(accessToken, content, mediaUrls);
    default:
      throw new Error(`Publishing not supported for ${platform}`);
  }
};

const publishToInstagram = async (accessToken: string, caption: string, mediaUrls?: string[]) => {
  // Instagram Graph API publishing
  const mediaUrl = mediaUrls?.[0];
  if (!mediaUrl) throw new Error('Instagram requires media');

  // Create media container
  const containerResponse = await fetch('https://graph.instagram.com/me/media', {
    method: 'POST',
    body: JSON.stringify({
      image_url: mediaUrl,
      caption,
      access_token: accessToken,
    }),
  });

  const container = await containerResponse.json();

  // Publish container
  const publishResponse = await fetch(`https://graph.instagram.com/me/media_publish`, {
    method: 'POST',
    body: JSON.stringify({
      creation_id: container.id,
      access_token: accessToken,
    }),
  });

  const result = await publishResponse.json();

  return {
    postId: result.id,
    url: `https://www.instagram.com/p/${result.id}/`,
  };
};

const publishToTikTok = async (accessToken: string, description: string, mediaUrls?: string[]) => {
  // TikTok API publishing
  const videoUrl = mediaUrls?.[0];
  if (!videoUrl) throw new Error('TikTok requires video');

  const response = await fetch('https://open-api.tiktok.com/share/video/upload/', {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}` },
    body: JSON.stringify({
      video: {
        video_url: videoUrl,
      },
      post_info: {
        title: description,
        privacy_level: 'PUBLIC_TO_EVERYONE',
      },
    }),
  });

  const result = await response.json();

  return {
    postId: result.data.share_id,
    url: `https://www.tiktok.com/@username/video/${result.data.share_id}`,
  };
};

const publishToYouTube = async (accessToken: string, description: string, mediaUrls?: string[]) => {
  // YouTube Data API publishing
  const videoUrl = mediaUrls?.[0];
  if (!videoUrl) throw new Error('YouTube requires video');

  const response = await fetch('https://www.googleapis.com/upload/youtube/v3/videos?part=snippet,status', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      snippet: {
        title: description.substring(0, 100),
        description,
      },
      status: {
        privacyStatus: 'public',
      },
    }),
  });

  const result = await response.json();

  return {
    postId: result.id,
    url: `https://www.youtube.com/watch?v=${result.id}`,
  };
};

// Helper: Generate random state for OAuth
const generateState = (): string => {
  return Math.random().toString(36).substring(2, 15) +
         Math.random().toString(36).substring(2, 15);
};

// Demo mode: Mock connected accounts
export const getMockConnectedAccounts = (): ConnectedAccount[] => [
  {
    platform: 'instagram',
    accountId: 'ig_123456',
    username: '@yourartistname',
    displayName: 'Your Artist Name',
    profilePicture: 'https://via.placeholder.com/150',
    accessToken: 'mock_token_ig',
    expiresAt: Date.now() + 3600000,
    scopes: ['user_profile', 'user_media', 'instagram_content_publish'],
    isActive: true,
    connectedAt: new Date(Date.now() - 86400000 * 30).toISOString(),
    lastSyncAt: new Date().toISOString(),
    stats: {
      followers: 45300,
      posts: 247,
      engagement: 8.2,
    },
  },
  {
    platform: 'tiktok',
    accountId: 'tt_789012',
    username: '@yourartistname',
    displayName: 'Your Artist Name',
    profilePicture: 'https://via.placeholder.com/150',
    accessToken: 'mock_token_tt',
    expiresAt: Date.now() + 3600000,
    scopes: ['user.info.basic', 'video.upload'],
    isActive: true,
    connectedAt: new Date(Date.now() - 86400000 * 60).toISOString(),
    lastSyncAt: new Date().toISOString(),
    stats: {
      followers: 128500,
      posts: 89,
      engagement: 12.5,
    },
  },
];

export const getPlatformInfo = (platform: Platform) => {
  const info = {
    instagram: {
      name: 'Instagram',
      description: 'Share photos and short videos with your followers',
      color: '#E4405F',
      icon: 'instagram',
      capabilities: ['posts', 'stories', 'reels'],
    },
    tiktok: {
      name: 'TikTok',
      description: 'Create and share short-form videos',
      color: '#000000',
      icon: 'tiktok',
      capabilities: ['videos', 'analytics'],
    },
    youtube: {
      name: 'YouTube',
      description: 'Upload and share video content',
      color: '#FF0000',
      icon: 'youtube',
      capabilities: ['videos', 'shorts', 'community'],
    },
  };

  return info[platform];
};
