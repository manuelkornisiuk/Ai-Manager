import { Resend } from 'resend';

const apiKey = import.meta.env.VITE_RESEND_API_KEY;
if (!apiKey) {
  console.warn('Demo mode: Resend not configured. Email features will be mocked.');
}

const resend = apiKey ? new Resend(apiKey) : null;
const fromEmail = import.meta.env.VITE_FROM_EMAIL || 'noreply@artistos.com';
const appUrl = import.meta.env.VITE_APP_URL || 'https://artistos.vercel.app';
const appName = import.meta.env.VITE_APP_NAME || 'ArtistOS';

// Email templates
const emailTemplates = {
  welcome: (userName: string) => ({
    subject: `Welcome to ${appName}! 🎵`,
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); padding: 40px 20px; text-align: center; border-radius: 12px 12px 0 0; }
            .header h1 { color: white; margin: 0; font-size: 28px; }
            .content { background: white; padding: 40px 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px; }
            .button { display: inline-block; background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; margin: 20px 0; font-weight: 600; }
            .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; }
            .feature { background: #f9fafb; padding: 15px; border-radius: 8px; margin: 15px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Welcome to ${appName}! 🎵</h1>
            </div>
            <div class="content">
              <h2>Hey ${userName}! 👋</h2>
              <p>We're thrilled to have you join the ${appName} family! You now have access to your personal AI-powered music career manager.</p>

              <div class="feature">
                <strong>🧠 Brand DNA Analysis</strong><br>
                Define your unique artist identity and style
              </div>

              <div class="feature">
                <strong>✨ AI Content Generator</strong><br>
                Get unlimited content ideas tailored to your brand
              </div>

              <div class="feature">
                <strong>📊 Audience Insights</strong><br>
                Track your growth across all platforms
              </div>

              <div class="feature">
                <strong>🎯 Music Pitching (Premium)</strong><br>
                Pitch your tracks to curators with AI-generated messages
              </div>

              <a href="${appUrl}" class="button">Get Started Now</a>

              <p>If you have any questions or need help getting started, just reply to this email. We're here to help!</p>

              <p>Keep creating! 🎶<br>
              The ${appName} Team</p>
            </div>
            <div class="footer">
              <p>${appName} - Your AI Manager<br>
              <a href="${appUrl}">Visit Dashboard</a> | <a href="${appUrl}/settings">Settings</a></p>
            </div>
          </div>
        </body>
      </html>
    `,
  }),

  emailVerification: (userName: string, verificationLink: string) => ({
    subject: `Verify your ${appName} email`,
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); padding: 40px 20px; text-align: center; border-radius: 12px 12px 0 0; }
            .header h1 { color: white; margin: 0; font-size: 28px; }
            .content { background: white; padding: 40px 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px; }
            .button { display: inline-block; background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; margin: 20px 0; font-weight: 600; }
            .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Verify Your Email 📧</h1>
            </div>
            <div class="content">
              <h2>Hi ${userName},</h2>
              <p>Thanks for signing up! Please verify your email address to complete your registration and access all features.</p>

              <a href="${verificationLink}" class="button">Verify Email Address</a>

              <p>Or copy and paste this link into your browser:</p>
              <p style="background: #f3f4f6; padding: 12px; border-radius: 6px; word-break: break-all; font-size: 14px;">${verificationLink}</p>

              <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">If you didn't create an account with ${appName}, you can safely ignore this email.</p>
            </div>
            <div class="footer">
              <p>${appName} - Your AI Manager</p>
            </div>
          </div>
        </body>
      </html>
    `,
  }),

  passwordReset: (userName: string, resetLink: string) => ({
    subject: `Reset your ${appName} password`,
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); padding: 40px 20px; text-align: center; border-radius: 12px 12px 0 0; }
            .header h1 { color: white; margin: 0; font-size: 28px; }
            .content { background: white; padding: 40px 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px; }
            .button { display: inline-block; background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; margin: 20px 0; font-weight: 600; }
            .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; }
            .warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Reset Password 🔐</h1>
            </div>
            <div class="content">
              <h2>Hi ${userName},</h2>
              <p>We received a request to reset your password for your ${appName} account.</p>

              <a href="${resetLink}" class="button">Reset Password</a>

              <p>Or copy and paste this link into your browser:</p>
              <p style="background: #f3f4f6; padding: 12px; border-radius: 6px; word-break: break-all; font-size: 14px;">${resetLink}</p>

              <div class="warning">
                <strong>⚠️ Security Notice:</strong><br>
                This link will expire in 1 hour. If you didn't request a password reset, please ignore this email and your password will remain unchanged.
              </div>
            </div>
            <div class="footer">
              <p>${appName} - Your AI Manager</p>
            </div>
          </div>
        </body>
      </html>
    `,
  }),

  subscriptionConfirmation: (userName: string, planName: string, amount: number, interval: string) => ({
    subject: `Welcome to ${planName}! 🎉`,
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); padding: 40px 20px; text-align: center; border-radius: 12px 12px 0 0; }
            .header h1 { color: white; margin: 0; font-size: 28px; }
            .content { background: white; padding: 40px 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px; }
            .button { display: inline-block; background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; margin: 20px 0; font-weight: 600; }
            .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; }
            .plan-details { background: #f9fafb; padding: 20px; border-radius: 8px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Subscription Confirmed! 🎉</h1>
            </div>
            <div class="content">
              <h2>Thanks ${userName}! 🙏</h2>
              <p>Your subscription to <strong>${planName}</strong> is now active. You have full access to all premium features!</p>

              <div class="plan-details">
                <h3 style="margin-top: 0;">Subscription Details</h3>
                <p style="margin: 8px 0;"><strong>Plan:</strong> ${planName}</p>
                <p style="margin: 8px 0;"><strong>Amount:</strong> $${amount}/${interval}</p>
                <p style="margin: 8px 0;"><strong>Status:</strong> Active ✅</p>
              </div>

              <h3>What's Unlocked:</h3>
              <ul>
                <li>✨ Unlimited AI content generation</li>
                <li>🧠 Brand DNA analysis</li>
                <li>📊 Audience insights</li>
                <li>📅 Content scheduling</li>
                ${planName.includes('Annual') ? '<li>🎯 Music pitching to playlists</li><li>🤖 AI-powered pitch generation</li><li>📇 Curator CRM</li>' : ''}
              </ul>

              <a href="${appUrl}" class="button">Start Using Premium Features</a>

              <p>You can manage your subscription anytime from your account settings.</p>
            </div>
            <div class="footer">
              <p>${appName} - Your AI Manager<br>
              <a href="${appUrl}/settings">Manage Subscription</a></p>
            </div>
          </div>
        </body>
      </html>
    `,
  }),

  paymentReceipt: (userName: string, amount: number, planName: string, invoiceUrl: string) => ({
    subject: `Payment receipt from ${appName}`,
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); padding: 40px 20px; text-align: center; border-radius: 12px 12px 0 0; }
            .header h1 { color: white; margin: 0; font-size: 28px; }
            .content { background: white; padding: 40px 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px; }
            .button { display: inline-block; background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; margin: 20px 0; font-weight: 600; }
            .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; }
            .receipt { background: #f9fafb; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e5e7eb; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Payment Received 💳</h1>
            </div>
            <div class="content">
              <h2>Hi ${userName},</h2>
              <p>Thank you for your payment! Here's your receipt:</p>

              <div class="receipt">
                <h3 style="margin-top: 0;">Receipt</h3>
                <p style="margin: 8px 0;"><strong>Plan:</strong> ${planName}</p>
                <p style="margin: 8px 0;"><strong>Amount Paid:</strong> $${amount.toFixed(2)}</p>
                <p style="margin: 8px 0;"><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
                <p style="margin: 8px 0;"><strong>Payment Status:</strong> Successful ✅</p>
              </div>

              <a href="${invoiceUrl}" class="button">Download Invoice</a>

              <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">This receipt is for your records. Questions? Just reply to this email.</p>
            </div>
            <div class="footer">
              <p>${appName} - Your AI Manager</p>
            </div>
          </div>
        </body>
      </html>
    `,
  }),

  renewalReminder: (userName: string, planName: string, amount: number, renewalDate: string) => ({
    subject: `Your ${appName} subscription renews soon`,
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); padding: 40px 20px; text-align: center; border-radius: 12px 12px 0 0; }
            .header h1 { color: white; margin: 0; font-size: 28px; }
            .content { background: white; padding: 40px 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px; }
            .button { display: inline-block; background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; margin: 20px 0; font-weight: 600; }
            .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; }
            .info-box { background: #eff6ff; border-left: 4px solid #3b82f6; padding: 15px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Subscription Renewal 🔄</h1>
            </div>
            <div class="content">
              <h2>Hi ${userName},</h2>
              <p>This is a friendly reminder that your <strong>${planName}</strong> subscription will automatically renew soon.</p>

              <div class="info-box">
                <p style="margin: 8px 0;"><strong>Renewal Date:</strong> ${renewalDate}</p>
                <p style="margin: 8px 0;"><strong>Amount:</strong> $${amount.toFixed(2)}</p>
                <p style="margin: 8px 0;">Your payment method on file will be charged automatically.</p>
              </div>

              <p>No action is needed - you'll continue enjoying all premium features.</p>

              <a href="${appUrl}/settings" class="button">Manage Subscription</a>

              <p style="color: #6b7280; font-size: 14px;">Want to make changes? You can update your plan or payment method anytime in your account settings.</p>
            </div>
            <div class="footer">
              <p>${appName} - Your AI Manager</p>
            </div>
          </div>
        </body>
      </html>
    `,
  }),

  pitchingUpdate: (userName: string, songTitle: string, status: string, curatorName?: string) => ({
    subject: `Update on "${songTitle}" pitch`,
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); padding: 40px 20px; text-align: center; border-radius: 12px 12px 0 0; }
            .header h1 { color: white; margin: 0; font-size: 28px; }
            .content { background: white; padding: 40px 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px; }
            .button { display: inline-block; background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; margin: 20px 0; font-weight: 600; }
            .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; }
            .status-box { background: #f0fdf4; border-left: 4px solid #10b981; padding: 15px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Pitch Update 🎵</h1>
            </div>
            <div class="content">
              <h2>Hi ${userName},</h2>
              <p>There's an update on your pitch for <strong>"${songTitle}"</strong>!</p>

              <div class="status-box">
                <p style="margin: 8px 0;"><strong>Status:</strong> ${status}</p>
                ${curatorName ? `<p style="margin: 8px 0;"><strong>Curator:</strong> ${curatorName}</p>` : ''}
              </div>

              ${status === 'accepted'
                ? '<p>🎉 Congratulations! Your track has been accepted! Keep up the great work!</p>'
                : status === 'under_review'
                ? '<p>Your track is being reviewed by the curator. We\'ll notify you when there\'s an update.</p>'
                : '<p>Check your dashboard for more details and next steps.</p>'
              }

              <a href="${appUrl}/pitching" class="button">View Pitch Details</a>
            </div>
            <div class="footer">
              <p>${appName} - Your AI Manager</p>
            </div>
          </div>
        </body>
      </html>
    `,
  }),

  weeklyReport: (userName: string, stats: { contentIdeas: number; pitches: number; engagement: string }) => ({
    subject: `Your ${appName} Weekly Report 📊`,
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); padding: 40px 20px; text-align: center; border-radius: 12px 12px 0 0; }
            .header h1 { color: white; margin: 0; font-size: 28px; }
            .content { background: white; padding: 40px 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px; }
            .button { display: inline-block; background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; margin: 20px 0; font-weight: 600; }
            .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; }
            .stat-card { background: #f9fafb; padding: 20px; border-radius: 8px; margin: 15px 0; text-align: center; }
            .stat-number { font-size: 32px; font-weight: bold; color: #a855f7; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Weekly Report 📊</h1>
            </div>
            <div class="content">
              <h2>Hi ${userName}! 👋</h2>
              <p>Here's your weekly summary from ${appName}:</p>

              <div class="stat-card">
                <div class="stat-number">${stats.contentIdeas}</div>
                <p>Content Ideas Generated</p>
              </div>

              <div class="stat-card">
                <div class="stat-number">${stats.pitches}</div>
                <p>Pitches Submitted</p>
              </div>

              <div class="stat-card">
                <div class="stat-number">${stats.engagement}</div>
                <p>Engagement Growth</p>
              </div>

              <h3>🚀 Keep the momentum going!</h3>
              <p>You're making great progress. Check your dashboard for personalized recommendations to grow even faster.</p>

              <a href="${appUrl}" class="button">View Full Dashboard</a>
            </div>
            <div class="footer">
              <p>${appName} - Your AI Manager<br>
              <a href="${appUrl}/settings">Email Preferences</a></p>
            </div>
          </div>
        </body>
      </html>
    `,
  }),
};

// Email sending functions
export const sendWelcomeEmail = async (email: string, userName: string) => {
  if (!resend) {
    console.log('Demo mode: Would send welcome email to', email);
    return;
  }
  const template = emailTemplates.welcome(userName);
  await resend.emails.send({
    from: fromEmail,
    to: email,
    subject: template.subject,
    html: template.html,
  });
};

export const sendEmailVerification = async (email: string, userName: string, verificationLink: string) => {
  if (!resend) {
    console.log('Demo mode: Would send verification email to', email);
    return;
  }
  const template = emailTemplates.emailVerification(userName, verificationLink);
  await resend.emails.send({
    from: fromEmail,
    to: email,
    subject: template.subject,
    html: template.html,
  });
};

export const sendPasswordReset = async (email: string, userName: string, resetLink: string) => {
  if (!resend) {
    console.log('Demo mode: Would send password reset email to', email);
    return;
  }
  const template = emailTemplates.passwordReset(userName, resetLink);
  await resend.emails.send({
    from: fromEmail,
    to: email,
    subject: template.subject,
    html: template.html,
  });
};

export const sendSubscriptionConfirmation = async (
  email: string,
  userName: string,
  planName: string,
  amount: number,
  interval: string
) => {
  if (!resend) {
    console.log('Demo mode: Would send subscription confirmation email to', email);
    return;
  }
  const template = emailTemplates.subscriptionConfirmation(userName, planName, amount, interval);
  await resend.emails.send({
    from: fromEmail,
    to: email,
    subject: template.subject,
    html: template.html,
  });
};

export const sendPaymentReceipt = async (
  email: string,
  userName: string,
  amount: number,
  planName: string,
  invoiceUrl: string
) => {
  if (!resend) {
    console.log('Demo mode: Would send payment receipt email to', email);
    return;
  }
  const template = emailTemplates.paymentReceipt(userName, amount, planName, invoiceUrl);
  await resend.emails.send({
    from: fromEmail,
    to: email,
    subject: template.subject,
    html: template.html,
  });
};

export const sendRenewalReminder = async (
  email: string,
  userName: string,
  planName: string,
  amount: number,
  renewalDate: string
) => {
  if (!resend) {
    console.log('Demo mode: Would send renewal reminder email to', email);
    return;
  }
  const template = emailTemplates.renewalReminder(userName, planName, amount, renewalDate);
  await resend.emails.send({
    from: fromEmail,
    to: email,
    subject: template.subject,
    html: template.html,
  });
};

export const sendPitchingUpdate = async (
  email: string,
  userName: string,
  songTitle: string,
  status: string,
  curatorName?: string
) => {
  if (!resend) {
    console.log('Demo mode: Would send pitching update email to', email);
    return;
  }
  const template = emailTemplates.pitchingUpdate(userName, songTitle, status, curatorName);
  await resend.emails.send({
    from: fromEmail,
    to: email,
    subject: template.subject,
    html: template.html,
  });
};

export const sendWeeklyReport = async (
  email: string,
  userName: string,
  stats: { contentIdeas: number; pitches: number; engagement: string }
) => {
  if (!resend) {
    console.log('Demo mode: Would send weekly report email to', email);
    return;
  }
  const template = emailTemplates.weeklyReport(userName, stats);
  await resend.emails.send({
    from: fromEmail,
    to: email,
    subject: template.subject,
    html: template.html,
  });
};
