import { useState } from 'react';
import { Sparkles, Wand2, Video, Image as ImageIcon, Film, Mic, Camera, ArrowRight, X, Instagram, Music2, Calendar, Clock, Check, Send } from 'lucide-react';
import SocialMediaComposer from './SocialMediaComposer';

interface ContentIdea {
  id: number;
  title: string;
  contentType: 'performance' | 'lifestyle' | 'storytelling' | 'cinematic' | 'bts';
  platform: string[];
  purpose: string;
  description: string;
  estimatedEngagement: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  timeToCreate: string;
  bestFor: 'Instagram' | 'TikTok' | 'Both';
  platformTips: {
    instagram: string;
    tiktok: string;
  };
}

interface VideoScenario {
  conceptDescription: string;
  hook: string;
  setting: string;
  visualStyle: string;
  shotBreakdown: string[];
  emotionalGoal: string;
  proTips: string[];
}

export default function ContentGeneratorView() {
  const [selectedIdea, setSelectedIdea] = useState<ContentIdea | null>(null);
  const [showScenarios, setShowScenarios] = useState(false);
  const [platformFilter, setPlatformFilter] = useState<'All' | 'Instagram' | 'TikTok'>('All');
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showComposer, setShowComposer] = useState(false);
  const [composerContent, setComposerContent] = useState('');
  const [scheduleData, setScheduleData] = useState({
    platform: 'instagram' as 'instagram' | 'tiktok' | 'youtube',
    date: '',
    time: '',
  });
  const [scheduledSuccess, setScheduledSuccess] = useState(false);

  const contentIdeas: ContentIdea[] = [
    {
      id: 1,
      title: 'Purple Hour Studio Sessions',
      contentType: 'performance',
      platform: ['TikTok', 'Instagram Reels', 'YouTube Shorts'],
      purpose: 'Engagement & Brand Building',
      description: 'Capture golden hour (purple-tinted) recording sessions with atmospheric lighting. Show authentic moments of creating beats while maintaining your moody aesthetic.',
      estimatedEngagement: '15-20K views',
      difficulty: 'Easy',
      timeToCreate: '2-3 hours',
      bestFor: 'Both',
      platformTips: {
        instagram: '60-90 seconds. Add detailed caption explaining your creative process. Post 6-9 PM EST. Use 5-8 relevant hashtags like #producerlife #beattape #alternativehiphop',
        tiktok: '15-45 seconds. Hook viewers in first 2 seconds with beat drop. Use trending sounds if possible. Post 2-3x daily for algorithm boost. Raw and authentic performs better than polished.',
      },
    },
    {
      id: 2,
      title: 'Midnight City Wandering',
      contentType: 'cinematic',
      platform: ['Instagram', 'TikTok'],
      purpose: 'Storytelling & Visual Identity',
      description: 'Cinematic B-roll of you walking through neon-lit city streets at night. Overlay with lyrics or spoken word from your tracks. Pure aesthetic that resonates with Gen Z urban creatives.',
      estimatedEngagement: '10-15K views',
      difficulty: 'Medium',
      timeToCreate: '4-6 hours',
      bestFor: 'Instagram',
      platformTips: {
        instagram: 'Perfect for Instagram! Longer format (90 seconds) allows cinematic storytelling. Polished editing expected. Strong captions with lyric excerpts perform well. Save as highlight reel.',
        tiktok: 'Works on TikTok but needs faster cuts. Keep under 30 seconds. Start with most visually striking shot. Use popular city/night aesthetic sounds to reach FYP.',
      },
    },
    {
      id: 3,
      title: 'Beat Making Time-Lapse with Twist',
      contentType: 'bts',
      platform: ['TikTok', 'YouTube Shorts'],
      purpose: 'Growth & Educational',
      description: 'Time-lapse of your full beat-making process, but with a surprise element - show the "before" (rough idea) vs "after" (polished track) transformation. Educational but entertaining.',
      estimatedEngagement: '20-30K views',
      difficulty: 'Easy',
      timeToCreate: '3-4 hours',
      bestFor: 'TikTok',
      platformTips: {
        instagram: 'Good for Instagram, but educational content gets less reach. Post midday when producers are browsing. Include "Save this!" call-to-action. Tutorial-style captions.',
        tiktok: 'Perfect for TikTok! Educational content thrives here. Use text overlay to guide viewers. Hook: "Watch me make a beat in 30 seconds". Algorithm loves completion rate.',
      },
    },
    {
      id: 4,
      title: 'Artist Morning Routine (Real)',
      contentType: 'lifestyle',
      platform: ['Instagram Reels', 'TikTok'],
      purpose: 'Engagement & Humanization',
      description: 'Raw, unfiltered morning routine focusing on your creative rituals. Coffee, journal, listening to demos, dealing with creative blocks. Show the real struggle and process.',
      estimatedEngagement: '8-12K views',
      difficulty: 'Easy',
      timeToCreate: '1-2 hours',
      bestFor: 'TikTok',
      platformTips: {
        instagram: 'Lifestyle content gets moderate engagement. Needs more polished aesthetic. Show clean, aspirational version of morning. Use soft lighting and good camera quality.',
        tiktok: 'Thrives on TikTok! Raw and authentic is preferred. Can film on phone with natural lighting. "Get ready with me" format. Trending audio boosts reach significantly.',
      },
    },
    {
      id: 5,
      title: 'Lyric Visualization Series',
      contentType: 'cinematic',
      platform: ['Instagram', 'TikTok'],
      purpose: 'Storytelling & Release Promotion',
      description: 'Create mini visual stories for your most powerful lyrics. Use moody lighting, purple/pink color grading, and symbolic imagery. Each video is a 15-30 second emotional moment.',
      estimatedEngagement: '12-18K views',
      difficulty: 'Medium',
      timeToCreate: '5-7 hours',
      bestFor: 'Instagram',
      platformTips: {
        instagram: 'Instagram loves polished visual content. Post as carousel with multiple lyric snippets. Use text overlays with custom fonts. Followers expect high production value.',
        tiktok: 'Works on TikTok with trending sound strategy. Add your track to TikTok library first. Encourage fans to use your sound. Lower production value acceptable if authentic.',
      },
    },
    {
      id: 6,
      title: 'Studio Failure Compilation',
      contentType: 'bts',
      platform: ['TikTok', 'YouTube'],
      purpose: 'Engagement & Authenticity',
      description: 'Compile all the funny fails, wrong takes, technical issues, and creative dead-ends. Show that even artists have messy processes. Relatable + humanizing.',
      estimatedEngagement: '25-35K views',
      difficulty: 'Easy',
      timeToCreate: '2-3 hours',
      bestFor: 'TikTok',
      platformTips: {
        instagram: 'Moderate performance. Instagram users expect more polished content. Works better as Stories than Reels. Keep it short and add upbeat music.',
        tiktok: 'Perfect for TikTok! Failure/blooper content is highly engaging. Use popular "expectation vs reality" sounds. Comment section will be very active. High shareability.',
      },
    },
    {
      id: 7,
      title: 'Sound Design Challenge',
      contentType: 'performance',
      platform: ['TikTok', 'Instagram Reels'],
      purpose: 'Growth & Community',
      description: 'Create a beat using only sounds from your environment (city noise, coffee shop ambience, etc.). Document the process and challenge followers to do the same.',
      estimatedEngagement: '30-40K views',
      difficulty: 'Medium',
      timeToCreate: '3-5 hours',
      bestFor: 'TikTok',
      platformTips: {
        instagram: 'Challenge content gets decent engagement. Need clear CTA asking followers to participate. Use branded hashtag. Feature fan submissions in Stories.',
        tiktok: 'Viral potential on TikTok! Challenges are algorithm-friendly. Use duet/stitch features. Start hashtag like #YourNameChallenge. Post multiple examples to seed trend.',
      },
    },
    {
      id: 8,
      title: 'Rooftop Performance: Midnight Vibes',
      contentType: 'performance',
      platform: ['Instagram', 'TikTok', 'YouTube'],
      purpose: 'Release Promotion',
      description: 'Perform "Midnight Vibes" on a rooftop at sunset/night with city skyline backdrop. Use your signature purple/pink lighting. Raw performance energy meets cinematic visuals.',
      estimatedEngagement: '18-25K views',
      difficulty: 'Hard',
      timeToCreate: '8-10 hours',
      bestFor: 'Instagram',
      platformTips: {
        instagram: 'High-production live performance content shines on Instagram. Full 90-second format allows complete song snippet. Tag location for discovery. Promotes upcoming releases well.',
        tiktok: 'Works but needs shorter cut (under 60 seconds). TikTok prioritizes authenticity over production quality. Consider posting BTS of this shoot instead of polished performance.',
      },
    },
    {
      id: 9,
      title: 'Day in the Life: Release Week',
      contentType: 'storytelling',
      platform: ['YouTube', 'Instagram'],
      purpose: 'Storytelling & Behind-the-Scenes',
      description: 'Document the entire release day - from waking up nervous, seeing first reactions, responding to fans, watching numbers climb. Show the full emotional journey.',
      estimatedEngagement: '15-22K views',
      difficulty: 'Medium',
      timeToCreate: '6-8 hours',
      bestFor: 'Instagram',
      platformTips: {
        instagram: 'Great for Instagram! Behind-the-scenes emotional content resonates with existing followers. Post as longer Reel or multi-part Story. Use countdown stickers pre-release.',
        tiktok: 'Okay for TikTok but less impactful. Cut into multiple shorter clips (release reaction, first comment read, number milestone). Spread across multiple posts for better reach.',
      },
    },
    {
      id: 10,
      title: 'Alternate Universe Versions',
      contentType: 'performance',
      platform: ['TikTok', 'Instagram Reels'],
      purpose: 'Engagement & Viral Potential',
      description: 'Recreate one of your songs in completely different genres (jazz, country, lo-fi, etc.). Show versatility while being entertaining. Format: "What if [song] was [genre]?"',
      estimatedEngagement: '35-50K views',
      difficulty: 'Medium',
      timeToCreate: '4-6 hours',
      bestFor: 'TikTok',
      platformTips: {
        instagram: 'Good engagement but less viral potential. Works well as Reels carousel series. Followers enjoy seeing creative side. Comment section engagement will be strong.',
        tiktok: 'Extremely viral on TikTok! "What if..." format is algorithm gold. High duet/stitch potential. Other creators will remix your remixes. Pin comment asking which genre next.',
      },
    },
    {
      id: 11,
      title: 'Fan Story Integration',
      contentType: 'storytelling',
      platform: ['Instagram', 'TikTok'],
      purpose: 'Community & Engagement',
      description: 'Ask fans to share stories about what your music means to them. Create cinematic visuals that bring their stories to life, with your music as the soundtrack.',
      estimatedEngagement: '20-28K views',
      difficulty: 'Hard',
      timeToCreate: '10-12 hours',
      bestFor: 'Instagram',
      platformTips: {
        instagram: 'Perfect for Instagram! Community-focused content strengthens follower relationships. Use Story questions to collect submissions. Feature multiple fans for inclusivity.',
        tiktok: 'Harder to execute on TikTok. Users less likely to submit long-form stories. Consider asking for voice notes or short clips instead. Duet feature helps fan participation.',
      },
    },
    {
      id: 12,
      title: 'Silent Studio Session',
      contentType: 'cinematic',
      platform: ['Instagram', 'YouTube'],
      purpose: 'Artistic Expression',
      description: 'Film yourself creating a beat entirely in silence (no music, just ambient sounds). Focus on visual storytelling - hand movements, facial expressions, equipment. Add the final beat at the end.',
      estimatedEngagement: '12-16K views',
      difficulty: 'Medium',
      timeToCreate: '5-6 hours',
      bestFor: 'Instagram',
      platformTips: {
        instagram: 'Artistic/experimental content fits Instagram aesthetic. Followers appreciate unique approaches. Will be saved and reshared. Use carousel to explain concept in caption.',
        tiktok: 'Risky on TikTok. Silent content often gets scrolled past unless hook is extremely strong. Consider adding ASMR element or suspenseful buildup to final beat reveal.',
      },
    },
    {
      id: 13,
      title: 'Equipment Breakdown & Sound Demo',
      contentType: 'bts',
      platform: ['TikTok', 'YouTube Shorts'],
      purpose: 'Educational & Growth',
      description: 'Show each piece of your studio equipment and demonstrate the exact sound/effect it creates in your music. Format: "This is the [equipment] that makes [signature sound]."',
      estimatedEngagement: '18-24K views',
      difficulty: 'Easy',
      timeToCreate: '2-3 hours',
      bestFor: 'TikTok',
      platformTips: {
        instagram: 'Educational content gets moderate reach. Works better as Story series or Guide. Include product links if you have affiliate partnerships. Producers will save for reference.',
        tiktok: 'Great for TikTok! Quick educational snippets perform well. "Before and after" sound comparisons hook viewers. Producer community is huge on TikTok. High comment engagement.',
      },
    },
    {
      id: 14,
      title: 'Urban Exploration + Music',
      contentType: 'lifestyle',
      platform: ['Instagram Reels', 'TikTok'],
      purpose: 'Brand Building & Visual Identity',
      description: 'Explore abandoned or aesthetically unique urban locations. Film cinematic shots with your music as the backdrop. Match the mood of the location to the vibe of the track.',
      estimatedEngagement: '14-20K views',
      difficulty: 'Medium',
      timeToCreate: '6-8 hours',
      bestFor: 'Instagram',
      platformTips: {
        instagram: 'Urban exploration aesthetic fits Instagram perfectly. High-quality visuals expected. Use geotags to reach local audience. Combination of photography and video works well.',
        tiktok: 'Can work on TikTok with right approach. Focus on discovery/exploration angle rather than pure aesthetics. "Found this hidden spot" narrative. Add map/directions in caption.',
      },
    },
    {
      id: 15,
      title: 'Collab Concept: Side-by-Side Creation',
      contentType: 'performance',
      platform: ['TikTok', 'Instagram'],
      purpose: 'Growth & Cross-Promotion',
      description: 'Collaborate with another artist (or micro-influencer) but film separately. Show split-screen of both of you creating your parts simultaneously. Builds anticipation for the collab.',
      estimatedEngagement: '25-35K views',
      difficulty: 'Hard',
      timeToCreate: '8-10 hours',
      bestFor: 'Both',
      platformTips: {
        instagram: 'Collab content benefits from cross-posting and tagging. Both artists post to their feeds. Use collab post feature to reach both audiences. Story countdown builds hype.',
        tiktok: 'Excellent for TikTok! Duet feature is built for this. Easy to coordinate and execute. Tag each other and use shared hashtag. Algorithm will push to both audiences.',
      },
    },
  ];

  const getVideoScenarios = (idea: ContentIdea): VideoScenario[] => {
    if (!idea) return [];

    const scenarioMap: Record<number, VideoScenario[]> = {
      1: [
        {
          conceptDescription: 'Purple-hour moody studio session captured during golden hour with purple-tinted lighting. You\'re at your workstation, headphones on, deeply focused on layering a beat. Camera captures authentic creative moments.',
          hook: 'Start with a close-up of your hands on the MIDI controller as purple light hits your workspace. Cut to your face reacting to the first drop.',
          setting: 'Home studio during sunset (5-7 PM). Position your desk near a window. Use purple LED strips + natural golden hour light mix.',
          visualStyle: 'Moody and atmospheric. Purple (#8B5CF6) and pink (#EC4899) color grading. Shallow depth of field. Film in 24fps for cinematic feel. Mix of static tripod shots and slow handheld movement.',
          shotBreakdown: [
            'Opening: Close-up of hands on MIDI keyboard (3 sec)',
            'Cut to: Side profile of your face, purple light illuminating one side (2 sec)',
            'Wide shot: Full studio setup with purple ambient lighting (3 sec)',
            'Over-shoulder: Computer screen showing DAW, hands working (4 sec)',
            'Close-up: Your face reacting to the beat drop, slight head nod (3 sec)',
            'B-roll: Equipment details, knobs turning, waveforms (10 sec)',
            'Ending: Lean back in chair, satisfied expression, frame freezes on your silhouette (3 sec)',
          ],
          emotionalGoal: 'Make viewers feel like they\'re witnessing a sacred creative process. Inspire aspiring producers while showcasing your dedication and aesthetic.',
          proTips: [
            'Film during actual golden hour for authentic lighting',
            'Don\'t fake the beat-making - capture real creative moments',
            'Use smooth transitions timed to your beat drops',
            'Add subtle grain/texture in post for extra mood',
          ],
        },
        {
          conceptDescription: 'High-energy late-night studio session. You\'re vibing to the beat, more performance-focused. Purple neon lights pulsing to the rhythm. This version is more dynamic and playful.',
          hook: 'Pitch black screen. Sudden beat drop as purple lights flash on, revealing you hitting the first note. Instant energy.',
          setting: 'Studio at night (9 PM-12 AM). Only artificial lighting - purple LED strips, pink accent lights. Dark background to make colors pop.',
          visualStyle: 'High contrast, saturated colors. Mix of quick cuts and smooth slow-motion moments. More music video than documentary. Handheld camera for energy.',
          shotBreakdown: [
            'Opening: Black screen with audio starting (1 sec)',
            'Beat drop: Quick flash of purple lights revealing your silhouette (1 sec)',
            'Medium shot: You nodding to the beat, building energy (3 sec)',
            'Quick cuts: Hands on equipment, feet tapping, head bobbing (5 sec)',
            'Slow-mo: You hitting a key, purple light streaks across frame (3 sec)',
            'Overhead shot: Looking down at full setup, you in center (4 sec)',
            'Fast montage: Multiple angles of performance moments (8 sec)',
            'Ending: Freeze frame mid-action with purple light trail (3 sec)',
          ],
          emotionalGoal: 'Pure excitement and creative energy. Make viewers want to run to their own studio/bedroom and create immediately.',
          proTips: [
            'Shoot in 60fps or 120fps for smooth slow-motion options',
            'Pre-program LED lights to pulse with your beat',
            'Wear something that contrasts with purple (black or white works best)',
            'Film multiple takes and cut to the best energy moments',
          ],
        },
      ],
      2: [
        {
          conceptDescription: 'Cinematic night walk through neon-lit streets. You walk slowly, contemplative, as the city pulses around you. Overlaid with spoken word or lyrics from your track. Focus on atmosphere and emotion.',
          hook: 'Open on a neon sign reflected in a puddle. Camera tilts up to reveal you walking toward it, hood up, mysterious.',
          setting: 'Downtown area with lots of neon signs, wet streets (for reflections), ideally after light rain. Shoot between 10 PM-1 AM when streets are less crowded.',
          visualStyle: 'Cinematic 2.35:1 aspect ratio. Purple/pink/blue neon tones. Shallow focus on you, neon lights bokeh in background. Smooth gimbal movements. Slightly desaturated except for neon colors.',
          shotBreakdown: [
            'Opening: Neon reflection in puddle (2 sec)',
            'Tilt up: Reveal your silhouette approaching (3 sec)',
            'Following shot: Camera moves backward as you walk forward (5 sec)',
            'Side tracking: You walking past neon signs, lights washing over you (4 sec)',
            'Close-up: Your face illuminated by changing neon colors (3 sec)',
            'Wide shot: You small in frame, surrounded by city lights (3 sec)',
            'Low angle: Looking up as you pass overhead lights (2 sec)',
            'POV: What you see - city from your perspective (3 sec)',
            'Ending: You walk away from camera into purple neon haze (3 sec)',
          ],
          emotionalGoal: 'Melancholic beauty. Viewers should feel both isolated and connected to the urban landscape. Introspective and moody.',
          proTips: [
            'Bring a friend to help with gimbal/camera work',
            'Scout location beforehand to find best neon spots',
            'Film multiple paths and edit best shots together',
            'Add light fog/mist effect in post for extra atmosphere',
            'Use spoken word or isolated vocal from your track - not full song',
          ],
        },
        {
          conceptDescription: 'Faster-paced urban montage. Multiple locations, quick cuts, you interacting with the city. More energetic, less contemplative. Show the city as your playground and inspiration.',
          hook: 'Quick flash of 5 different neon signs in rapid succession (0.5 sec each), ending on you standing in front of the brightest one.',
          setting: 'Multiple locations across the city: subway entrance, corner store, rooftop edge, busy intersection. Film all in one night.',
          visualStyle: 'Dynamic camera movement. Mix of handheld and stabilized. Faster cuts. Vibrant neon colors. Less serious, more exploratory vibe.',
          shotBreakdown: [
            'Rapid montage: Different neon signs flashing (2.5 sec)',
            'Reveal: You standing in neon glow (1 sec)',
            'Quick cut sequence: Walking up subway stairs, buying coffee, checking phone (6 sec)',
            'Spinning shot: Camera rotates around you as city lights blur (3 sec)',
            'Rooftop: You sitting on edge, city sprawled behind you (4 sec)',
            'Street level: Walking through crowd, lights reflecting off surfaces (4 sec)',
            'Alley: Pausing to look at street art, purple light from sign above (3 sec)',
            'Final wide: You on rooftop silhouette against purple sky (4 sec)',
          ],
          emotionalGoal: 'Adventurous and inspiring. Make viewers want to explore their own city and find beauty in urban spaces.',
          proTips: [
            'Film in burst mode - multiple takes at each location',
            'Vary your pace - some shots walking, some standing, some moving fast',
            'Capture city sounds (ambient audio) to layer under music',
            'Get permits if filming in restricted areas like subway',
            'Bring small portable LED light for fill on your face',
          ],
        },
      ],
      3: [
        {
          conceptDescription: 'Traditional time-lapse showing your full beat-making process from blank project to finished track, but with a twist ending that surprises the viewer.',
          hook: 'Open with your hands cracking knuckles in front of a blank DAW screen. Text overlay: "Watch me make a beat in 30 seconds."',
          setting: 'Studio with clean, organized setup. Camera mounted on tripod directly in front of your workstation. Good overhead lighting.',
          visualStyle: 'Clean and well-lit. Traditional time-lapse speed (4-8x). Standard aspect ratio. Focus on clarity so viewers can see the DAW and your movements.',
          shotBreakdown: [
            'Opening: Hands cracking, blank screen visible behind (2 sec)',
            'Time-lapse: Full beat creation process sped up - adding drums, bass, melody (20 sec)',
            'Normal speed: You export the track, satisfied expression (2 sec)',
            'Twist: Another window opens - it\'s a rough demo from months ago. Split screen comparison (4 sec)',
            'Ending: Text overlay: "First try vs. Now. Keep creating." (3 sec)',
          ],
          emotionalGoal: 'Inspirational for producers. Show that polished work takes practice. Growth is possible.',
          proTips: [
            'Film actual creative session - don\'t fake it',
            'Keep your workspace tidy so time-lapse looks clean',
            'Make sure camera battery will last entire session',
            'Consider adding small clock in corner to show real time passed',
          ],
        },
        {
          conceptDescription: 'Beat-making challenge format: "Can I make a hit beat in 10 minutes?" Real-time pressure, showing both the creative process and the stress.',
          hook: 'You set a visible timer on your phone to 10:00. Look at camera with determined expression. "Let\'s see if I can do this." Start timer.',
          setting: 'Same studio setup but include visible timer (phone or clock) in frame. More casual, energetic vibe.',
          visualStyle: 'Real-time feeling even if sped up slightly. Multiple camera angles cut together. Mix of over-shoulder DAW view and your reactions.',
          shotBreakdown: [
            'Opening: Setting timer, determined look (3 sec)',
            'Fast cuts: Quick bursts of you working - drums, melody, bass (12 sec)',
            'Check timer: "5 minutes left!" - slight panic (2 sec)',
            'Speed up: Frantic finishing touches (6 sec)',
            'Timer: Last 10 seconds shown in real-time with your reactions (4 sec)',
            'Reveal: Play the final beat, your reaction - surprised/proud (5 sec)',
          ],
          emotionalGoal: 'Tension and release. Viewers root for you to finish. Show that creativity can happen under pressure.',
          proTips: [
            'Film with 2 cameras if possible (DAW view + face reaction)',
            'Practice the challenge beforehand to know it\'s achievable',
            'Have a loose plan but allow for real spontaneity',
            'Consider doing multiple takes and using the best one',
          ],
        },
      ],
    };

    return scenarioMap[idea.id] || [
      {
        conceptDescription: 'Default scenario - concept would be generated based on the content idea.',
        hook: 'Attention-grabbing opening based on content type.',
        setting: 'Location appropriate for the content concept.',
        visualStyle: 'Visual aesthetic matching artist brand DNA.',
        shotBreakdown: ['Shot-by-shot breakdown would be generated here'],
        emotionalGoal: 'Emotional response tailored to content purpose.',
        proTips: ['Professional tips for execution would be listed here'],
      },
    ];
  };

  const getIconForType = (type: string) => {
    switch (type) {
      case 'performance':
        return Mic;
      case 'lifestyle':
        return Camera;
      case 'storytelling':
        return Film;
      case 'cinematic':
        return Video;
      case 'bts':
        return ImageIcon;
      default:
        return Wand2;
    }
  };

  const getColorForType = (type: string) => {
    switch (type) {
      case 'performance':
        return 'purple';
      case 'lifestyle':
        return 'blue';
      case 'storytelling':
        return 'pink';
      case 'cinematic':
        return 'indigo';
      case 'bts':
        return 'green';
      default:
        return 'gray';
    }
  };

  const handleScheduleFromIdea = () => {
    if (!scheduleData.date || !scheduleData.time) {
      alert('Please select date and time');
      return;
    }

    const hour = parseInt(scheduleData.time.split(':')[0]);
    const isOptimalTime = (scheduleData.platform === 'instagram' || scheduleData.platform === 'tiktok')
      ? (hour >= 18 && hour <= 21)
      : (hour >= 14 && hour <= 20);

    setScheduledSuccess(true);
    setTimeout(() => {
      setShowScheduleModal(false);
      setScheduledSuccess(false);
      setScheduleData({
        platform: 'instagram',
        date: '',
        time: '',
      });
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">AI Content Generator</h2>
          <p className="text-[var(--color-text-secondary)] mt-1">
            Tailored content ideas based on your brand DNA, music style, and audience insights.
          </p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-medium transition-all shadow-lg shadow-purple-500/20">
          <Sparkles className="w-4 h-4" />
          Regenerate Ideas
        </button>
      </div>

      <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6">
        <div className="flex items-start gap-4">
          <Wand2 className="w-6 h-6 text-purple-400 flex-shrink-0 mt-1" />
          <div className="flex-1">
            <h3 className="font-bold mb-2">Analysis Complete</h3>
            <p className="text-sm text-[var(--color-text-secondary)] mb-3">
              Generated {contentIdeas.length} content ideas based on your profile:
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm mb-4">
              <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-3">
                <p className="text-[var(--color-text-secondary)] mb-1">Genre</p>
                <p className="font-bold">Alternative Hip-Hop</p>
              </div>
              <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-3">
                <p className="text-[var(--color-text-secondary)] mb-1">Visual Style</p>
                <p className="font-bold">Moody Aesthetic</p>
              </div>
              <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-3">
                <p className="text-[var(--color-text-secondary)] mb-1">Audience</p>
                <p className="font-bold">Gen Z Creatives</p>
              </div>
              <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-3">
                <p className="text-[var(--color-text-secondary)] mb-1">Brand Colors</p>
                <div className="flex gap-1">
                  <div className="w-4 h-4 rounded-full bg-purple-500" />
                  <div className="w-4 h-4 rounded-full bg-pink-500" />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-[var(--color-text-secondary)]">Platform Focus:</span>
              <button
                onClick={() => setPlatformFilter('All')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  platformFilter === 'All'
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                    : 'bg-[var(--color-surface)]/50 text-[var(--color-text-secondary)] hover:bg-[var(--color-surface)]'
                }`}
              >
                All Platforms
              </button>
              <button
                onClick={() => setPlatformFilter('Instagram')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${
                  platformFilter === 'Instagram'
                    ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white'
                    : 'bg-[var(--color-surface)]/50 text-[var(--color-text-secondary)] hover:bg-[var(--color-surface)]'
                }`}
              >
                <Instagram className="w-3.5 h-3.5" />
                Instagram Best
              </button>
              <button
                onClick={() => setPlatformFilter('TikTok')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${
                  platformFilter === 'TikTok'
                    ? 'bg-gradient-to-r from-pink-500 to-red-500 text-white'
                    : 'bg-[var(--color-surface)]/50 text-[var(--color-text-secondary)] hover:bg-[var(--color-surface)]'
                }`}
              >
                <Music2 className="w-3.5 h-3.5" />
                TikTok Best
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {contentIdeas
          .filter((idea) => {
            if (platformFilter === 'All') return true;
            return idea.bestFor === platformFilter || idea.bestFor === 'Both';
          })
          .map((idea) => {
          const Icon = getIconForType(idea.contentType);
          const color = getColorForType(idea.contentType);

          return (
            <div
              key={idea.id}
              className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6 hover:border-purple-500/50 transition-all"
            >
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl bg-${color}-500/10 flex items-center justify-center flex-shrink-0`}>
                  <Icon className={`w-6 h-6 text-${color}-500`} />
                </div>

                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold mb-2">{idea.title}</h3>
                      <p className="text-sm text-[var(--color-text-secondary)] mb-3">{idea.description}</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className={`px-3 py-1 bg-${color}-500/20 text-${color}-300 rounded-full text-xs font-medium`}>
                      {idea.contentType}
                    </span>
                    {idea.platform.map((p) => (
                      <span key={p} className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-xs font-medium">
                        {p}
                      </span>
                    ))}
                    <span className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-xs font-medium">
                      {idea.purpose}
                    </span>
                    {idea.bestFor === 'Instagram' && (
                      <span className="px-3 py-1 bg-gradient-to-r from-pink-500/20 to-purple-500/20 text-pink-300 rounded-full text-xs font-medium flex items-center gap-1">
                        <Instagram className="w-3 h-3" />
                        Best for IG
                      </span>
                    )}
                    {idea.bestFor === 'TikTok' && (
                      <span className="px-3 py-1 bg-gradient-to-r from-pink-500/20 to-red-500/20 text-pink-300 rounded-full text-xs font-medium flex items-center gap-1">
                        <Music2 className="w-3 h-3" />
                        Best for TikTok
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div className="bg-[var(--color-background)] rounded-lg p-3">
                      <p className="text-xs text-[var(--color-text-secondary)] mb-1">Est. Engagement</p>
                      <p className="font-bold text-sm">{idea.estimatedEngagement}</p>
                    </div>
                    <div className="bg-[var(--color-background)] rounded-lg p-3">
                      <p className="text-xs text-[var(--color-text-secondary)] mb-1">Difficulty</p>
                      <p className={`font-bold text-sm ${
                        idea.difficulty === 'Easy' ? 'text-green-400' :
                        idea.difficulty === 'Medium' ? 'text-yellow-400' : 'text-red-400'
                      }`}>
                        {idea.difficulty}
                      </p>
                    </div>
                    <div className="bg-[var(--color-background)] rounded-lg p-3">
                      <p className="text-xs text-[var(--color-text-secondary)] mb-1">Time to Create</p>
                      <p className="font-bold text-sm">{idea.timeToCreate}</p>
                    </div>
                  </div>

                  <div className="bg-blue-500/5 border border-blue-500/20 rounded-lg p-4 mb-4">
                    <p className="text-xs font-bold text-blue-300 mb-2 flex items-center gap-1.5">
                      <Instagram className="w-3.5 h-3.5" />
                      Instagram Strategy
                    </p>
                    <p className="text-xs text-[var(--color-text-secondary)]">{idea.platformTips.instagram}</p>
                  </div>

                  <div className="bg-pink-500/5 border border-pink-500/20 rounded-lg p-4 mb-4">
                    <p className="text-xs font-bold text-pink-300 mb-2 flex items-center gap-1.5">
                      <Music2 className="w-3.5 h-3.5" />
                      TikTok Strategy
                    </p>
                    <p className="text-xs text-[var(--color-text-secondary)]">{idea.platformTips.tiktok}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => {
                        setSelectedIdea(idea);
                        setShowScenarios(true);
                      }}
                      className="flex items-center justify-center gap-2 px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] hover:border-purple-500/50 rounded-lg font-medium transition-all"
                    >
                      <Film className="w-4 h-4" />
                      Scenarios
                    </button>
                    <button
                      onClick={() => {
                        setComposerContent(idea.description);
                        setShowComposer(true);
                      }}
                      className="flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-medium transition-all"
                    >
                      <Send className="w-4 h-4" />
                      Post Now
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {showScenarios && selectedIdea && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl max-w-5xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-[var(--color-surface)] border-b border-[var(--color-border)] p-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">{selectedIdea.title}</h2>
                <p className="text-sm text-[var(--color-text-secondary)] mt-1">Video Execution Scenarios</p>
              </div>
              <button
                onClick={() => setShowScenarios(false)}
                className="w-10 h-10 rounded-full bg-[var(--color-background)] hover:bg-[var(--color-surface-hover)] flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {getVideoScenarios(selectedIdea).map((scenario, index) => (
                <div key={index} className="bg-gradient-to-br from-purple-500/5 to-pink-500/5 border border-purple-500/20 rounded-xl p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-8 h-8 rounded-full bg-purple-500 flex items-center justify-center text-white font-bold">
                      {index + 1}
                    </div>
                    <h3 className="text-xl font-bold">Scenario {index + 1}</h3>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <p className="text-sm font-medium text-purple-400 mb-1">Concept</p>
                      <p className="text-sm text-[var(--color-text-secondary)]">{scenario.conceptDescription}</p>
                    </div>

                    <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
                      <p className="text-sm font-medium text-pink-400 mb-1">🎣 Hook (First 3 Seconds)</p>
                      <p className="text-sm">{scenario.hook}</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
                        <p className="text-sm font-medium text-blue-400 mb-1">📍 Setting/Location</p>
                        <p className="text-sm text-[var(--color-text-secondary)]">{scenario.setting}</p>
                      </div>

                      <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
                        <p className="text-sm font-medium text-green-400 mb-1">🎨 Visual Style</p>
                        <p className="text-sm text-[var(--color-text-secondary)]">{scenario.visualStyle}</p>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium text-yellow-400 mb-2">🎬 Shot-by-Shot Breakdown</p>
                      <div className="space-y-2">
                        {scenario.shotBreakdown.map((shot, shotIndex) => (
                          <div key={shotIndex} className="flex items-start gap-2 bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-3">
                            <span className="text-xs font-bold text-purple-400 mt-0.5">{shotIndex + 1}.</span>
                            <p className="text-sm text-[var(--color-text-secondary)]">{shot}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="bg-pink-500/10 border border-pink-500/20 rounded-lg p-4">
                      <p className="text-sm font-medium text-pink-400 mb-1">💭 Emotional Goal</p>
                      <p className="text-sm">{scenario.emotionalGoal}</p>
                    </div>

                    <div>
                      <p className="text-sm font-medium text-green-400 mb-2">💡 Pro Tips</p>
                      <div className="space-y-2">
                        {scenario.proTips.map((tip, tipIndex) => (
                          <div key={tipIndex} className="flex items-start gap-2">
                            <span className="text-green-400 mt-1">•</span>
                            <p className="text-sm text-[var(--color-text-secondary)]">{tip}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              <div className="flex gap-3">
                <button
                  onClick={() => setShowScheduleModal(true)}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-medium transition-all flex items-center justify-center gap-2"
                >
                  <Calendar className="w-4 h-4" />
                  Add to Content Calendar
                </button>
                <button className="px-6 py-3 bg-[var(--color-background)] hover:bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-lg font-medium transition-all">
                  Export as PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showScheduleModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl max-w-xl w-full">
            <div className="bg-[var(--color-surface)] border-b border-[var(--color-border)] p-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Schedule to Calendar</h2>
                <p className="text-sm text-[var(--color-text-secondary)] mt-1">
                  {selectedIdea ? selectedIdea.title : 'Choose when to post this content'}
                </p>
              </div>
              <button
                onClick={() => setShowScheduleModal(false)}
                className="w-10 h-10 rounded-full bg-[var(--color-background)] hover:bg-[var(--color-surface-hover)] flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {scheduledSuccess ? (
                <div className="py-12 text-center">
                  <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-4">
                    <Check className="w-8 h-8 text-green-400" />
                  </div>
                  <h3 className="text-xl font-bold text-green-400 mb-2">Scheduled Successfully!</h3>
                  <p className="text-sm text-[var(--color-text-secondary)]">
                    Your post has been added to the content calendar
                  </p>
                </div>
              ) : (
                <>
                  <div>
                    <label className="block text-sm font-medium mb-2">Platform</label>
                    <div className="grid grid-cols-3 gap-3">
                      <button
                        onClick={() => setScheduleData({ ...scheduleData, platform: 'instagram' })}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          scheduleData.platform === 'instagram'
                            ? 'border-purple-500 bg-purple-500/10'
                            : 'border-[var(--color-border)] bg-[var(--color-background)] hover:border-purple-500/50'
                        }`}
                      >
                        <Instagram className={`w-8 h-8 mx-auto mb-2 ${
                          scheduleData.platform === 'instagram' ? 'text-purple-500' : 'text-[var(--color-text-secondary)]'
                        }`} />
                        <p className="text-sm font-medium">Instagram</p>
                      </button>
                      <button
                        onClick={() => setScheduleData({ ...scheduleData, platform: 'tiktok' })}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          scheduleData.platform === 'tiktok'
                            ? 'border-pink-500 bg-pink-500/10'
                            : 'border-[var(--color-border)] bg-[var(--color-background)] hover:border-pink-500/50'
                        }`}
                      >
                        <Music2 className={`w-8 h-8 mx-auto mb-2 ${
                          scheduleData.platform === 'tiktok' ? 'text-pink-500' : 'text-[var(--color-text-secondary)]'
                        }`} />
                        <p className="text-sm font-medium">TikTok</p>
                      </button>
                      <button
                        onClick={() => setScheduleData({ ...scheduleData, platform: 'youtube' })}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          scheduleData.platform === 'youtube'
                            ? 'border-red-500 bg-red-500/10'
                            : 'border-[var(--color-border)] bg-[var(--color-background)] hover:border-red-500/50'
                        }`}
                      >
                        <Video className={`w-8 h-8 mx-auto mb-2 ${
                          scheduleData.platform === 'youtube' ? 'text-red-500' : 'text-[var(--color-text-secondary)]'
                        }`} />
                        <p className="text-sm font-medium">YouTube</p>
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Date</label>
                      <div className="relative">
                        <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--color-text-secondary)]" />
                        <input
                          type="date"
                          value={scheduleData.date}
                          onChange={(e) => setScheduleData({ ...scheduleData, date: e.target.value })}
                          min={new Date().toISOString().split('T')[0]}
                          className="w-full pl-10 pr-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Time</label>
                      <div className="relative">
                        <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--color-text-secondary)]" />
                        <input
                          type="time"
                          value={scheduleData.time}
                          onChange={(e) => setScheduleData({ ...scheduleData, time: e.target.value })}
                          className="w-full pl-10 pr-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-lg p-4">
                    <p className="text-sm font-medium text-green-400 mb-2 flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Optimal Times for {scheduleData.platform.charAt(0).toUpperCase() + scheduleData.platform.slice(1)}
                    </p>
                    <div className="text-xs text-[var(--color-text-secondary)] space-y-1">
                      {scheduleData.platform === 'instagram' && (
                        <>
                          <p>• Best: 6-9 PM EST (peak engagement)</p>
                          <p>• Good: 11 AM - 1 PM EST (lunch break)</p>
                        </>
                      )}
                      {scheduleData.platform === 'tiktok' && (
                        <>
                          <p>• Best: 6-10 PM EST (FYP algorithm peak)</p>
                          <p>• Good: 7-9 AM EST (morning scroll)</p>
                        </>
                      )}
                      {scheduleData.platform === 'youtube' && (
                        <>
                          <p>• Best: 2-4 PM EST (after school/work)</p>
                          <p>• Good: 6-9 PM EST (evening viewing)</p>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4 border-t border-[var(--color-border)]">
                    <button
                      onClick={() => setShowScheduleModal(false)}
                      className="flex-1 px-6 py-3 bg-[var(--color-background)] hover:bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-lg font-medium transition-all"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleScheduleFromIdea}
                      className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-medium transition-all"
                    >
                      Schedule Post
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      <SocialMediaComposer
        isOpen={showComposer}
        onClose={() => setShowComposer(false)}
        defaultContent={composerContent}
      />
    </div>
  );
}
