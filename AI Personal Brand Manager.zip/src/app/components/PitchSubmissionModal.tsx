import { useState } from 'react';
import { X, Music, Sparkles, Send, Loader } from 'lucide-react';
import { createPlaylistPitch } from '../../lib/supabase';
import { useAuth } from '../context/AuthContext';

interface PitchSubmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetName: string;
  targetType: 'playlist' | 'blog' | 'sync';
  targetDetails?: any;
}

export default function PitchSubmissionModal({
  isOpen,
  onClose,
  targetName,
  targetType,
  targetDetails,
}: PitchSubmissionModalProps) {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    songTitle: '',
    artistName: user?.name || '',
    spotifyTrackUrl: '',
    genre: '',
    mood: '',
    description: '',
    pitchMessage: '',
  });
  const [isGeneratingPitch, setIsGeneratingPitch] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const generateAIPitch = async () => {
    if (!formData.songTitle || !formData.genre || !formData.mood) {
      setError('Please fill in song title, genre, and mood first');
      return;
    }

    setIsGeneratingPitch(true);
    setError('');

    // Simulate AI generation (in production, this would call an AI API)
    setTimeout(() => {
      const pitchTemplates = {
        playlist: `Hi ${targetDetails?.curator || 'Curator'},

I hope this message finds you well! I'm ${formData.artistName}, and I wanted to reach out about my latest track "${formData.songTitle}".

This ${formData.genre} song has a ${formData.mood.toLowerCase()} vibe that I think would resonate perfectly with your "${targetName}" playlist audience. ${formData.description}

The production quality is top-notch, and early feedback from my community has been incredibly positive. I believe this track would complement the existing flow of your playlist while adding a fresh perspective.

I'd be honored if you'd consider giving it a listen. The track is available on Spotify${formData.spotifyTrackUrl ? ` at ${formData.spotifyTrackUrl}` : ''}.

Thank you for your time and for curating such an amazing playlist!

Best regards,
${formData.artistName}`,
        blog: `Hi ${targetName} Team,

My name is ${formData.artistName}, and I'm reaching out to introduce my latest ${formData.genre} release, "${formData.songTitle}".

${formData.description}

This track represents ${formData.mood.toLowerCase()} energy and showcases my growth as an artist. I think it would resonate well with your readers who appreciate authentic, quality music.

I've included all necessary materials:
- High-resolution press photos
- Artist bio and background
- Spotify link${formData.spotifyTrackUrl ? `: ${formData.spotifyTrackUrl}` : ''}
- Social media links

I'd love the opportunity to be featured on ${targetName}. Let me know if you need any additional information!

Best,
${formData.artistName}`,
        sync: `Dear ${targetName} Music Supervisor,

I'm ${formData.artistName}, and I believe my track "${formData.songTitle}" would be an excellent fit for ${targetName}.

Track Details:
- Genre: ${formData.genre}
- Mood/Vibe: ${formData.mood}
- Description: ${formData.description}

Why it fits your project:
The ${formData.mood.toLowerCase()} atmosphere and ${formData.genre} production style align perfectly with the tone described in your brief. The track has both emotional depth and commercial appeal.

Rights & Clearances:
- All samples cleared
- Master rights available
- Publishing rights available
- Instrumental version available
- Stems available upon request

${formData.spotifyTrackUrl ? `Preview: ${formData.spotifyTrackUrl}` : 'Full track and stems can be provided immediately upon request.'}

Looking forward to the possibility of contributing to this project!

Best regards,
${formData.artistName}`,
      };

      setFormData(prev => ({
        ...prev,
        pitchMessage: pitchTemplates[targetType],
      }));
      setIsGeneratingPitch(false);
    }, 2000);
  };

  const handleSubmit = async () => {
    if (!user) {
      setError('You must be logged in to submit a pitch');
      return;
    }

    if (!formData.songTitle || !formData.artistName || !formData.genre) {
      setError('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      // Create pitch in database
      await createPlaylistPitch({
        user_id: user.id,
        song_title: formData.songTitle,
        artist_name: formData.artistName,
        spotify_track_url: formData.spotifyTrackUrl || undefined,
        genre: formData.genre,
        mood: formData.mood || undefined,
        description: formData.description || undefined,
        pitch_message: formData.pitchMessage || undefined,
        target_playlists: {
          name: targetName,
          type: targetType,
          details: targetDetails,
        },
        status: 'submitted',
        submission_date: new Date().toISOString(),
      });

      // Success - close modal
      onClose();

      // Show success message (you could add a toast notification here)
      alert(`Pitch submitted successfully to ${targetName}!`);
    } catch (err) {
      console.error('Error submitting pitch:', err);
      setError('Failed to submit pitch. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[var(--color-surface)] rounded-xl border border-[var(--color-border)] w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-[var(--color-surface)] border-b border-[var(--color-border)] p-6 flex items-center justify-between">
          <div>
            <h3 className="text-2xl font-bold">Submit Pitch</h3>
            <p className="text-sm text-[var(--color-text-secondary)] mt-1">
              Pitching to: <span className="text-purple-400 font-medium">{targetName}</span>
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-lg hover:bg-[var(--color-surface-hover)] flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {error && (
            <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4">
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Song Title <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                value={formData.songTitle}
                onChange={(e) => handleInputChange('songTitle', e.target.value)}
                placeholder="Enter song title"
                className="w-full px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Artist Name <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                value={formData.artistName}
                onChange={(e) => handleInputChange('artistName', e.target.value)}
                placeholder="Your artist name"
                className="w-full px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Spotify Track URL
            </label>
            <input
              type="url"
              value={formData.spotifyTrackUrl}
              onChange={(e) => handleInputChange('spotifyTrackUrl', e.target.value)}
              placeholder="https://open.spotify.com/track/..."
              className="w-full px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:border-purple-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Genre <span className="text-red-400">*</span>
              </label>
              <select
                value={formData.genre}
                onChange={(e) => handleInputChange('genre', e.target.value)}
                className="w-full px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:border-purple-500"
              >
                <option value="">Select genre</option>
                <option value="Hip-Hop">Hip-Hop</option>
                <option value="Alternative Hip-Hop">Alternative Hip-Hop</option>
                <option value="R&B">R&B</option>
                <option value="Pop">Pop</option>
                <option value="Electronic">Electronic</option>
                <option value="Indie">Indie</option>
                <option value="Rock">Rock</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Mood/Vibe
              </label>
              <select
                value={formData.mood}
                onChange={(e) => handleInputChange('mood', e.target.value)}
                className="w-full px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:border-purple-500"
              >
                <option value="">Select mood</option>
                <option value="Energetic">Energetic</option>
                <option value="Chill">Chill</option>
                <option value="Moody">Moody</option>
                <option value="Uplifting">Uplifting</option>
                <option value="Dark">Dark</option>
                <option value="Romantic">Romantic</option>
                <option value="Introspective">Introspective</option>
                <option value="Party">Party</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Track Description
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Describe your track, its story, and what makes it unique..."
              rows={4}
              className="w-full px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:border-purple-500 resize-none"
            />
          </div>

          <div className="border-t border-[var(--color-border)] pt-6">
            <div className="flex items-center justify-between mb-3">
              <label className="block text-sm font-medium">
                Pitch Message
              </label>
              <button
                onClick={generateAIPitch}
                disabled={isGeneratingPitch}
                className="px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-medium transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isGeneratingPitch ? (
                  <>
                    <Loader className="w-4 h-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Generate AI Pitch
                  </>
                )}
              </button>
            </div>
            <textarea
              value={formData.pitchMessage}
              onChange={(e) => handleInputChange('pitchMessage', e.target.value)}
              placeholder="Your personalized pitch message to the curator/blog/supervisor will appear here..."
              rows={12}
              className="w-full px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:border-purple-500 resize-none font-mono text-sm"
            />
            <p className="text-xs text-[var(--color-text-secondary)] mt-2">
              💡 Tip: Use the AI generator to create a professional pitch, then customize it with your personal touch
            </p>
          </div>
        </div>

        <div className="sticky bottom-0 bg-[var(--color-surface)] border-t border-[var(--color-border)] p-6 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-6 py-3 bg-[var(--color-background)] border border-[var(--color-border)] hover:bg-[var(--color-surface-hover)] rounded-lg font-medium transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={isSubmitting || !formData.songTitle || !formData.artistName || !formData.genre}
            className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-bold transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <>
                <Loader className="w-5 h-5 animate-spin" />
                Submitting...
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                Submit Pitch
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
