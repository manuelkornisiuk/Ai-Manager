import { Users, MapPin, Calendar, Clock, TrendingUp } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line } from 'recharts';

export default function AudienceView() {
  const demographics = {
    totalFollowers: 47234,
    growth: '+12.3%',
    avgAge: 23,
    topAge: '18-24',
  };

  const ageData = [
    { age: '13-17', value: 15 },
    { age: '18-24', value: 42 },
    { age: '25-34', value: 28 },
    { age: '35-44', value: 10 },
    { age: '45+', value: 5 },
  ];

  const genderData = [
    { name: 'Female', value: 52, color: '#EC4899' },
    { name: 'Male', value: 45, color: '#8B5CF6' },
    { name: 'Other', value: 3, color: '#3B82F6' },
  ];

  const locationData = [
    { city: 'New York', followers: 8234 },
    { city: 'Los Angeles', followers: 6789 },
    { city: 'Chicago', followers: 4523 },
    { city: 'Miami', followers: 3890 },
    { city: 'Atlanta', followers: 3456 },
  ];

  const activityData = [
    { hour: '12AM', activity: 15 },
    { hour: '3AM', activity: 8 },
    { hour: '6AM', activity: 12 },
    { hour: '9AM', activity: 25 },
    { hour: '12PM', activity: 45 },
    { hour: '3PM', activity: 62 },
    { hour: '6PM', activity: 88 },
    { hour: '9PM', activity: 72 },
  ];

  const growthData = [
    { week: 'Week 1', followers: 42100 },
    { week: 'Week 2', followers: 43200 },
    { week: 'Week 3', followers: 44800 },
    { week: 'Week 4', followers: 47234 },
  ];

  const interests = [
    { interest: 'Hip-Hop Music', percentage: 89 },
    { interest: 'Music Production', percentage: 76 },
    { interest: 'Fashion', percentage: 68 },
    { interest: 'Photography', percentage: 54 },
    { interest: 'Streetwear', percentage: 51 },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Audience Insights</h2>
        <p className="text-[var(--color-text-secondary)] mt-1">Understand who your fans are and when they're most active.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6 hover:border-purple-500/50 transition-colors">
          <div className="flex items-center justify-between mb-2">
            <Users className="w-5 h-5 text-purple-500" />
            <span className="text-sm text-green-500 font-medium">{demographics.growth}</span>
          </div>
          <p className="text-3xl font-bold">{demographics.totalFollowers.toLocaleString()}</p>
          <p className="text-sm text-[var(--color-text-secondary)] mt-1">Total Followers</p>
          <p className="text-xs text-green-400 mt-2">+5.8K this month</p>
        </div>

        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6 hover:border-pink-500/50 transition-colors">
          <div className="flex items-center justify-between mb-2">
            <Calendar className="w-5 h-5 text-pink-500" />
          </div>
          <p className="text-3xl font-bold">{demographics.avgAge}</p>
          <p className="text-sm text-[var(--color-text-secondary)] mt-1">Average Age</p>
          <p className="text-xs text-[var(--color-text-secondary)] mt-2">Gen Z focused</p>
        </div>

        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6 hover:border-blue-500/50 transition-colors">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-5 h-5 text-blue-500" />
          </div>
          <p className="text-3xl font-bold">{demographics.topAge}</p>
          <p className="text-sm text-[var(--color-text-secondary)] mt-1">Top Age Range</p>
          <p className="text-xs text-[var(--color-text-secondary)] mt-2">42% of audience</p>
        </div>

        <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-xl p-6">
          <div className="flex items-center justify-between mb-2">
            <Clock className="w-5 h-5 text-green-500" />
          </div>
          <p className="text-3xl font-bold text-green-400">6-9 PM</p>
          <p className="text-sm text-[var(--color-text-secondary)] mt-1">Peak Activity</p>
          <p className="text-xs text-green-400 mt-2">11.5% engagement</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <h3 className="text-xl font-bold mb-4">Age Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={ageData}>
              <CartesianGrid key="age-grid" strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis key="age-xaxis" dataKey="age" stroke="var(--color-text-secondary)" />
              <YAxis key="age-yaxis" stroke="var(--color-text-secondary)" />
              <Tooltip
                key="age-tooltip"
                contentStyle={{
                  backgroundColor: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px'
                }}
              />
              <Bar key="age-bar" dataKey="value" fill="#8B5CF6" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <h3 className="text-xl font-bold mb-4">Gender Split</h3>
          <div className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  key="gender-pie"
                  data={genderData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {genderData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip key="gender-tooltip" />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-6 mt-4">
            {genderData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-sm">{item.name}: {item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <h3 className="text-xl font-bold mb-4">Follower Growth (Last 4 Weeks)</h3>
        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={growthData}>
            <CartesianGrid key="growth-grid" strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis key="growth-xaxis" dataKey="week" stroke="var(--color-text-secondary)" />
            <YAxis key="growth-yaxis" stroke="var(--color-text-secondary)" />
            <Tooltip
              key="growth-tooltip"
              contentStyle={{
                backgroundColor: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: '8px'
              }}
            />
            <Line key="growth-line" type="monotone" dataKey="followers" stroke="#8B5CF6" strokeWidth={3} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <MapPin className="w-5 h-5 text-purple-500" />
            <h3 className="text-xl font-bold">Top Locations</h3>
          </div>
          <div className="space-y-3">
            {locationData.map((location, index) => (
              <div key={location.city} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center font-bold text-sm">
                    {index + 1}
                  </span>
                  <span className="font-medium">{location.city}</span>
                </div>
                <span className="text-[var(--color-text-secondary)]">{location.followers.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-pink-500" />
            <h3 className="text-xl font-bold">Top Interests</h3>
          </div>
          <div className="space-y-3">
            {interests.map((item) => (
              <div key={item.interest}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium">{item.interest}</span>
                  <span className="text-sm text-[var(--color-text-secondary)]">{item.percentage}%</span>
                </div>
                <div className="h-2 bg-[var(--color-background)] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="w-5 h-5 text-blue-500" />
          <h3 className="text-xl font-bold">Audience Activity by Time</h3>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={activityData}>
            <CartesianGrid key="activity-grid" strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis key="activity-xaxis" dataKey="hour" stroke="var(--color-text-secondary)" />
            <YAxis key="activity-yaxis" stroke="var(--color-text-secondary)" />
            <Tooltip
              key="activity-tooltip"
              contentStyle={{
                backgroundColor: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: '8px'
              }}
            />
            <Bar key="activity-bar" dataKey="activity" fill="#EC4899" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
        <div className="mt-4 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
          <p className="text-sm font-medium text-green-400 mb-1">💡 Peak Time Strategy</p>
          <p className="text-sm text-[var(--color-text-secondary)]">
            Schedule 60% of your content between 6-9 PM EST for maximum reach. This window shows <span className="text-green-400 font-bold">11.5% engagement</span> vs 6.2% average.
          </p>
        </div>
      </div>
    </div>
  );
}
