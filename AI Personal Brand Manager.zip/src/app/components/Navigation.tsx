import { useState } from 'react';
import { Home, Brain, TrendingUp, Calendar, Users, Settings, Sparkles, CreditCard, Moon, Sun, Target, Shield, Send, LucideIcon, LogIn, LogOut, UserPlus } from 'lucide-react';
import { useTheme } from '../context/ThemeContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import AuthModal from './AuthModal.tsx';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

interface Tab {
  id: string;
  label: string;
  icon: LucideIcon;
  badge?: string;
}

export default function Navigation({ activeTab, onTabChange }: NavigationProps) {
  const { theme, toggleTheme } = useTheme();
  const { user, setUser } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');

  const tabs: Tab[] = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'brand-dna', label: 'Brand DNA', icon: Brain },
    { id: 'content-generator', label: 'Content Generator', icon: Sparkles, badge: 'AI' },
    { id: 'recommendations', label: 'Recommendations', icon: TrendingUp },
    { id: 'pitching', label: 'Music Pitching', icon: Send, badge: 'NEW' },
    { id: 'competitor-analysis', label: 'Genre Insights', icon: Target },
    { id: 'schedule', label: 'Schedule', icon: Calendar },
    { id: 'audience', label: 'Audience', icon: Users },
    { id: 'pricing', label: 'Pricing', icon: CreditCard },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <nav className="w-64 bg-[var(--color-surface)] border-r border-[var(--color-border)] flex flex-col">
      <div className="p-6 border-b border-[var(--color-border)]">
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 opacity-30 blur-md animate-pulse"></div>
            <div className="relative w-8 h-8 rounded-full border-2 border-transparent bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 bg-clip-border"></div>
            <div className="absolute inset-2 rounded-full bg-[var(--color-surface)]"></div>
          </div>
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 bg-clip-text text-transparent">
              ArtistOS
            </h1>
            <p className="text-xs text-[var(--color-text-secondary)]">Your AI Manager</p>
          </div>
        </div>
      </div>

      <div className="flex-1 p-4 space-y-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors relative ${
                isActive
                  ? 'bg-purple-500 text-white'
                  : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-hover)]'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{tab.label}</span>
              {tab.badge && (
                <span className="ml-auto px-2 py-0.5 bg-gradient-to-r from-purple-400 to-pink-400 text-white text-xs font-bold rounded-full">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className="p-4 border-t border-[var(--color-border)] space-y-3">
        <button
          onClick={toggleTheme}
          className="w-full flex items-center justify-between px-4 py-3 rounded-lg hover:bg-[var(--color-surface-hover)] transition-colors"
        >
          <div className="flex items-center gap-3">
            {theme === 'dark' ? (
              <Moon className="w-5 h-5 text-[var(--color-text-secondary)]" />
            ) : (
              <Sun className="w-5 h-5 text-[var(--color-text-secondary)]" />
            )}
            <span className="font-medium text-[var(--color-text-secondary)]">
              {theme === 'dark' ? 'Dark Mode' : 'Light Mode'}
            </span>
          </div>
          <div className={`relative w-11 h-6 rounded-full transition-colors ${
            theme === 'dark' ? 'bg-purple-500' : 'bg-gray-300'
          }`}>
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
              theme === 'dark' ? 'translate-x-6' : 'translate-x-1'
            }`} />
          </div>
        </button>

        {user ? (
          <div className="space-y-2">
            <div className="flex items-center gap-3 px-4 py-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                {user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
              </div>
              <div className="flex-1">
                <p className="font-medium">{user.name}</p>
                <p className="text-sm text-[var(--color-text-secondary)]">
                  {user.isCreator ? 'Creator' : 'Artist'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setUser(null)}
              className="w-full flex items-center gap-3 px-4 py-2 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
            >
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Sign Out</span>
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <button
              onClick={() => {
                setAuthMode('signin');
                setShowAuthModal(true);
              }}
              className="w-full flex items-center gap-3 px-4 py-3 bg-purple-500 hover:bg-purple-600 text-white rounded-lg transition-colors font-medium"
            >
              <LogIn className="w-5 h-5" />
              <span>Sign In</span>
            </button>
            <button
              onClick={() => {
                setAuthMode('signup');
                setShowAuthModal(true);
              }}
              className="w-full flex items-center gap-3 px-4 py-3 border border-[var(--color-border)] hover:bg-[var(--color-surface-hover)] rounded-lg transition-colors font-medium"
            >
              <UserPlus className="w-5 h-5" />
              <span>Sign Up</span>
            </button>
          </div>
        )}

        <div className="px-4 py-2 flex items-center justify-center gap-1.5 text-[10px] text-[var(--color-text-secondary)] opacity-60">
          <Shield className="w-3 h-3" />
          <span>Secured & Encrypted</span>
        </div>
      </div>

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        mode={authMode}
      />
    </nav>
  );
}
