import { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext.tsx';
import { AuthProvider } from './context/AuthContext.tsx';
import Navigation from './components/Navigation.tsx';
import DashboardView from './components/DashboardView.tsx';
import BrandDNAView from './components/BrandDNAView.tsx';
import ContentGeneratorView from './components/ContentGeneratorView.tsx';
import RecommendationsView from './components/RecommendationsView.tsx';
import PitchingView from './components/PitchingView.tsx';
import ScheduleView from './components/ScheduleView.tsx';
import AudienceView from './components/AudienceView.tsx';
import CompetitorAnalysisView from './components/CompetitorAnalysisView.tsx';
import PricingView from './components/PricingView.tsx';
import SettingsView from './components/SettingsView.tsx';
import DemoNotice from './components/DemoNotice.tsx';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView />;
      case 'brand-dna':
        return <BrandDNAView />;
      case 'content-generator':
        return <ContentGeneratorView />;
      case 'recommendations':
        return <RecommendationsView />;
      case 'pitching':
        return <PitchingView />;
      case 'competitor-analysis':
        return <CompetitorAnalysisView />;
      case 'schedule':
        return <ScheduleView />;
      case 'audience':
        return <AudienceView />;
      case 'pricing':
        return <PricingView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <ThemeProvider>
      <AuthProvider>
        <DemoNotice />
        <div className="size-full flex bg-[var(--color-background)]">
          <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
          <main className="flex-1 overflow-y-auto">
            <div className="max-w-7xl mx-auto p-8">
              {renderView()}
            </div>
          </main>
        </div>
      </AuthProvider>
    </ThemeProvider>
  );
}