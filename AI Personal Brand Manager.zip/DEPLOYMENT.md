# ArtistOS Production Deployment Guide

This comprehensive guide covers the complete setup and deployment process for ArtistOS, from development to production.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Environment Setup](#environment-setup)
3. [Supabase Configuration](#supabase-configuration)
4. [Stripe Setup](#stripe-setup)
5. [Email Service Setup](#email-service-setup)
6. [Local Development](#local-development)
7. [Production Deployment](#production-deployment)
8. [Post-Deployment](#post-deployment)
9. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before you begin, ensure you have:

- **Node.js** 18+ and **pnpm** installed
- A **GitHub** account
- A **Supabase** account (free tier works for development)
- A **Stripe** account (test mode for development)
- A **Resend** account for transactional emails
- A **Vercel** account for hosting (recommended)
- **Git** installed on your computer

## Step-by-Step Deployment Guide

### Option 1: Deploy via GitHub (Recommended)

#### Step 1: Get Your Code
1. Download all files from `/workspaces/default/code/` to your local computer
2. Create a folder called `artistos` on your computer

#### Step 2: Create GitHub Repository
1. Go to [github.com](https://github.com)
2. Click the "+" icon in the top right → "New repository"
3. Name it: `artistos`
4. Choose "Private" (to protect your code)
5. Click "Create repository"

#### Step 3: Push Your Code to GitHub
Open Terminal/Command Prompt in your `artistos` folder and run:

```bash
# Initialize git repository
git init

# Add all files
git add .

# Create first commit
git commit -m "Initial commit - ArtistOS by Juan Manuel Kornisiuk"

# Connect to your GitHub repository (replace YOUR-USERNAME)
git remote add origin https://github.com/YOUR-USERNAME/artistos.git

# Push to GitHub
git branch -M main
git push -u origin main
```

#### Step 4: Deploy to Vercel
1. Go to [vercel.com](https://vercel.com)
2. Click "Sign Up" and choose "Continue with GitHub"
3. Once logged in, click "Add New..." → "Project"
4. Find your `artistos` repository and click "Import"
5. Configure your project:
   - **Framework Preset**: Vite
   - **Build Command**: `pnpm run build` (or `npm run build`)
   - **Output Directory**: `dist`
   - **Install Command**: `pnpm install` (or `npm install`)
6. Click "Deploy"
7. Wait 2-3 minutes for deployment to complete
8. Click "Visit" to see your live app!

Your app will be live at: `https://artistos.vercel.app` (or similar)

---

### Option 2: Deploy via Vercel CLI (Advanced)

#### Step 1: Install Vercel CLI
```bash
npm install -g vercel
```

#### Step 2: Login to Vercel
```bash
vercel login
```

#### Step 3: Deploy
Navigate to your project folder and run:
```bash
vercel
```

Follow the prompts:
- Set up and deploy? **Y**
- Which scope? Choose your account
- Link to existing project? **N**
- Project name? **artistos**
- Directory? **./** (current directory)
- Override settings? **N**

Your app will deploy and you'll get a live URL!

#### Step 4: Deploy to Production
```bash
vercel --prod
```

---

## Custom Domain (Optional)

Once deployed, you can add a custom domain:

1. Go to your project in Vercel Dashboard
2. Click "Settings" → "Domains"
3. Add your domain (e.g., `artistos.com`)
4. Follow DNS setup instructions
5. Vercel will automatically provision SSL certificate

---

## Automatic Deployments

Once connected to GitHub:
- Every push to `main` branch = automatic production deploy
- Every pull request = preview deployment
- No manual steps needed!

---

## Environment Variables (If Needed Later)

If you add API keys or secrets:
1. Go to Vercel Dashboard → Your Project
2. Click "Settings" → "Environment Variables"
3. Add variables:
   - `VITE_API_KEY`
   - `VITE_STRIPE_KEY`
   - etc.
4. Redeploy for changes to take effect

---

## Troubleshooting

### Build Fails
- Check that all dependencies are in `package.json`
- Ensure build command is `pnpm run build` or `npm run build`
- Check build logs for specific errors

### Blank Page After Deploy
- Verify output directory is `dist`
- Check browser console for errors
- Ensure all imports use correct paths

### 404 on Routes
- The `vercel.json` file handles this with rewrites
- Make sure `vercel.json` is committed to your repo

---

## Updating Your App

To update your live app:

1. Make changes to your code locally
2. Commit changes:
   ```bash
   git add .
   git commit -m "Update: description of changes"
   git push
   ```
3. Vercel automatically deploys in 1-2 minutes
4. Check your live URL to see changes

---

## Support

- Vercel Docs: [vercel.com/docs](https://vercel.com/docs)
- GitHub Help: [docs.github.com](https://docs.github.com)

---

© 2026 Juan Manuel Kornisiuk. All Rights Reserved.
