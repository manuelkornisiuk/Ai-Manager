import { useState } from 'react';
import { Check, Sparkles, Zap, Crown, ArrowRight, Shield, Music, TrendingUp } from 'lucide-react';
import SecurityBadge from './SecurityBadge.tsx';

export default function PricingView() {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');

  const plans = [
    {
      name: '7-Day Free Trial',
      price: '$0',
      period: 'then $69/mo',
      description: 'Experience the full power of ArtistOS',
      features: [
        '✅ Full access to everything',
        '✅ Unlimited AI content generation',
        '✅ Complete Brand DNA analysis',
        '✅ Advanced audience insights',
        '✅ Music pitching included',
        '✅ AI-powered pitch generation',
        '✅ Curator CRM & tracking',
        '⚡ No credit card required',
      ],
      limitations: [],
      cta: 'Start Free Trial',
      disabled: false,
      popular: true,
      savings: null,
      billedAs: 'Try everything free for 7 days',
      isFreeTrial: true,
    },
    {
      name: 'Monthly',
      price: billingCycle === 'monthly' ? '$69' : '$59',
      period: 'per month',
      description: 'The complete AI manager for serious artists',
      features: [
        'Unlimited AI content generation',
        '15+ video scenarios per idea',
        'Full Brand DNA analysis',
        'Advanced analytics & projections',
        'Audience insights & demographics',
        'Content calendar & scheduling',
        'Genre insights & competitor analysis',
        'Growth recommendations',
        'Priority email support',
        'Export reports as PDF',
      ],
      limitations: [],
      cta: 'Get Started',
      disabled: false,
      popular: false,
      savings: billingCycle === 'annual' ? 'Save $120/year (15% off)' : null,
      billedAs: billingCycle === 'monthly' ? 'Billed monthly at $69' : 'Billed annually at $708',
      totalPrice: billingCycle === 'annual' ? '$708/year' : null,
    },
    {
      name: 'Premium',
      price: billingCycle === 'monthly' ? '$149' : '$119',
      period: 'per month',
      description: 'For artists ready to go pro',
      features: [
        'Everything in Monthly, plus:',
        '🎵 Unlimited Spotify playlist pitching',
        '📰 Unlimited blog & press submissions',
        '🎬 Unlimited TV/film/ads sync pitching',
        '🤖 AI-matched opportunities (90%+ match)',
        '📊 Pitch tracking & analytics',
        '👨‍💼 Personal success manager',
        '📞 Monthly strategy call',
        '📄 White-label reports',
        '🔌 API access',
      ],
      limitations: [],
      cta: 'Get Started',
      disabled: false,
      popular: false,
      savings: billingCycle === 'annual' ? 'Save $360/year (20% off)' : null,
      billedAs: billingCycle === 'monthly' ? 'Billed monthly at $149' : 'Billed annually at $1,428',
      totalPrice: billingCycle === 'annual' ? '$1,428/year' : null,
      isPremium: true,
    },
  ];

  const benefits = [
    {
      icon: Sparkles,
      title: 'AI-Powered Insights',
      description: 'Get personalized content recommendations based on your unique brand DNA and audience behavior.',
    },
    {
      icon: Music,
      title: 'Pitch Your Music',
      description: 'Premium plan includes unlimited pitching to Spotify playlists, blogs, and TV/film sync opportunities.',
    },
    {
      icon: TrendingUp,
      title: 'Proven Results',
      description: 'Artists using ArtistOS see 25-30% monthly growth vs 12% industry average. Average pitch success rate: 28%.',
    },
  ];

  const faqs = [
    {
      question: 'Can I switch between monthly and annual billing?',
      answer: 'Yes! You can switch at any time. Annual billing saves you money (15-20% off). You can upgrade or downgrade at the end of your billing period.',
    },
    {
      question: 'What\'s included in the 7-day free trial?',
      answer: 'Full access to EVERYTHING! Try all features including music pitching, AI content generation, Brand DNA, analytics, and more. No credit card required to start.',
    },
    {
      question: 'What\'s the difference between Monthly and Premium?',
      answer: 'Premium ($149/mo) adds unlimited music pitching to Spotify playlists, blogs, press, TV/film sync, plus a personal success manager and monthly strategy calls. Monthly ($69/mo) includes all core AI features.',
    },
    {
      question: 'Can I cancel anytime?',
      answer: 'Yes! Cancel anytime with no penalties. Monthly plans cancel immediately, annual plans remain active until the end of your term.',
    },
    {
      question: 'Do you offer refunds?',
      answer: 'Yes, 30-day money-back guarantee on all plans. If you\'re not satisfied, we\'ll refund your first payment, no questions asked.',
    },
    {
      question: 'Is my payment information secure?',
      answer: 'Absolutely! We use Stripe for payment processing (PCI-DSS compliant). We never store your credit card information.',
    },
  ];

  return (
    <div className="space-y-12 pb-12">
      <div className="text-center max-w-3xl mx-auto">
        <h2 className="text-4xl font-bold mb-4">Choose Your Plan</h2>
        <p className="text-lg text-[var(--color-text-secondary)] mb-6">
          Join thousands of independent artists growing their careers with ArtistOS
        </p>

        <div className="inline-flex bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg p-1">
          <button
            onClick={() => setBillingCycle('monthly')}
            className={`px-6 py-2 rounded-md font-medium transition-all ${
              billingCycle === 'monthly'
                ? 'bg-purple-500 text-white'
                : 'text-[var(--color-text-secondary)] hover:text-white'
            }`}
          >
            Monthly
          </button>
          <button
            onClick={() => setBillingCycle('annual')}
            className={`px-6 py-2 rounded-md font-medium transition-all relative ${
              billingCycle === 'annual'
                ? 'bg-purple-500 text-white'
                : 'text-[var(--color-text-secondary)] hover:text-white'
            }`}
          >
            Annual
            <span className="absolute -top-2 -right-2 px-1.5 py-0.5 bg-green-500 text-white text-xs font-bold rounded">
              Save 20%
            </span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <div
            key={plan.name}
            className={`relative rounded-2xl p-8 ${
              plan.popular
                ? 'bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-2 border-purple-500 scale-105'
                : plan.isPremium
                ? 'bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-2 border-yellow-500/50'
                : 'bg-[var(--color-surface)] border border-[var(--color-border)]'
            }`}
          >
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <span className="px-4 py-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-sm font-bold rounded-full shadow-lg">
                  ⭐ MOST POPULAR
                </span>
              </div>
            )}
            {plan.isPremium && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <span className="px-4 py-1 bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-sm font-bold rounded-full shadow-lg flex items-center gap-1">
                  <Crown className="w-4 h-4" />
                  INCLUDES PITCHING
                </span>
              </div>
            )}
            {plan.isFreeTrial && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <span className="px-4 py-1 bg-green-500 text-white text-sm font-bold rounded-full shadow-lg">
                  ✨ TRY IT FREE
                </span>
              </div>
            )}

            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
              <p className="text-sm text-[var(--color-text-secondary)] mb-4 min-h-[40px]">{plan.description}</p>
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-5xl font-bold">{plan.price}</span>
                {!plan.isFreeTrial && (
                  <span className="text-sm text-[var(--color-text-secondary)]">/ {plan.period}</span>
                )}
              </div>
              {plan.isFreeTrial && (
                <p className="text-sm text-green-400 mt-1 font-medium">Full access, {plan.period}</p>
              )}
              {plan.totalPrice && (
                <p className="text-sm text-[var(--color-text-secondary)] mt-2">
                  {plan.totalPrice}
                </p>
              )}
              {plan.savings && (
                <p className="text-sm text-green-400 mt-2 font-bold">{plan.savings}</p>
              )}
              {plan.billedAs && (
                <p className="text-xs text-[var(--color-text-secondary)] mt-2">{plan.billedAs}</p>
              )}
            </div>

            <button
              disabled={plan.disabled}
              className={`w-full py-3 rounded-lg font-bold mb-6 transition-all ${
                plan.isPremium
                  ? 'bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-white shadow-lg'
                  : plan.popular
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg shadow-purple-500/30'
                  : plan.isFreeTrial
                  ? 'bg-green-500 hover:bg-green-600 text-white'
                  : plan.disabled
                  ? 'bg-[var(--color-surface-hover)] text-[var(--color-text-secondary)] cursor-not-allowed'
                  : 'bg-[var(--color-surface-hover)] hover:bg-[var(--color-surface)] border border-[var(--color-border)] hover:border-purple-500'
              }`}
            >
              {plan.cta}
              {!plan.disabled && <ArrowRight className="inline-block w-4 h-4 ml-2" />}
            </button>

            <div className="space-y-2.5">
              {plan.features.map((feature, index) => (
                <div key={index} className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                  <span className="text-xs">{feature}</span>
                </div>
              ))}
              {plan.limitations.map((limitation, index) => (
                <div key={index} className="flex items-start gap-2 opacity-40">
                  <div className="w-4 h-4 flex-shrink-0 mt-0.5 flex items-center justify-center">
                    <div className="w-2.5 h-0.5 bg-[var(--color-text-secondary)] rounded-full" />
                  </div>
                  <span className="text-xs">{limitation}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-2xl p-8">
        <h3 className="text-2xl font-bold text-center mb-8">Why Artists Love ArtistOS</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div key={index} className="text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <h4 className="font-bold text-lg mb-2">{benefit.title}</h4>
                <p className="text-sm text-[var(--color-text-secondary)]">{benefit.description}</p>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <div>
            <p className="text-4xl font-bold text-purple-400 mb-2">25-30%</p>
            <p className="text-sm text-[var(--color-text-secondary)]">Average Monthly Growth</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-pink-400 mb-2">10+</p>
            <p className="text-sm text-[var(--color-text-secondary)]">Hours Saved Per Week</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-blue-400 mb-2">2-3x</p>
            <p className="text-sm text-[var(--color-text-secondary)]">ROI in First Month</p>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto">
        <h3 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h3>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
              <h4 className="font-bold mb-2">{faq.question}</h4>
              <p className="text-sm text-[var(--color-text-secondary)]">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl p-8 text-center text-white">
        <h3 className="text-3xl font-bold mb-4">Ready to Grow Your Music Career?</h3>
        <p className="text-lg mb-6 opacity-90">
          Join thousands of artists using AI to build stronger brands, pitch their music, and reach more fans.
        </p>
        <div className="flex items-center justify-center gap-6 mb-6">
          <div>
            <p className="text-3xl font-bold">28%</p>
            <p className="text-sm opacity-75">Pitch Success Rate</p>
          </div>
          <div className="w-px h-12 bg-white/20"></div>
          <div>
            <p className="text-3xl font-bold">25-30%</p>
            <p className="text-sm opacity-75">Monthly Growth</p>
          </div>
          <div className="w-px h-12 bg-white/20"></div>
          <div>
            <p className="text-3xl font-bold">180K+</p>
            <p className="text-sm opacity-75">Playlist Followers</p>
          </div>
        </div>
        <button className="px-8 py-4 bg-white text-purple-600 font-bold rounded-lg hover:bg-gray-100 transition-all shadow-lg text-lg">
          Start Your 7-Day Free Trial
        </button>
        <p className="text-sm mt-4 opacity-90">Full access • No credit card required • Cancel anytime</p>
        <div className="flex items-center justify-center gap-3 mt-6 pt-6 border-t border-white/20 text-xs opacity-75">
          <Shield className="w-3.5 h-3.5" />
          <span>Secure payment via Stripe • PCI-DSS compliant</span>
        </div>
      </div>

      <div className="space-y-4">
        <SecurityBadge variant="footer" />
        <div className="text-center">
          <p className="text-sm text-[var(--color-text-secondary)]">
            Have questions? <a href="#" className="text-purple-400 hover:text-purple-300 font-medium">Contact our team</a>
          </p>
        </div>
      </div>
    </div>
  );
}
