# Privacy Policy

**Last Updated: June 4, 2026**

## Overview

ArtistOS ("we", "our", "us") respects your privacy and is committed to protecting your personal data.

## Information We Collect

### Account Information
- Name, email address, artist name
- Genre and music style preferences
- Connected platform usernames (public data only)

### Platform Analytics
- Follower counts and growth rates
- Engagement metrics (likes, comments, shares)
- Content performance data
- Audience demographics (aggregated)

### Usage Data
- Features used within ArtistOS
- Session duration and frequency
- Device and browser information

## How We Use Your Data

- **Personalized Recommendations** - AI analysis of your brand and content
- **Performance Tracking** - Monitor your growth across platforms
- **Service Improvement** - Enhance features and user experience
- **Communication** - Send important updates and notifications

## Data Sharing

We do NOT:
- Sell your data to third parties
- Share your data with advertisers
- Access your private messages or unpublished content

We DO share limited data with:
- **Payment Processors** (Stripe) - For subscription billing
- **Platform APIs** (Instagram, TikTok, etc.) - Public metrics only via OAuth
- **Analytics Services** - Anonymized usage data for service improvement

## Your Rights

- **Access** - Request a copy of your data
- **Deletion** - Delete your account and all associated data
- **Portability** - Export your data in standard formats
- **Opt-Out** - Unsubscribe from marketing communications
- **Correction** - Update or correct your information

## Data Security

We implement industry-standard security measures including:
- TLS 1.3 encryption for data in transit
- AES-256 encryption for data at rest
- Regular security audits and penetration testing
- Strict access controls and authentication

## Compliance

ArtistOS is compliant with:
- General Data Protection Regulation (GDPR)
- California Consumer Privacy Act (CCPA)
- Children's Online Privacy Protection Act (COPPA)

## Contact

For privacy concerns: privacy@artistos.com

For security issues: security@artistos.com

---

© 2026 Juan Manuel Kornisiuk. All Rights Reserved.
