-- ArtistOS Production Database Schema
-- Run this in your Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table (extends Supabase auth.users)
CREATE TABLE public.profiles (
    id UUID REFERENCES auth.users(id) PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT,
    artist_name TEXT,
    bio TEXT,
    genre TEXT,
    avatar_url TEXT,
    instagram_handle TEXT,
    spotify_artist_id TEXT,
    tiktok_handle TEXT,
    youtube_channel_id TEXT,
    is_creator BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Subscriptions table
CREATE TABLE public.subscriptions (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    stripe_customer_id TEXT UNIQUE,
    stripe_subscription_id TEXT UNIQUE,
    plan_type TEXT CHECK (plan_type IN ('free', 'monthly', 'quarterly', 'annual', 'creator')),
    status TEXT CHECK (status IN ('active', 'canceled', 'past_due', 'incomplete', 'trialing')),
    current_period_start TIMESTAMP WITH TIME ZONE,
    current_period_end TIMESTAMP WITH TIME ZONE,
    cancel_at_period_end BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Brand DNA table
CREATE TABLE public.brand_dna (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    visual_style JSONB,
    color_palette JSONB,
    music_style JSONB,
    target_audience JSONB,
    brand_voice TEXT,
    key_themes JSONB,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Content ideas table
CREATE TABLE public.content_ideas (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    content_type TEXT,
    platforms JSONB,
    estimated_engagement TEXT,
    difficulty TEXT,
    time_to_create TEXT,
    ai_generated BOOLEAN DEFAULT TRUE,
    saved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Video scenarios table
CREATE TABLE public.video_scenarios (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    content_idea_id UUID REFERENCES public.content_ideas(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    concept_description TEXT,
    hook TEXT,
    setting TEXT,
    visual_style TEXT,
    shot_breakdown JSONB,
    emotional_goal TEXT,
    pro_tips JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Playlist pitches table
CREATE TABLE public.playlist_pitches (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    song_title TEXT NOT NULL,
    artist_name TEXT NOT NULL,
    spotify_track_url TEXT,
    genre TEXT,
    mood TEXT,
    description TEXT,
    pitch_message TEXT,
    target_playlists JSONB,
    status TEXT CHECK (status IN ('draft', 'submitted', 'under_review', 'accepted', 'rejected')) DEFAULT 'draft',
    submission_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Curator contacts table (for pitching CRM)
CREATE TABLE public.curator_contacts (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    email TEXT,
    playlist_name TEXT,
    playlist_url TEXT,
    platform TEXT DEFAULT 'spotify',
    genre TEXT,
    follower_count INTEGER,
    notes TEXT,
    last_contacted TIMESTAMP WITH TIME ZONE,
    response_status TEXT CHECK (response_status IN ('pending', 'responded', 'accepted', 'declined', 'no_response')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Analytics history table
CREATE TABLE public.analytics_history (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    date DATE NOT NULL,
    platform TEXT NOT NULL,
    followers INTEGER,
    engagement_rate NUMERIC,
    views INTEGER,
    likes INTEGER,
    comments INTEGER,
    shares INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Scheduled posts table
CREATE TABLE public.scheduled_posts (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    platform TEXT NOT NULL,
    post_type TEXT,
    title TEXT,
    content TEXT,
    media_urls JSONB,
    scheduled_for TIMESTAMP WITH TIME ZONE NOT NULL,
    status TEXT CHECK (status IN ('scheduled', 'posted', 'failed', 'cancelled')) DEFAULT 'scheduled',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Email notifications log
CREATE TABLE public.email_notifications (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    email_type TEXT NOT NULL,
    recipient_email TEXT NOT NULL,
    subject TEXT,
    sent_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    status TEXT CHECK (status IN ('sent', 'failed', 'pending')) DEFAULT 'pending',
    error_message TEXT
);

-- Row Level Security (RLS) Policies

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.brand_dna ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_ideas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.video_scenarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.playlist_pitches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.curator_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scheduled_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_notifications ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- Subscriptions policies
CREATE POLICY "Users can view own subscription" ON public.subscriptions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own subscription" ON public.subscriptions FOR UPDATE USING (auth.uid() = user_id);

-- Brand DNA policies
CREATE POLICY "Users can view own brand DNA" ON public.brand_dna FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own brand DNA" ON public.brand_dna FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own brand DNA" ON public.brand_dna FOR UPDATE USING (auth.uid() = user_id);

-- Content ideas policies
CREATE POLICY "Users can view own content ideas" ON public.content_ideas FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own content ideas" ON public.content_ideas FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own content ideas" ON public.content_ideas FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own content ideas" ON public.content_ideas FOR DELETE USING (auth.uid() = user_id);

-- Video scenarios policies
CREATE POLICY "Users can view own video scenarios" ON public.video_scenarios FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own video scenarios" ON public.video_scenarios FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own video scenarios" ON public.video_scenarios FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own video scenarios" ON public.video_scenarios FOR DELETE USING (auth.uid() = user_id);

-- Playlist pitches policies
CREATE POLICY "Users can view own pitches" ON public.playlist_pitches FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own pitches" ON public.playlist_pitches FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own pitches" ON public.playlist_pitches FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own pitches" ON public.playlist_pitches FOR DELETE USING (auth.uid() = user_id);

-- Curator contacts policies
CREATE POLICY "Users can view own curator contacts" ON public.curator_contacts FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own curator contacts" ON public.curator_contacts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own curator contacts" ON public.curator_contacts FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own curator contacts" ON public.curator_contacts FOR DELETE USING (auth.uid() = user_id);

-- Analytics history policies
CREATE POLICY "Users can view own analytics" ON public.analytics_history FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own analytics" ON public.analytics_history FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Scheduled posts policies
CREATE POLICY "Users can view own scheduled posts" ON public.scheduled_posts FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own scheduled posts" ON public.scheduled_posts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own scheduled posts" ON public.scheduled_posts FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own scheduled posts" ON public.scheduled_posts FOR DELETE USING (auth.uid() = user_id);

-- Email notifications policies
CREATE POLICY "Users can view own email notifications" ON public.email_notifications FOR SELECT USING (auth.uid() = user_id);

-- Functions

-- Function to automatically create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
    is_creator_email BOOLEAN;
BEGIN
    -- Check if email is creator email
    is_creator_email := NEW.email IN ('juanmanuelkornisiuk@gmail.com', 'juan@artistos.com', 'admin@artistos.com');

    -- Create profile
    INSERT INTO public.profiles (id, email, full_name, is_creator)
    VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name', is_creator_email);

    -- Create subscription
    INSERT INTO public.subscriptions (user_id, plan_type, status)
    VALUES (NEW.id, CASE WHEN is_creator_email THEN 'creator' ELSE 'free' END, 'active');

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create profile on signup
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER set_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER set_subscriptions_updated_at BEFORE UPDATE ON public.subscriptions FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER set_brand_dna_updated_at BEFORE UPDATE ON public.brand_dna FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER set_playlist_pitches_updated_at BEFORE UPDATE ON public.playlist_pitches FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER set_curator_contacts_updated_at BEFORE UPDATE ON public.curator_contacts FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER set_scheduled_posts_updated_at BEFORE UPDATE ON public.scheduled_posts FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- Indexes for performance
CREATE INDEX idx_profiles_email ON public.profiles(email);
CREATE INDEX idx_subscriptions_user_id ON public.subscriptions(user_id);
CREATE INDEX idx_subscriptions_stripe_customer_id ON public.subscriptions(stripe_customer_id);
CREATE INDEX idx_content_ideas_user_id ON public.content_ideas(user_id);
CREATE INDEX idx_playlist_pitches_user_id ON public.playlist_pitches(user_id);
CREATE INDEX idx_playlist_pitches_status ON public.playlist_pitches(status);
CREATE INDEX idx_curator_contacts_user_id ON public.curator_contacts(user_id);
CREATE INDEX idx_analytics_history_user_id ON public.analytics_history(user_id);
CREATE INDEX idx_analytics_history_date ON public.analytics_history(date);
CREATE INDEX idx_scheduled_posts_user_id ON public.scheduled_posts(user_id);
CREATE INDEX idx_scheduled_posts_scheduled_for ON public.scheduled_posts(scheduled_for);
