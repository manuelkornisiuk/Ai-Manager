import { Crown, Lock, Sparkles, CheckCircle } from 'lucide-react';

interface PremiumFeatureGateProps {
  featureName: string;
  currentPlan?: 'free' | 'monthly' | 'quarterly' | 'annual';
}

export default function PremiumFeatureGate({ featureName, currentPlan = 'monthly' }: PremiumFeatureGateProps) {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[var(--color-surface)] border-2 border-purple-500/50 rounded-2xl p-8 max-w-2xl w-full relative">
        <div className="absolute -top-6 left-1/2 -translate-x-1/2">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center shadow-lg">
            <Crown className="w-6 h-6 text-white" />
          </div>
        </div>

        <div className="text-center mt-4 mb-6">
          <h2 className="text-3xl font-bold mb-2">Premium Feature</h2>
          <p className="text-lg text-[var(--color-text-secondary)]">
            {featureName} is available exclusively with the Annual Plan
          </p>
        </div>

        <div className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 rounded-xl p-6 mb-6">
          <div className="flex items-center gap-3 mb-4">
            <Crown className="w-6 h-6 text-yellow-400" />
            <h3 className="text-xl font-bold">Upgrade to Premium Plan</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
              <p className="text-2xl font-bold text-yellow-400 mb-1">$149/mo</p>
              <p className="text-sm text-[var(--color-text-secondary)]">or $119/mo annually</p>
              <p className="text-xs text-green-400 mt-1">Save $360 with annual plan</p>
            </div>
            <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
              <p className="text-2xl font-bold text-green-400 mb-1">28% Success</p>
              <p className="text-sm text-[var(--color-text-secondary)]">Average pitch acceptance rate</p>
            </div>
          </div>

          <div className="space-y-2 mb-4">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Pitch to Spotify playlists (180K+ followers)</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Submit to major blogs & press (2.5M+ readers)</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Get sync deals for TV, film, ads ($2K-$15K)</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>AI-matched opportunities (90%+ match rate)</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Track submissions & analytics</span>
            </div>
          </div>

          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3">
            <p className="text-sm text-green-400 flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              <strong>Bonus:</strong> 7-day free trial included - Try before you commit
            </p>
          </div>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => {
              // In real app, this would navigate to pricing or close modal
              window.location.hash = 'pricing';
            }}
            className="flex-1 px-6 py-3 bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-white rounded-lg font-bold transition-all"
          >
            Upgrade to Premium Plan
          </button>
          <button
            onClick={() => {
              // In real app, this would close the modal
              window.history.back();
            }}
            className="px-6 py-3 bg-[var(--color-surface)] border border-[var(--color-border)] hover:bg-[var(--color-surface-hover)] rounded-lg font-medium transition-colors"
          >
            Maybe Later
          </button>
        </div>

        <p className="text-center text-xs text-[var(--color-text-secondary)] mt-4">
          Your current plan: <span className="capitalize font-medium">{currentPlan}</span>
        </p>
      </div>
    </div>
  );
}
