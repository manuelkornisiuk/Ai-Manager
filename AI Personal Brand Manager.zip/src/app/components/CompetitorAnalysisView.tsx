import { TrendingUp, Users, Clock, Target, Lightbulb, CheckCircle, ArrowRight, Award, Zap } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

export default function CompetitorAnalysisView() {
  const topArtists = [
    {
      name: 'Tyler, The Creator',
      followers: '12.4M',
      genre: 'Alternative Hip-Hop',
      avgEngagement: '14.2%',
      monthlyGrowth: '+8.5%',
      strengths: [
        'Consistent visual aesthetic (pastel colors, retro vibes)',
        'Posts 3-5x daily across platforms',
        'Heavy use of storytelling and narrative content',
        'Strong merchandise integration',
        'Personal, unfiltered communication style',
      ],
      contentMix: {
        'Behind-the-scenes': 35,
        'Performance clips': 25,
        'Lifestyle/Personal': 20,
        'Fan interaction': 15,
        'Product/Merch': 5,
      },
      bestPractices: [
        'Posts during peak hours (6-9 PM EST) - 78% of content',
        'Uses carousel posts for storytelling - 2x engagement',
        'Responds to comments within first hour - builds loyalty',
        'Teases unreleased music in Stories - creates anticipation',
      ],
    },
    {
      name: 'Vince Staples',
      followers: '2.1M',
      genre: 'Alternative Hip-Hop',
      avgEngagement: '11.8%',
      monthlyGrowth: '+6.2%',
      strengths: [
        'Witty, conversational social media presence',
        'Minimalist visual aesthetic (black, white, red)',
        'Heavy Twitter/X engagement (text-based)',
        'Uses humor and controversy strategically',
        'Authentic, no-filter personality',
      ],
      contentMix: {
        'Text posts/Tweets': 40,
        'Behind-the-scenes': 25,
        'Performance clips': 20,
        'Commentary/Opinion': 10,
        'Lifestyle': 5,
      },
      bestPractices: [
        'Daily Twitter engagement - keeps audience connected',
        'Short, punchy video clips (under 30 seconds)',
        'Controversial takes generate discussion and shares',
        'Minimal editing - raw, authentic feel',
      ],
    },
    {
      name: 'Smino',
      followers: '891K',
      genre: 'Alternative Hip-Hop',
      avgEngagement: '9.4%',
      monthlyGrowth: '+12.3%',
      strengths: [
        'Vibrant, colorful visual identity',
        'Community-focused content strategy',
        'Regional pride (St. Louis) as brand pillar',
        'Collaborative content with other artists',
        'Playful, experimental aesthetic',
      ],
      contentMix: {
        'Behind-the-scenes': 30,
        'Lifestyle/Cultural': 25,
        'Performance clips': 20,
        'Collaborations': 15,
        'Fan interaction': 10,
      },
      bestPractices: [
        'Highlights hometown and culture - builds authentic connection',
        'Features other artists regularly - expands reach',
        'Uses bright colors and energetic editing',
        'Shows personality beyond music - relatability',
      ],
    },
  ];

  const yourProfile = {
    name: 'Jordan Beats',
    followers: '47.2K',
    avgEngagement: '8.4%',
    monthlyGrowth: '+12.3%',
  };

  const comparisonData = [
    {
      metric: 'Posting Frequency',
      you: 65,
      'Genre Average': 85,
      'Successful Artists': 95,
    },
    {
      metric: 'Visual Consistency',
      you: 87,
      'Genre Average': 72,
      'Successful Artists': 92,
    },
    {
      metric: 'Engagement Rate',
      you: 84,
      'Genre Average': 78,
      'Successful Artists': 91,
    },
    {
      metric: 'Response Time',
      you: 68,
      'Genre Average': 71,
      'Successful Artists': 94,
    },
    {
      metric: 'Content Variety',
      you: 65,
      'Genre Average': 80,
      'Successful Artists': 88,
    },
  ];

  const radarData = [
    { category: 'Visual Identity', you: 87, topArtists: 92 },
    { category: 'Engagement', you: 84, topArtists: 91 },
    { category: 'Posting Frequency', you: 65, topArtists: 95 },
    { category: 'Response Rate', you: 68, topArtists: 94 },
    { category: 'Content Quality', you: 78, topArtists: 89 },
    { category: 'Brand Consistency', you: 82, topArtists: 90 },
  ];

  const actionableInsights = [
    {
      title: 'Increase Posting Frequency',
      gap: 'You post 4x/week. Top artists post 5-7x/week.',
      recommendation: 'Add 2-3 more posts per week during 6-9 PM EST. Focus on quick behind-the-scenes clips and Stories.',
      impact: 'High',
      difficulty: 'Easy',
      expectedResult: '+15-20% reach, +8% engagement',
    },
    {
      title: 'Adopt Storytelling Approach',
      gap: 'Top artists use carousel posts and multi-part narratives.',
      recommendation: 'Create 2 carousel posts per week telling the story behind your tracks. Use 5-7 slides with cohesive visual flow.',
      impact: 'High',
      difficulty: 'Medium',
      expectedResult: '+30% engagement on carousel posts',
    },
    {
      title: 'Respond to Comments Faster',
      gap: 'You respond to 64% of comments. Top artists respond to 90%+ within first hour.',
      recommendation: 'Set aside 15 minutes after each post to respond to all comments. Use saved replies for common questions.',
      impact: 'Medium',
      difficulty: 'Easy',
      expectedResult: '+12% audience loyalty, better algorithm boost',
    },
    {
      title: 'Show More Personality',
      gap: 'Top artists share personal opinions, humor, and daily life.',
      recommendation: 'Post 3-4 text-based Stories daily showing your thoughts, reactions, or behind-the-scenes moments. Be unfiltered.',
      impact: 'High',
      difficulty: 'Easy',
      expectedResult: '+25% audience connection, more shares',
    },
    {
      title: 'Create Collaborative Content',
      gap: 'Smino features other artists in 15% of content.',
      recommendation: 'Collaborate with 2-3 other artists monthly. Create split-screen content, remixes, or joint live sessions.',
      impact: 'High',
      difficulty: 'Hard',
      expectedResult: '+40% reach through cross-promotion',
    },
  ];

  const successPatterns = [
    {
      pattern: 'Consistent Visual Identity',
      artists: ['Tyler, The Creator', 'Smino'],
      description: 'Top artists maintain strict color palettes and visual themes across all content.',
      yourStatus: 'Strong',
      action: 'You already have this! Keep using purple/pink aesthetic.',
    },
    {
      pattern: 'Daily Audience Touch Points',
      artists: ['Vince Staples', 'Tyler, The Creator'],
      description: 'Successful artists post something (even small) every single day to stay top of mind.',
      yourStatus: 'Needs Work',
      action: 'Add daily Stories showing work-in-progress, thoughts, or quick updates.',
    },
    {
      pattern: 'Authentic Personality',
      artists: ['Vince Staples', 'Tyler, The Creator'],
      description: 'Being unfiltered and genuine creates deeper fan connections than polished perfection.',
      yourStatus: 'Moderate',
      action: 'Show more raw moments - failures, frustrations, real creative process.',
    },
    {
      pattern: 'Strategic Controversy',
      artists: ['Vince Staples'],
      description: 'Hot takes and controversial opinions (done tastefully) drive discussion and shares.',
      yourStatus: 'Not Using',
      action: 'Share opinions on music industry topics, current events in hip-hop.',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Genre Insights</h2>
        <p className="text-[var(--color-text-secondary)] mt-1">
          Learn from successful Alternative Hip-Hop artists to accelerate your growth
        </p>
      </div>

      <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6">
        <h3 className="text-xl font-bold mb-4">Your Position in Alternative Hip-Hop</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
            <p className="text-sm text-[var(--color-text-secondary)] mb-1">Your Followers</p>
            <p className="text-2xl font-bold text-purple-400">{yourProfile.followers}</p>
          </div>
          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
            <p className="text-sm text-[var(--color-text-secondary)] mb-1">Engagement Rate</p>
            <p className="text-2xl font-bold text-pink-400">{yourProfile.avgEngagement}</p>
            <p className="text-xs text-green-400 mt-1">Above genre average (7.8%)</p>
          </div>
          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
            <p className="text-sm text-[var(--color-text-secondary)] mb-1">Growth Rate</p>
            <p className="text-2xl font-bold text-blue-400">{yourProfile.monthlyGrowth}</p>
            <p className="text-xs text-green-400 mt-1">Top 15% of genre</p>
          </div>
          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
            <p className="text-sm text-[var(--color-text-secondary)] mb-1">Potential Reach</p>
            <p className="text-2xl font-bold text-green-400">500K+</p>
            <p className="text-xs text-[var(--color-text-secondary)] mt-1">With optimizations</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <div className="mb-4">
            <h3 className="text-xl font-bold">Growth Opportunities</h3>
            <p className="text-sm text-[var(--color-text-secondary)]">See where you can improve the most</p>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={comparisonData}>
              <CartesianGrid key="comparison-grid" strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis key="comparison-xaxis" dataKey="metric" stroke="var(--color-text-secondary)" angle={-45} textAnchor="end" height={100} fontSize={12} />
              <YAxis key="comparison-yaxis" stroke="var(--color-text-secondary)" />
              <Tooltip
                key="comparison-tooltip"
                contentStyle={{
                  backgroundColor: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px'
                }}
              />
              <Bar key="you-bar" dataKey="you" fill="#8B5CF6" name="You" />
              <Bar key="average-bar" dataKey="Genre Average" fill="#6B7280" name="Genre Average" />
              <Bar key="top-bar" dataKey="Successful Artists" fill="#EC4899" name="Successful Artists" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
          <div className="mb-4">
            <h3 className="text-xl font-bold">Your Strengths & Next Steps</h3>
            <p className="text-sm text-[var(--color-text-secondary)]">You're doing great in visual consistency!</p>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={radarData}>
              <PolarGrid key="radar-grid" stroke="var(--color-border)" />
              <PolarAngleAxis key="radar-angle" dataKey="category" stroke="var(--color-text-secondary)" fontSize={12} />
              <PolarRadiusAxis key="radar-radius" stroke="var(--color-text-secondary)" />
              <Radar key="radar-you" name="You" dataKey="you" stroke="#8B5CF6" fill="#8B5CF6" fillOpacity={0.5} />
              <Radar key="radar-top" name="Successful Artists" dataKey="topArtists" stroke="#EC4899" fill="#EC4899" fillOpacity={0.3} />
              <Tooltip
                key="radar-tooltip"
                contentStyle={{
                  backgroundColor: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px'
                }}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <div className="mb-4">
          <h3 className="text-xl font-bold">🎯 What to Focus On Next</h3>
          <p className="text-sm text-[var(--color-text-secondary)]">Priority actions that will move the needle</p>
        </div>
        <div className="space-y-4">
          {actionableInsights.map((insight, index) => (
            <div key={index} className="p-5 bg-[var(--color-background)] rounded-xl border border-[var(--color-border)]">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h4 className="font-bold text-lg mb-1">{insight.title}</h4>
                  <p className="text-sm text-[var(--color-text-secondary)] mb-2">{insight.gap}</p>
                </div>
                <div className="flex gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    insight.impact === 'High' ? 'bg-red-500/20 text-red-300' : 'bg-yellow-500/20 text-yellow-300'
                  }`}>
                    {insight.impact} Impact
                  </span>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    insight.difficulty === 'Easy' ? 'bg-green-500/20 text-green-300' :
                    insight.difficulty === 'Medium' ? 'bg-yellow-500/20 text-yellow-300' :
                    'bg-red-500/20 text-red-300'
                  }`}>
                    {insight.difficulty}
                  </span>
                </div>
              </div>

              <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-4 mb-3">
                <p className="text-sm font-medium mb-1">📋 Recommendation:</p>
                <p className="text-sm">{insight.recommendation}</p>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  <Zap className="w-4 h-4 text-green-500" />
                  <span className="text-green-400 font-medium">{insight.expectedResult}</span>
                </div>
                <button className="px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-medium transition-all text-sm">
                  Apply Strategy
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <h3 className="text-xl font-bold mb-4">Success Patterns in Alternative Hip-Hop</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {successPatterns.map((pattern, index) => (
            <div key={index} className="p-4 bg-[var(--color-background)] rounded-lg">
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-bold">{pattern.pattern}</h4>
                <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                  pattern.yourStatus === 'Strong' ? 'bg-green-500/20 text-green-300' :
                  pattern.yourStatus === 'Moderate' ? 'bg-yellow-500/20 text-yellow-300' :
                  'bg-red-500/20 text-red-300'
                }`}>
                  {pattern.yourStatus}
                </span>
              </div>
              <p className="text-xs text-purple-400 mb-2">
                Used by: {pattern.artists.join(', ')}
              </p>
              <p className="text-sm text-[var(--color-text-secondary)] mb-3">
                {pattern.description}
              </p>
              <div className="bg-blue-500/10 border border-blue-500/20 rounded p-3">
                <p className="text-xs font-medium text-blue-400 mb-1">Your Action:</p>
                <p className="text-xs">{pattern.action}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {topArtists.map((artist, index) => (
          <div key={index} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-2xl font-bold mb-1">{artist.name}</h3>
                <p className="text-sm text-[var(--color-text-secondary)]">{artist.genre}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-purple-400">{artist.followers}</p>
                <p className="text-xs text-[var(--color-text-secondary)]">followers</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="bg-[var(--color-background)] rounded-lg p-3">
                <p className="text-xs text-[var(--color-text-secondary)] mb-1">Engagement</p>
                <p className="text-lg font-bold">{artist.avgEngagement}</p>
              </div>
              <div className="bg-[var(--color-background)] rounded-lg p-3">
                <p className="text-xs text-[var(--color-text-secondary)] mb-1">Growth</p>
                <p className="text-lg font-bold text-green-400">{artist.monthlyGrowth}</p>
              </div>
              <div className="bg-[var(--color-background)] rounded-lg p-3">
                <p className="text-xs text-[var(--color-text-secondary)] mb-1">Rank</p>
                <p className="text-lg font-bold text-yellow-400">#{index + 1}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="font-bold mb-2 flex items-center gap-2">
                  <Award className="w-4 h-4 text-yellow-500" />
                  Key Strengths
                </p>
                <ul className="space-y-1">
                  {artist.strengths.map((strength, i) => (
                    <li key={i} className="text-sm text-[var(--color-text-secondary)] flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                      <span>{strength}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <p className="font-bold mb-2 flex items-center gap-2">
                  <Lightbulb className="w-4 h-4 text-yellow-500" />
                  Best Practices
                </p>
                <ul className="space-y-1">
                  {artist.bestPractices.map((practice, i) => (
                    <li key={i} className="text-sm text-[var(--color-text-secondary)] flex items-start gap-2">
                      <ArrowRight className="w-4 h-4 text-purple-500 flex-shrink-0 mt-0.5" />
                      <span>{practice}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-[var(--color-border)]">
              <p className="font-bold mb-2 text-sm">Content Mix</p>
              <div className="space-y-2">
                {Object.entries(artist.contentMix).map(([type, percentage]) => (
                  <div key={type}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs">{type}</span>
                      <span className="text-xs text-[var(--color-text-secondary)]">{percentage}%</span>
                    </div>
                    <div className="h-1.5 bg-[var(--color-background)] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
