import { Shield, Lock, Check } from 'lucide-react';

interface SecurityBadgeProps {
  variant?: 'inline' | 'footer' | 'banner';
}

export default function SecurityBadge({ variant = 'inline' }: SecurityBadgeProps) {
  if (variant === 'banner') {
    return (
      <div className="flex items-center gap-4 px-4 py-3 bg-green-500/10 border border-green-500/20 rounded-lg">
        <Shield className="w-5 h-5 text-green-500 flex-shrink-0" />
        <div className="flex-1">
          <p className="text-sm font-medium text-green-500">Bank-Level Security</p>
          <p className="text-xs text-[var(--color-text-secondary)]">
            256-bit encryption • GDPR compliant • Zero data selling
          </p>
        </div>
      </div>
    );
  }

  if (variant === 'footer') {
    return (
      <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-[var(--color-text-secondary)]">
        <div className="flex items-center gap-1.5">
          <Shield className="w-3.5 h-3.5" />
          <span>256-bit Encrypted</span>
        </div>
        <span className="text-[var(--color-border)]">•</span>
        <div className="flex items-center gap-1.5">
          <Lock className="w-3.5 h-3.5" />
          <span>GDPR Compliant</span>
        </div>
        <span className="text-[var(--color-border)]">•</span>
        <div className="flex items-center gap-1.5">
          <Check className="w-3.5 h-3.5" />
          <span>SOC 2 Type II Certified</span>
        </div>
        <span className="text-[var(--color-border)]">•</span>
        <div className="flex items-center gap-1.5">
          <Shield className="w-3.5 h-3.5" />
          <span>Zero Data Selling</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 text-xs text-[var(--color-text-secondary)]">
      <Shield className="w-3.5 h-3.5 text-green-500" />
      <span>Secured & Encrypted</span>
    </div>
  );
}
