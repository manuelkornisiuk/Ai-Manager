Copyright (c) 2026 Juan Manuel Kornisiuk. All Rights Reserved.

ArtistOS - AI-Powered Personal Brand Manager for Musicians

This software and associated documentation files (the "Software") are the
proprietary and confidential information of Juan Manuel Kornisiuk.

All rights reserved. No part of this Software may be reproduced, distributed,
or transmitted in any form or by any means, including photocopying, recording,
or other electronic or mechanical methods, without the prior written permission
of the copyright holder, except in the case of brief quotations embodied in
critical reviews and certain other noncommercial uses permitted by copyright law.

For permission requests, contact: Juan Manuel Kornisiuk

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
