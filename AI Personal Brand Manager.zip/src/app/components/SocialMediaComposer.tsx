import { useState, useEffect } from 'react';
import { X, Image, Calendar, Send, Loader, Instagram, Music2, Youtube, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ConnectedAccount, Platform, PostSchedule, getMockConnectedAccounts, publishPost } from '../../lib/socialMedia';

interface SocialMediaComposerProps {
  isOpen: boolean;
  onClose: () => void;
  defaultContent?: string;
  defaultMediaUrls?: string[];
}

export default function SocialMediaComposer({
  isOpen,
  onClose,
  defaultContent = '',
  defaultMediaUrls = [],
}: SocialMediaComposerProps) {
  const { user } = useAuth();
  const [connectedAccounts, setConnectedAccounts] = useState<ConnectedAccount[]>([]);
  const [selectedPlatforms, setSelectedPlatforms] = useState<Platform[]>([]);
  const [content, setContent] = useState(defaultContent);
  const [mediaUrls, setMediaUrls] = useState<string[]>(defaultMediaUrls);
  const [scheduleDate, setScheduleDate] = useState('');
  const [scheduleTime, setScheduleTime] = useState('');
  const [isScheduled, setIsScheduled] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishStatus, setPublishStatus] = useState<{ platform: Platform; status: 'success' | 'error'; message?: string }[]>([]);

  useEffect(() => {
    if (isOpen) {
      loadConnectedAccounts();
      setContent(defaultContent);
      setMediaUrls(defaultMediaUrls);
    }
  }, [isOpen, defaultContent, defaultMediaUrls]);

  const loadConnectedAccounts = async () => {
    try {
      const accounts = getMockConnectedAccounts();
      setConnectedAccounts(accounts.filter(acc => acc.isActive));
    } catch (error) {
      console.error('Failed to load connected accounts:', error);
    }
  };

  const togglePlatform = (platform: Platform) => {
    setSelectedPlatforms(prev =>
      prev.includes(platform)
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };

  const handleMediaUrlAdd = () => {
    const url = prompt('Enter media URL (image or video):');
    if (url) {
      setMediaUrls(prev => [...prev, url]);
    }
  };

  const handleMediaUrlRemove = (index: number) => {
    setMediaUrls(prev => prev.filter((_, i) => i !== index));
  };

  const getCharacterLimit = () => {
    if (selectedPlatforms.includes('instagram')) return 2200;
    if (selectedPlatforms.includes('tiktok')) return 2200;
    if (selectedPlatforms.includes('youtube')) return 5000;
    return 2200;
  };

  const getPlatformIcon = (platform: Platform) => {
    switch (platform) {
      case 'instagram':
        return <Instagram className="w-4 h-4" />;
      case 'tiktok':
        return <Music2 className="w-4 h-4" />;
      case 'youtube':
        return <Youtube className="w-4 h-4" />;
    }
  };

  const handlePublish = async () => {
    if (selectedPlatforms.length === 0) {
      alert('Please select at least one platform');
      return;
    }

    if (!content.trim()) {
      alert('Please enter content for your post');
      return;
    }

    setIsPublishing(true);
    setPublishStatus([]);

    try {
      if (isScheduled) {
        // Schedule post for later
        const scheduledFor = new Date(`${scheduleDate}T${scheduleTime}`);

        // In production: save to database with scheduled status
        console.log('Scheduling post:', {
          platforms: selectedPlatforms,
          content,
          mediaUrls,
          scheduledFor: scheduledFor.toISOString(),
        });

        await new Promise(resolve => setTimeout(resolve, 1500));
        alert(`✅ Post scheduled successfully for ${scheduledFor.toLocaleString()}!`);
        onClose();
      } else {
        // Publish immediately to all selected platforms
        const results = await Promise.allSettled(
          selectedPlatforms.map(async (platform) => {
            const account = connectedAccounts.find(acc => acc.platform === platform);
            if (!account) throw new Error(`No account found for ${platform}`);

            try {
              const result = await publishPost(platform, account.accessToken, content, mediaUrls);
              return { platform, status: 'success' as const, result };
            } catch (error) {
              return { platform, status: 'error' as const, message: (error as Error).message };
            }
          })
        );

        const statuses = results.map((result, index) => {
          if (result.status === 'fulfilled') {
            return result.value;
          } else {
            return {
              platform: selectedPlatforms[index],
              status: 'error' as const,
              message: result.reason.message,
            };
          }
        });

        setPublishStatus(statuses);

        // In demo mode, simulate success
        setTimeout(() => {
          const allSuccess = statuses.every(s => s.status === 'success');
          if (allSuccess) {
            alert('✅ Published successfully to all platforms!');
            onClose();
          }
        }, 2000);
      }
    } catch (error) {
      console.error('Failed to publish:', error);
      alert('Failed to publish. Please try again.');
    } finally {
      setIsPublishing(false);
    }
  };

  if (!isOpen) return null;

  const characterLimit = getCharacterLimit();
  const characterCount = content.length;
  const isOverLimit = characterCount > characterLimit;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[var(--color-surface)] rounded-xl border border-[var(--color-border)] w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-[var(--color-surface)] border-b border-[var(--color-border)] p-6 flex items-center justify-between">
          <div>
            <h3 className="text-2xl font-bold">Create Social Post</h3>
            <p className="text-sm text-[var(--color-text-secondary)] mt-1">
              Publish to multiple platforms at once
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-lg hover:bg-[var(--color-surface-hover)] flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Platform Selection */}
          <div>
            <label className="block text-sm font-medium mb-3">Select Platforms</label>
            {connectedAccounts.length === 0 ? (
              <div className="bg-yellow-500/10 border border-yellow-500/50 rounded-lg p-4">
                <p className="text-sm text-yellow-400 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  No connected accounts. Please connect your social media accounts first.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {connectedAccounts.map((account) => {
                  const isSelected = selectedPlatforms.includes(account.platform);
                  return (
                    <button
                      key={account.accountId}
                      onClick={() => togglePlatform(account.platform)}
                      className={`p-4 border rounded-lg transition-all text-left ${
                        isSelected
                          ? 'bg-purple-500/20 border-purple-500'
                          : 'bg-[var(--color-background)] border-[var(--color-border)] hover:border-purple-500/50'
                      }`}
                    >
                      <div className="flex items-center gap-3 mb-2">
                        {getPlatformIcon(account.platform)}
                        <span className="font-medium capitalize">{account.platform}</span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-purple-400 ml-auto" />}
                      </div>
                      <p className="text-xs text-[var(--color-text-secondary)]">{account.username}</p>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Content */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium">Post Content</label>
              <span
                className={`text-xs ${
                  isOverLimit ? 'text-red-400' : 'text-[var(--color-text-secondary)]'
                }`}
              >
                {characterCount} / {characterLimit}
              </span>
            </div>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What do you want to share?"
              rows={8}
              className={`w-full px-4 py-3 bg-[var(--color-background)] border rounded-lg focus:outline-none focus:border-purple-500 resize-none ${
                isOverLimit ? 'border-red-500' : 'border-[var(--color-border)]'
              }`}
            />
            {isOverLimit && (
              <p className="text-xs text-red-400 mt-2">Content exceeds character limit</p>
            )}
          </div>

          {/* Media */}
          <div>
            <label className="block text-sm font-medium mb-2">Media (Optional)</label>
            <div className="space-y-2">
              {mediaUrls.map((url, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 p-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg"
                >
                  <Image className="w-4 h-4 text-[var(--color-text-secondary)]" />
                  <span className="text-sm flex-1 truncate">{url}</span>
                  <button
                    onClick={() => handleMediaUrlRemove(index)}
                    className="text-red-400 hover:text-red-300 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
              <button
                onClick={handleMediaUrlAdd}
                className="w-full p-3 border-2 border-dashed border-[var(--color-border)] hover:border-purple-500/50 rounded-lg text-sm text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] transition-all flex items-center justify-center gap-2"
              >
                <Image className="w-4 h-4" />
                Add Media URL
              </button>
            </div>
          </div>

          {/* Scheduling */}
          <div className="border-t border-[var(--color-border)] pt-6">
            <div className="flex items-center gap-3 mb-4">
              <input
                type="checkbox"
                id="schedule-toggle"
                checked={isScheduled}
                onChange={(e) => setIsScheduled(e.target.checked)}
                className="w-4 h-4"
              />
              <label htmlFor="schedule-toggle" className="text-sm font-medium cursor-pointer">
                Schedule for later
              </label>
            </div>

            {isScheduled && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-2">Date</label>
                  <input
                    type="date"
                    value={scheduleDate}
                    onChange={(e) => setScheduleDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm mb-2">Time</label>
                  <input
                    type="time"
                    value={scheduleTime}
                    onChange={(e) => setScheduleTime(e.target.value)}
                    className="w-full px-4 py-3 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Publish Status */}
          {publishStatus.length > 0 && (
            <div className="space-y-2">
              {publishStatus.map(({ platform, status, message }) => (
                <div
                  key={platform}
                  className={`p-3 rounded-lg border ${
                    status === 'success'
                      ? 'bg-green-500/10 border-green-500/50'
                      : 'bg-red-500/10 border-red-500/50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {status === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-red-400" />
                    )}
                    <span className="text-sm font-medium capitalize">{platform}</span>
                    <span className={`text-sm ml-auto ${status === 'success' ? 'text-green-400' : 'text-red-400'}`}>
                      {status === 'success' ? 'Published' : 'Failed'}
                    </span>
                  </div>
                  {message && (
                    <p className="text-xs text-[var(--color-text-secondary)] mt-1">{message}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="sticky bottom-0 bg-[var(--color-surface)] border-t border-[var(--color-border)] p-6 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-6 py-3 bg-[var(--color-background)] border border-[var(--color-border)] hover:bg-[var(--color-surface-hover)] rounded-lg font-medium transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handlePublish}
            disabled={
              isPublishing ||
              selectedPlatforms.length === 0 ||
              !content.trim() ||
              isOverLimit ||
              (isScheduled && (!scheduleDate || !scheduleTime))
            }
            className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-bold transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isPublishing ? (
              <>
                <Loader className="w-5 h-5 animate-spin" />
                {isScheduled ? 'Scheduling...' : 'Publishing...'}
              </>
            ) : (
              <>
                {isScheduled ? (
                  <>
                    <Calendar className="w-5 h-5" />
                    Schedule Post
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Publish Now
                  </>
                )}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
