import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type UserPlan = 'free' | 'professional' | 'premium' | 'creator';

interface User {
  id: string;
  email: string;
  name: string;
  plan: UserPlan;
  isCreator: boolean;
}

interface AuthContextType {
  user: User | null;
  isCreator: boolean;
  hasPremiumAccess: boolean;
  setUser: (user: User | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// CREATOR CONFIGURATION
// Juan Manuel Kornisiuk - Owner with FREE lifetime access
const CREATOR_EMAILS = [
  'juanmanuelkornisiuk@gmail.com', // Juan's real email - FREE FOREVER
  'juan@artistos.com',
  'admin@artistos.com',
];

// Or use a creator ID if you prefer
const CREATOR_IDS = [
  'creator-001',
  'juan-kornisiuk',
];

export function AuthProvider({ children }: { children: ReactNode }) {
  // Simulated user - in real app, this would come from your auth system
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('artistos-user');
    if (savedUser) {
      return JSON.parse(savedUser);
    }

    return {
      id: 'creator-001',
      email: 'juanmanuelkornisiuk@gmail.com',
      name: 'Juan Manuel Kornisiuk',
      plan: 'creator' as UserPlan,
      isCreator: true,
    };
  });

  const isCreator = user ? (
    CREATOR_EMAILS.includes(user.email.toLowerCase()) ||
    CREATOR_IDS.includes(user.id) ||
    user.isCreator === true ||
    user.plan === 'creator'
  ) : false;

  const hasPremiumAccess = isCreator || user?.plan === 'premium';

  useEffect(() => {
    if (user) {
      localStorage.setItem('artistos-user', JSON.stringify(user));
    } else {
      localStorage.removeItem('artistos-user');
    }
  }, [user]);

  return (
    <AuthContext.Provider value={{ user, isCreator, hasPremiumAccess, setUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
