import { Lightbulb, Clock, TrendingUp, Target, CheckCircle, AlertCircle, Sparkles, Video, Image, Play } from 'lucide-react';

export default function RecommendationsView() {
  const contentIdeas = [
    {
      id: 1,
      type: 'Video',
      format: 'TikTok/Reels',
      title: 'Beat Breakdown Series',
      description: 'Weekly 60-second process videos showing how you create your signature sounds. Behind-the-scenes content drives 23% higher engagement.',
      bestTime: 'Thu, 7:30 PM',
      platforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts'],
      estimatedEngagement: '12-15K views',
      confidence: 'High',
      icon: Video,
      actionItems: [
        'Record 3-5 beat creation sessions this week',
        'Focus on purple/pink moody aesthetic in lighting',
        'Add captions explaining production techniques',
      ],
    },
    {
      id: 2,
      type: 'Live Stream',
      format: 'Instagram Live',
      title: 'Midnight Sessions Live',
      description: 'Monthly late-night studio sessions during "Midnight Vibes" release cycle. Interactive Q&A with production tips builds community.',
      bestTime: 'Fri, 10:00 PM',
      platforms: ['Instagram Live', 'TikTok Live'],
      estimatedEngagement: '2-3K live viewers',
      confidence: 'High',
      icon: Play,
      actionItems: [
        'Schedule for release week (June 14)',
        'Prepare 3-5 production tips to share',
        'Promote 24hrs in advance via Stories',
      ],
    },
    {
      id: 3,
      type: 'Carousel',
      format: 'Instagram Post',
      title: 'Visual Vibes: Lyrics + Photography',
      description: 'Weekly carousel posts pairing your lyrics with moody aesthetic photography. Use signature purple/pink tones for 23% engagement boost.',
      bestTime: 'Sat, 6:00 PM',
      platforms: ['Instagram', 'Facebook'],
      estimatedEngagement: '5-7K likes',
      confidence: 'High',
      icon: Image,
      actionItems: [
        'Select 5-7 impactful lyrics from "Midnight Vibes"',
        'Shoot/source moody urban photography',
        'Apply brand color grading (#8B5CF6, #EC4899)',
      ],
    },
    {
      id: 4,
      type: 'Video',
      format: 'YouTube + Clips',
      title: 'Day in the Life: Indie Artist Reality',
      description: 'Authentic lifestyle content showing the grind, struggles, and wins. Vulnerability builds deeper connections with Gen Z audience.',
      bestTime: 'Sun, 2:00 PM',
      platforms: ['YouTube', 'Instagram Reels'],
      estimatedEngagement: '8-10K views',
      confidence: 'Medium',
      icon: Video,
      actionItems: [
        'Film full day: morning routine to studio',
        'Show real struggles (writer\'s block, rejection)',
        'Create 3-4 Reels clips from long-form',
      ],
    },
    {
      id: 5,
      type: 'Interactive',
      format: 'Stories + Feed',
      title: 'Fan Remix Challenge',
      description: 'Encourage followers to create remixes/covers of "Midnight Vibes". Feature best submissions. UGC drives 40% engagement boost.',
      bestTime: 'Release week',
      platforms: ['TikTok', 'Instagram', 'Twitter'],
      estimatedEngagement: '500+ submissions',
      confidence: 'High',
      icon: Sparkles,
      actionItems: [
        'Create challenge hashtag: #MidnightVibesRemix',
        'Post stems or acapella for fans to use',
        'Feature top 5 remixes in Stories + Feed',
      ],
    },
  ];

  const releaseStrategy = {
    singleName: 'Midnight Vibes',
    releaseDate: 'June 14, 2026',
    countdown: '10 days',
    phases: [
      {
        phase: 'Teaser Phase',
        period: '10-7 days before',
        status: 'active',
        tasks: [
          { task: 'Post 15-second snippet on TikTok (6-9 PM EST)', done: true },
          { task: 'Share moody aesthetic photos with color palette', done: true },
          { task: 'Create anticipation with cryptic posts', done: false },
          { task: 'Story polls: "Drop Friday or Saturday?"', done: false },
        ],
      },
      {
        phase: 'Hype Phase',
        period: '6-3 days before',
        status: 'upcoming',
        tasks: [
          { task: 'Release official cover art (Sat 6 PM)', done: false },
          { task: 'Behind-the-scenes recording video', done: false },
          { task: 'Engage 100% of comments in first hour', done: false },
          { task: 'Tease lyrics via carousel post', done: false },
        ],
      },
      {
        phase: 'Launch Phase',
        period: 'Release day',
        status: 'upcoming',
        tasks: [
          { task: 'Midnight drop with countdown Stories', done: false },
          { task: 'Go live to thank fans (10 PM EST)', done: false },
          { task: 'Share lyrics breakdown carousel', done: false },
          { task: 'Launch #MidnightVibesRemix challenge', done: false },
        ],
      },
      {
        phase: 'Momentum Phase',
        period: '1-7 days after',
        status: 'upcoming',
        tasks: [
          { task: 'Share fan reactions and UGC', done: false },
          { task: 'Post streaming milestone updates', done: false },
          { task: 'Release music video or visualizer', done: false },
          { task: 'Feature top remixes from challenge', done: false },
        ],
      },
    ],
  };

  const weeklyGoals = [
    { goal: 'Post 5-7 times (60% during 6-9 PM EST)', current: 4, target: 7 },
    { goal: 'Respond to 100% comments in first hour', current: 32, target: 50 },
    { goal: 'Create 2 Reels/TikToks (moody aesthetic)', current: 1, target: 2 },
    { goal: 'Share 3-5 Stories daily (polls/interactive)', current: 12, target: 15 },
  ];

  const growthInsights = [
    {
      metric: 'Best Posting Times',
      insight: '6-9 PM EST shows 11.5% engagement vs 6.2% average',
      action: 'Schedule 60% of content in this window',
    },
    {
      metric: 'Color Performance',
      insight: 'Purple/pink gradient content gets 23% more engagement',
      action: 'Use #8B5CF6 and #EC4899 in all thumbnails',
    },
    {
      metric: 'Platform Strategy',
      insight: 'TikTok tests → Reels (48hrs) → YT Shorts = 3x reach',
      action: 'Cross-platform repurposing workflow',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">AI Recommendations</h2>
        <p className="text-[var(--color-text-secondary)] mt-1">Personalized content ideas and strategies to grow your brand.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {growthInsights.map((item, index) => (
          <div key={index} className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-4">
            <h3 className="font-bold text-sm mb-1">{item.metric}</h3>
            <p className="text-xs text-[var(--color-text-secondary)] mb-2">{item.insight}</p>
            <p className="text-xs text-purple-300 font-medium">→ {item.action}</p>
          </div>
        ))}
      </div>

      <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Target className="w-6 h-6 text-purple-500" />
          <div>
            <h3 className="text-xl font-bold">Release Strategy: {releaseStrategy.singleName}</h3>
            <p className="text-sm text-[var(--color-text-secondary)]">Releasing in {releaseStrategy.countdown} • {releaseStrategy.releaseDate}</p>
          </div>
        </div>

        <div className="space-y-4 mt-6">
          {releaseStrategy.phases.map((phase, index) => (
            <div key={index} className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-bold">{phase.phase}</h4>
                  <p className="text-sm text-[var(--color-text-secondary)]">{phase.period}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  phase.status === 'active' ? 'bg-green-500/20 text-green-300' :
                  phase.status === 'completed' ? 'bg-blue-500/20 text-blue-300' :
                  'bg-gray-500/20 text-gray-300'
                }`}>
                  {phase.status}
                </span>
              </div>
              <div className="space-y-2">
                {phase.tasks.map((item, taskIndex) => (
                  <div key={taskIndex} className="flex items-center gap-2">
                    {item.done ? (
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border-2 border-[var(--color-border)] flex-shrink-0" />
                    )}
                    <span className={`text-sm ${item.done ? 'text-[var(--color-text-secondary)] line-through' : ''}`}>
                      {item.task}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Lightbulb className="w-6 h-6 text-yellow-500" />
          <h3 className="text-xl font-bold">Content Ideas Tailored for You</h3>
        </div>

        <div className="space-y-6">
          {contentIdeas.map((idea) => {
            const Icon = idea.icon;
            return (
              <div key={idea.id} className="p-5 bg-[var(--color-background)] rounded-xl border border-[var(--color-border)]">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3 flex-1">
                    <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-purple-500" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2 py-1 bg-purple-500/20 text-purple-300 rounded text-xs font-medium">
                          {idea.type}
                        </span>
                        <span className="px-2 py-1 bg-blue-500/20 text-blue-300 rounded text-xs font-medium">
                          {idea.format}
                        </span>
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          idea.confidence === 'High' ? 'bg-green-500/20 text-green-300' :
                          'bg-yellow-500/20 text-yellow-300'
                        }`}>
                          {idea.confidence} Confidence
                        </span>
                      </div>
                      <h4 className="font-bold text-lg mb-2">{idea.title}</h4>
                      <p className="text-sm text-[var(--color-text-secondary)] mb-3">{idea.description}</p>

                      <div className="bg-[var(--color-surface)] rounded-lg p-3 mb-3">
                        <p className="text-xs font-medium text-[var(--color-text-secondary)] mb-2">Action Items:</p>
                        <ul className="space-y-1">
                          {idea.actionItems.map((item, i) => (
                            <li key={i} className="flex items-start gap-2">
                              <div className="w-1 h-1 rounded-full bg-purple-500 mt-1.5 flex-shrink-0" />
                              <span className="text-xs">{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {idea.platforms.map((platform) => (
                          <span key={platform} className="px-2 py-1 bg-[var(--color-surface)] rounded text-xs">
                            {platform}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-4 pt-4 border-t border-[var(--color-border)]">
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4 text-purple-500" />
                      <span>{idea.bestTime}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="w-4 h-4 text-green-500" />
                      <span>{idea.estimatedEngagement}</span>
                    </div>
                  </div>
                  <button className="px-5 py-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-medium transition-all shadow-lg shadow-purple-500/20">
                    Schedule Post
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <h3 className="text-xl font-bold mb-4">This Week's Goals</h3>
        <div className="space-y-4">
          {weeklyGoals.map((item, index) => (
            <div key={index}>
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium">{item.goal}</span>
                <span className="text-sm font-bold">
                  {item.current} / {item.target}
                </span>
              </div>
              <div className="h-3 bg-[var(--color-background)] rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all"
                  style={{ width: `${(item.current / item.target) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
