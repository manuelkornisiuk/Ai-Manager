# ArtistOS

**AI-Powered Personal Brand Manager for Musicians**

© 2026 Juan Manuel Kornisiuk. All Rights Reserved.

## About

ArtistOS is an intelligent platform that helps independent musicians grow their audience and build their brand. By analyzing your content, audience behavior, and successful artists in your genre, ArtistOS provides personalized recommendations and AI-powered content generation.

## ⚠️ IMPORTANT: Current Status

**This is currently a DEMO/PROTOTYPE version:**

- ✅ All data shown is **mock/demonstration data only**
- ✅ **No real social media accounts are connected**
- ✅ **Your Instagram, Spotify, TikTok, and YouTube accounts are 100% safe**
- ✅ No API calls are made to any real platforms
- ✅ This is a frontend-only demonstration

**See [SECURITY_NOTICE.md](./SECURITY_NOTICE.md) for complete details about safety and future OAuth implementation.**

## Features

- **Brand DNA Analysis** - Understand your unique artistic identity
- **AI Content Generator** - Get personalized post ideas and video scenarios
- **Genre Insights** - Learn from successful artists in your genre
- **Audience Analytics** - Track demographics and engagement
- **Content Recommendations** - Actionable growth strategies
- **Schedule & Planning** - Organize your content calendar
- **Dark/Light Mode** - Comfortable viewing in any environment

## Getting Started

### Prerequisites

- Node.js 18+ or later
- pnpm (recommended) or npm

### Installation

1. Clone or download this repository
2. Install dependencies:
   ```bash
   pnpm install
   ```

3. Start the development server:
   ```bash
   pnpm run dev
   ```

4. Open your browser to `http://localhost:5173`

### Building for Production

Create an optimized production build:

```bash
pnpm run build
```

The built files will be in the `dist/` folder, ready to deploy to any static hosting service (Vercel, Netlify, GitHub Pages, etc.).

## Tech Stack

- **React 18.3.1** with TypeScript
- **Tailwind CSS v4** for styling
- **Recharts** for data visualization
- **Lucide React** for icons
- **Vite** for build tooling

## Pricing

- **Monthly**: $15/month
- **Quarterly**: $39 ($13/month, save $6)
- **Annual**: $99 early bird (regular $144, save $81)

## Security & Privacy

ArtistOS takes your security seriously:

- **End-to-End Encryption** - TLS 1.3 for all data transmission
- **AES-256 Encryption** - Data encrypted at rest
- **OAuth 2.0** - Secure platform authentication
- **Zero-Knowledge Architecture** - We can't access your passwords
- **GDPR & CCPA Compliant** - Full privacy regulation compliance
- **No Data Selling** - Your data is never sold or shared

See [SECURITY.md](./SECURITY.md) and [PRIVACY.md](./PRIVACY.md) for details.

## License

All rights reserved. See [COPYRIGHT](./COPYRIGHT) for details.

## Contact

Created by Juan Manuel Kornisiuk
