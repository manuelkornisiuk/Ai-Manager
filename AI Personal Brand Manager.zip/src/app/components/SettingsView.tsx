import { Instagram, Youtube, Music2, Check, Plus, Settings as SettingsIcon, Shield, Lock, Eye, EyeOff, Crown } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import SecurityBadge from './SecurityBadge.tsx';
import SocialMediaSettings from './SocialMediaSettings';

export default function SettingsView() {
  const { user, isCreator } = useAuth();
  const [activeTab, setActiveTab] = useState<'general' | 'social'>('general');

  const connectedAccounts = [
    {
      platform: 'Instagram',
      username: '@jordanbeats',
      followers: '18.5K',
      connected: true,
      icon: Instagram,
      color: 'from-purple-500 to-pink-500',
    },
    {
      platform: 'TikTok',
      username: '@jordanbeats',
      followers: '22.3K',
      connected: true,
      icon: Music2,
      color: 'from-pink-500 to-red-500',
    },
    {
      platform: 'Spotify',
      username: 'Jordan Beats',
      followers: '4.2K',
      connected: true,
      icon: Music2,
      color: 'from-green-500 to-emerald-500',
    },
    {
      platform: 'YouTube',
      username: 'Jordan Beats',
      followers: '2.2K',
      connected: true,
      icon: Youtube,
      color: 'from-red-500 to-orange-500',
    },
  ];

  const availablePlatforms = [
    { platform: 'Twitter', icon: Music2, color: 'from-blue-400 to-blue-500' },
    { platform: 'SoundCloud', icon: Music2, color: 'from-orange-500 to-red-500' },
    { platform: 'Apple Music', icon: Music2, color: 'from-pink-500 to-red-500' },
  ];

  const notifications = [
    { name: 'New follower alerts', enabled: true },
    { name: 'Content performance updates', enabled: true },
    { name: 'Weekly analytics report', enabled: true },
    { name: 'Posting reminders', enabled: false },
    { name: 'AI recommendation notifications', enabled: true },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Settings</h2>
        <p className="text-[var(--color-text-secondary)] mt-1">Manage your connected accounts and preferences.</p>
      </div>

      <SecurityBadge variant="banner" />

      {/* Tabs */}
      <div className="flex gap-2 border-b border-[var(--color-border)]">
        <button
          onClick={() => setActiveTab('general')}
          className={`px-6 py-3 font-medium transition-all ${
            activeTab === 'general'
              ? 'text-purple-400 border-b-2 border-purple-500'
              : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]'
          }`}
        >
          General
        </button>
        <button
          onClick={() => setActiveTab('social')}
          className={`px-6 py-3 font-medium transition-all ${
            activeTab === 'social'
              ? 'text-purple-400 border-b-2 border-purple-500'
              : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]'
          }`}
        >
          Social Media
        </button>
      </div>

      {activeTab === 'social' ? (
        <SocialMediaSettings />
      ) : (
        <div className="space-y-6">

      <div className={`bg-gradient-to-br ${
        isCreator
          ? 'from-green-500/10 to-emerald-500/10 border-green-500/20'
          : 'from-purple-500/10 to-pink-500/10 border-purple-500/20'
      } border rounded-xl p-6 mb-6`}>
        <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
          Your ArtistOS Subscription
          {isCreator && (
            <span className="px-2 py-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white text-xs font-bold rounded-full">
              CREATOR
            </span>
          )}
        </h3>
        <p className="text-sm text-[var(--color-text-secondary)] mb-4">
          {isCreator ? 'Creator Account - Full Access (Free Forever)' : 'Professional Plan - $69/month'}
        </p>
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-3">
            <p className="text-2xl font-bold text-purple-400">4</p>
            <p className="text-xs text-[var(--color-text-secondary)]">Connected Platforms</p>
          </div>
          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-3">
            <p className="text-2xl font-bold text-pink-400">∞</p>
            <p className="text-xs text-[var(--color-text-secondary)]">AI Recommendations</p>
          </div>
          <div className="bg-[var(--color-surface)]/50 backdrop-blur rounded-lg p-3">
            <p className="text-2xl font-bold text-blue-400">24/7</p>
            <p className="text-xs text-[var(--color-text-secondary)]">Brand Monitoring</p>
          </div>
        </div>
        {isCreator ? (
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 flex items-start gap-3">
            <Crown className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-bold text-green-400 mb-1">Creator Account Benefits</p>
              <p className="text-xs text-[var(--color-text-secondary)]">
                As the creator of ArtistOS, you have lifetime free access to all features including unlimited music pitching,
                priority support, and all future updates. No payment required, ever.
              </p>
            </div>
          </div>
        ) : (
          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 flex items-start gap-3">
            <Crown className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-bold text-yellow-400 mb-1">Upgrade to Premium for Music Pitching</p>
              <p className="text-xs text-[var(--color-text-secondary)] mb-2">
                Unlock unlimited pitching to Spotify playlists, blogs, and TV/film sync. Just $149/month or $119/month annually.
              </p>
              <button className="px-4 py-2 bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-white rounded-lg font-medium text-sm transition-all">
                Upgrade to Premium
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="bg-blue-500/10 border-2 border-blue-500/30 rounded-xl p-4 mb-6">
        <div className="flex items-start gap-3">
          <Shield className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-bold text-blue-300 mb-1">Demo Mode - Your Accounts Are Safe</h4>
            <p className="text-sm text-[var(--color-text-secondary)]">
              The accounts shown below are for demonstration only. <strong className="text-white">No real social media accounts are connected.</strong> When this app goes live, you'll connect accounts securely via OAuth 2.0, which means:
            </p>
            <ul className="text-xs text-[var(--color-text-secondary)] mt-2 space-y-1 ml-4">
              <li>• You'll never share your password with ArtistOS</li>
              <li>• You'll authorize through official platform websites (Instagram.com, Spotify.com, etc.)</li>
              <li>• The app can only READ public data, never post or modify without your permission</li>
              <li>• You can revoke access anytime from your platform settings</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-purple-500" />
            <h3 className="text-xl font-bold">Connected Accounts (Demo)</h3>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-[var(--color-text-secondary)]">
            <Lock className="w-3.5 h-3.5" />
            <span>Mock Data Only</span>
          </div>
        </div>

        <div className="space-y-4">
          {connectedAccounts.map((account) => {
            const Icon = account.icon;
            return (
              <div key={account.platform} className="flex items-center justify-between p-4 bg-[var(--color-background)] rounded-lg">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${account.color} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold">{account.platform}</h4>
                    <p className="text-sm text-[var(--color-text-secondary)]">
                      {account.username} • {account.followers} followers
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1 text-blue-400">
                    <Shield className="w-4 h-4" />
                    <span className="text-sm font-medium">Demo Only</span>
                  </div>
                  <button
                    disabled
                    className="px-4 py-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg font-medium opacity-50 cursor-not-allowed"
                  >
                    Manage
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6 opacity-60">
        <h3 className="text-xl font-bold mb-2">Add More Platforms</h3>
        <p className="text-sm text-[var(--color-text-secondary)] mb-4">(Available when app goes live with OAuth)</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {availablePlatforms.map((platform) => {
            const Icon = platform.icon;
            return (
              <button
                key={platform.platform}
                disabled
                className="flex flex-col items-center gap-3 p-6 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg cursor-not-allowed"
              >
                <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${platform.color} flex items-center justify-center opacity-50`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <div className="text-center">
                  <h4 className="font-bold">{platform.platform}</h4>
                  <div className="flex items-center gap-1 text-sm text-[var(--color-text-secondary)] mt-1">
                    <Plus className="w-4 h-4" />
                    <span>Demo Mode</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <h3 className="text-xl font-bold mb-4">Notification Preferences</h3>
        <div className="space-y-3">
          {notifications.map((notification) => (
            <div key={notification.name} className="flex items-center justify-between p-4 bg-[var(--color-background)] rounded-lg">
              <span className="font-medium">{notification.name}</span>
              <button
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  notification.enabled ? 'bg-purple-500' : 'bg-[var(--color-border)]'
                }`}
              >
                <div
                  className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                    notification.enabled ? 'translate-x-7' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <h3 className="text-xl font-bold mb-4">Account Information</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Artist Name</label>
            <input
              type="text"
              defaultValue={user?.name || "Jordan Beats"}
              className="w-full px-4 py-2 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Email</label>
            <input
              type="email"
              defaultValue={user?.email || "jordan@artistos.com"}
              className="w-full px-4 py-2 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Genre</label>
            <input
              type="text"
              defaultValue="Alternative Hip-Hop"
              className="w-full px-4 py-2 bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
          {isCreator && (
            <div>
              <label className="block text-sm font-medium mb-2">Account Type</label>
              <div className="px-4 py-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                <div className="flex items-center gap-2">
                  <Crown className="w-5 h-5 text-green-400" />
                  <span className="font-bold text-green-400">Creator Account</span>
                </div>
                <p className="text-xs text-[var(--color-text-secondary)] mt-1">
                  You have lifetime access to all features, completely free.
                </p>
              </div>
            </div>
          )}
        </div>
        <button className="mt-6 px-6 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-lg font-medium transition-colors">
          Save Changes
        </button>
      </div>

      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <Shield className="w-5 h-5 text-green-500" />
          <h3 className="text-xl font-bold">Security & Privacy</h3>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-[var(--color-background)] rounded-lg">
            <div>
              <h4 className="font-medium">Two-Factor Authentication</h4>
              <p className="text-xs text-[var(--color-text-secondary)]">Add an extra layer of security</p>
            </div>
            <button className="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-lg text-sm font-medium transition-colors">
              Enable
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-[var(--color-background)] rounded-lg">
            <div>
              <h4 className="font-medium">Session Timeout</h4>
              <p className="text-xs text-[var(--color-text-secondary)]">Auto-logout after inactivity</p>
            </div>
            <select className="px-3 py-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg text-sm">
              <option>30 minutes</option>
              <option>1 hour</option>
              <option>4 hours</option>
              <option>Never</option>
            </select>
          </div>
          <div className="flex items-center justify-between p-4 bg-[var(--color-background)] rounded-lg">
            <div>
              <h4 className="font-medium">Data Encryption</h4>
              <p className="text-xs text-[var(--color-text-secondary)]">AES-256 encryption enabled</p>
            </div>
            <div className="flex items-center gap-1.5 text-green-500">
              <Check className="w-4 h-4" />
              <span className="text-sm font-medium">Active</span>
            </div>
          </div>
          <div className="p-4 bg-green-500/5 border border-green-500/20 rounded-lg">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
              <div className="flex-1 text-xs text-[var(--color-text-secondary)]">
                <p className="font-medium text-foreground mb-1">Your data is protected</p>
                <p>We use bank-level security measures including end-to-end encryption, OAuth 2.0 authentication, and zero-knowledge architecture. We never store your passwords or sell your data. Read our <a href="#" className="text-purple-500 hover:underline">Privacy Policy</a> and <a href="#" className="text-purple-500 hover:underline">Security Policy</a>.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 pt-6 border-t border-[var(--color-border)] space-y-4">
        <SecurityBadge variant="footer" />
        <p className="text-center text-sm text-[var(--color-text-secondary)]">
          ArtistOS &copy; 2026 Juan Manuel Kornisiuk. All Rights Reserved.
        </p>
      </div>
        </div>
      )}
    </div>
  );
}
