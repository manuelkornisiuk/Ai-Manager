import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Create a mock client for demo mode when credentials aren't configured
const createMockClient = () => {
  const mockClient: any = {
    auth: {
      signUp: async () => ({ data: null, error: new Error('Demo mode: Supabase not configured') }),
      signInWithPassword: async () => ({ data: null, error: new Error('Demo mode: Supabase not configured') }),
      signOut: async () => ({ error: null }),
      resetPasswordForEmail: async () => ({ error: null }),
      updateUser: async () => ({ error: null }),
    },
    from: () => ({
      select: () => ({
        eq: () => ({
          single: async () => ({ data: null, error: new Error('Demo mode: Supabase not configured') }),
        }),
        order: () => Promise.resolve({ data: [], error: null }),
      }),
      insert: () => ({
        select: () => ({
          single: async () => ({ data: null, error: new Error('Demo mode: Supabase not configured') }),
        }),
      }),
      update: () => ({
        eq: () => ({
          select: () => ({
            single: async () => ({ data: null, error: new Error('Demo mode: Supabase not configured') }),
          }),
        }),
      }),
    }),
  };
  return mockClient;
};

export const supabase = (!supabaseUrl || !supabaseAnonKey)
  ? createMockClient()
  : createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Profile {
  id: string;
  email: string;
  full_name?: string;
  artist_name?: string;
  bio?: string;
  genre?: string;
  avatar_url?: string;
  instagram_handle?: string;
  spotify_artist_id?: string;
  tiktok_handle?: string;
  youtube_channel_id?: string;
  is_creator: boolean;
  created_at: string;
  updated_at: string;
}

export interface Subscription {
  id: string;
  user_id: string;
  stripe_customer_id?: string;
  stripe_subscription_id?: string;
  plan_type: 'free' | 'monthly' | 'quarterly' | 'annual' | 'creator';
  status: 'active' | 'canceled' | 'past_due' | 'incomplete' | 'trialing';
  current_period_start?: string;
  current_period_end?: string;
  cancel_at_period_end: boolean;
  created_at: string;
  updated_at: string;
}

export interface PlaylistPitch {
  id: string;
  user_id: string;
  song_title: string;
  artist_name: string;
  spotify_track_url?: string;
  genre?: string;
  mood?: string;
  description?: string;
  pitch_message?: string;
  target_playlists?: any;
  status: 'draft' | 'submitted' | 'under_review' | 'accepted' | 'rejected';
  submission_date?: string;
  created_at: string;
  updated_at: string;
}

export interface CuratorContact {
  id: string;
  user_id: string;
  name: string;
  email?: string;
  playlist_name?: string;
  playlist_url?: string;
  platform: string;
  genre?: string;
  follower_count?: number;
  notes?: string;
  last_contacted?: string;
  response_status?: 'pending' | 'responded' | 'accepted' | 'declined' | 'no_response';
  created_at: string;
  updated_at: string;
}

export interface ContentIdea {
  id: string;
  user_id: string;
  title: string;
  description?: string;
  content_type?: string;
  platforms?: any;
  estimated_engagement?: string;
  difficulty?: string;
  time_to_create?: string;
  ai_generated: boolean;
  saved: boolean;
  created_at: string;
}

// Auth helpers
export const signUp = async (email: string, password: string, fullName: string) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        full_name: fullName,
      },
    },
  });

  if (error) throw error;
  return data;
};

export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw error;
  return data;
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};

export const resetPassword = async (email: string) => {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/reset-password`,
  });

  if (error) throw error;
};

export const updatePassword = async (newPassword: string) => {
  const { error } = await supabase.auth.updateUser({
    password: newPassword,
  });

  if (error) throw error;
};

// Profile helpers
export const getProfile = async (userId: string) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error) throw error;
  return data as Profile;
};

export const updateProfile = async (userId: string, updates: Partial<Profile>) => {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .single();

  if (error) throw error;
  return data as Profile;
};

// Subscription helpers
export const getSubscription = async (userId: string) => {
  const { data, error } = await supabase
    .from('subscriptions')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (error) throw error;
  return data as Subscription;
};

// Playlist pitch helpers
export const getPlaylistPitches = async (userId: string) => {
  const { data, error} = await supabase
    .from('playlist_pitches')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data as PlaylistPitch[];
};

export const createPlaylistPitch = async (pitch: Omit<PlaylistPitch, 'id' | 'created_at' | 'updated_at'>) => {
  const { data, error } = await supabase
    .from('playlist_pitches')
    .insert([pitch])
    .select()
    .single();

  if (error) throw error;
  return data as PlaylistPitch;
};

export const updatePlaylistPitch = async (pitchId: string, updates: Partial<PlaylistPitch>) => {
  const { data, error } = await supabase
    .from('playlist_pitches')
    .update(updates)
    .eq('id', pitchId)
    .select()
    .single();

  if (error) throw error;
  return data as PlaylistPitch;
};

// Curator contact helpers
export const getCuratorContacts = async (userId: string) => {
  const { data, error } = await supabase
    .from('curator_contacts')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data as CuratorContact[];
};

export const createCuratorContact = async (contact: Omit<CuratorContact, 'id' | 'created_at' | 'updated_at'>) => {
  const { data, error } = await supabase
    .from('curator_contacts')
    .insert([contact])
    .select()
    .single();

  if (error) throw error;
  return data as CuratorContact;
};

// Content ideas helpers
export const getContentIdeas = async (userId: string) => {
  const { data, error } = await supabase
    .from('content_ideas')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data as ContentIdea[];
};

export const saveContentIdea = async (idea: Omit<ContentIdea, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('content_ideas')
    .insert([idea])
    .select()
    .single();

  if (error) throw error;
  return data as ContentIdea;
};
