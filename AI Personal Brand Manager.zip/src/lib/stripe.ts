import { loadStripe, Stripe } from '@stripe/stripe-js';

const stripePublishableKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY;

if (!stripePublishableKey) {
  console.warn('Demo mode: Stripe not configured. Payment features will use mock data.');
}

let stripePromise: Promise<Stripe | null>;

export const getStripe = () => {
  if (!stripePromise && stripePublishableKey) {
    stripePromise = loadStripe(stripePublishableKey);
  }
  return stripePromise;
};

// Subscription plans
export const SUBSCRIPTION_PLANS = {
  monthly: {
    name: 'Monthly Plan',
    price: 15,
    interval: 'month',
    priceId: import.meta.env.VITE_STRIPE_MONTHLY_PRICE_ID,
    features: [
      'All Professional features',
      'Unlimited content generation',
      'Brand DNA analysis',
      'Audience insights',
      'Content scheduling',
    ],
  },
  quarterly: {
    name: 'Quarterly Plan',
    price: 39,
    interval: '3 months',
    priceId: import.meta.env.VITE_STRIPE_QUARTERLY_PRICE_ID,
    savings: '13%',
    features: [
      'All Monthly Plan features',
      'Save $6 compared to monthly',
      'Priority support',
    ],
  },
  annual: {
    name: 'Annual Plan',
    price: 144,
    interval: 'year',
    priceId: import.meta.env.VITE_STRIPE_ANNUAL_PRICE_ID,
    savings: '20%',
    features: [
      'All Monthly Plan features',
      'Music pitching to playlists',
      'AI-powered pitch generation',
      'Curator CRM',
      'Priority support',
      'Save $36 compared to monthly',
    ],
  },
};

// Create checkout session
export const createCheckoutSession = async (priceId: string, customerId?: string) => {
  try {
    const response = await fetch('/api/create-checkout-session', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        priceId,
        customerId,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to create checkout session');
    }

    const { sessionId } = await response.json();
    return sessionId;
  } catch (error) {
    console.error('Error creating checkout session:', error);
    throw error;
  }
};

// Create customer portal session
export const createPortalSession = async (customerId: string) => {
  try {
    const response = await fetch('/api/create-portal-session', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        customerId,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to create portal session');
    }

    const { url } = await response.json();
    return url;
  } catch (error) {
    console.error('Error creating portal session:', error);
    throw error;
  }
};

// Redirect to checkout
export const redirectToCheckout = async (priceId: string, customerId?: string) => {
  const stripe = await getStripe();
  if (!stripe) {
    throw new Error('Stripe not initialized');
  }

  const sessionId = await createCheckoutSession(priceId, customerId);

  const { error } = await stripe.redirectToCheckout({ sessionId });

  if (error) {
    console.error('Stripe redirect error:', error);
    throw error;
  }
};

// Redirect to customer portal
export const redirectToPortal = async (customerId: string) => {
  const url = await createPortalSession(customerId);
  window.location.href = url;
};
